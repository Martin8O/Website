/**
 * Input triggers (spec §11) — the DOM half. Declarative *input → named signal* rules
 * that only the player can resolve, because they hit-test against the **rendered** 3D
 * scene; the host page gets a plain DOM event and never touches three (ADR-009).
 *
 * Three constraints shape everything here:
 *
 *  1. **The canvas cannot listen.** It is `pointer-events: none` so that real links and
 *     buttons an author overlays on the scene stay clickable (C5/C6). So the listeners go
 *     on the HOST element and coordinates are mapped into the canvas box by hand. The
 *     same rule in reverse: an event whose target is a *slotted* light-DOM node belongs to
 *     that node — the pixel is the page's, not the scene's — so we ignore it. Nothing here
 *     ever calls `preventDefault()` or `stopPropagation()`.
 *  2. **No work in the pointer handler.** `pointermove` fires far more often than a frame;
 *     raycasting on each one would be exactly the jank the scroll rule forbids. Moves are
 *     coalesced into one rAF, so at most one raycast per frame. `click` is discrete and
 *     handled immediately.
 *  3. **Progressive enhancement.** Hover triggers may never fire on touch, and a trigger
 *     only ever *signals* — it cannot seek or play (ADR-009 defers actions post-1.0). An
 *     `on` value this version does not know is silently ignored (§11 additive rule).
 */

import type { Trigger, TriggerOn, Vec3 } from "../format/types.js";

/** v1 closed set (§11). A document may carry others; we ignore what we don't know. */
const KNOWN_ON: ReadonlySet<string> = new Set<TriggerOn>(["click", "pointerenter", "pointerleave"]);

/** What the host receives, verbatim, as the `vertie-trigger` detail. */
export interface TriggerSignal {
  /** The trigger's `emit` name. */
  name: string;
  on: TriggerOn;
  /** Track id that was hit, or null for a whole-canvas trigger. */
  target: string | null;
  /** Scene-local time the input landed at. */
  time: number;
  /** World-space hit point; null for a whole-canvas trigger. */
  point: Vec3 | null;
  /** Pointer position in the canvas box (CSS pixels, top-left origin). */
  screen: { x: number; y: number };
  /** The trigger's verbatim `x-*` payload. */
  data: Record<string, unknown>;
}

/** The renderer slice a controller needs — narrow, so a test needs no three and no GPU. */
export interface TriggerHitTester {
  /** Canvas-box CSS pixels → the track under them, or null. */
  hitTest(x: number, y: number): { id: string; point: Vec3 } | null;
}

export interface TriggerControllerOptions {
  /** The element that listens (the shadow host — the canvas cannot). */
  host: HTMLElement;
  /** The canvas, for its client rect: input outside the box is not input for the scene. */
  canvas: Element;
  /** Raw scene triggers, in document order. */
  triggers: Trigger[];
  hitTester: TriggerHitTester;
  /** Current scene-local time — `during` windows and the signal's `time` read this. */
  sceneTime(): number;
  emit(signal: TriggerSignal): void;
  /** Frame scheduling seam (a hidden tab pauses rAF; tests pump by hand). */
  raf?(callback: () => void): number;
  caf?(handle: number): void;
}

export interface TriggerControllerDebug {
  /** Triggers declared by the scene, including ones this version ignores. */
  count: number;
  /** How many are armed right now (`during` window + a known `on`). */
  armed: number;
  /** Track id currently under the pointer, or null. */
  hovered: string | null;
  /** Whether the pointer is inside the canvas box at all. */
  inside: boolean;
}

/** One compiled rule: the payload extracted once, `on` narrowed to what we support. */
interface CompiledTrigger {
  on: TriggerOn;
  target: string | null;
  emit: string;
  from: number;
  to: number;
  cursor: string | null;
  data: Record<string, unknown>;
}

function extractPayload(trigger: Trigger): Record<string, unknown> {
  const data: Record<string, unknown> = {};
  for (const key of Object.keys(trigger)) {
    if (key.startsWith("x-")) data[key] = (trigger as unknown as Record<string, unknown>)[key];
  }
  return data;
}

function compile(triggers: Trigger[]): CompiledTrigger[] {
  const compiled: CompiledTrigger[] = [];
  for (const trigger of triggers) {
    // §11: a newer-minor document must keep playing on an older same-major player.
    if (!KNOWN_ON.has(trigger.on)) continue;
    compiled.push({
      on: trigger.on,
      target: trigger.target ?? null,
      emit: trigger.emit,
      from: trigger.during?.[0] ?? -Infinity,
      to: trigger.during?.[1] ?? Infinity,
      cursor: trigger.cursor ?? null,
      data: extractPayload(trigger),
    });
  }
  return compiled;
}

/** No rAF (node, or an environment without one) = resolve immediately; nothing to coalesce. */
function defaultRaf(callback: () => void): number {
  if (typeof requestAnimationFrame !== "function") {
    callback();
    return 0;
  }
  return requestAnimationFrame(() => callback());
}

function defaultCaf(handle: number): void {
  if (typeof cancelAnimationFrame === "function") cancelAnimationFrame(handle);
}

/**
 * Owns every pointer listener a scene's triggers need — and installs none it does not.
 * A scene with only `click` triggers pays for no `pointermove` raycasting at all.
 */
export class TriggerController {
  private readonly compiled: CompiledTrigger[];
  private readonly host: HTMLElement;
  private readonly canvas: Element;
  private readonly options: TriggerControllerOptions;
  private readonly raf: (callback: () => void) => number;
  private readonly caf: (handle: number) => void;
  /** Which listener sets were actually installed (only what the scene needs). */
  private readonly listening: { click: boolean; hover: boolean };

  private hovered: string | null = null;
  private inside = false;
  private pending: number | null = null;
  private lastClientX = 0;
  private lastClientY = 0;
  private cursorApplied = false;
  private destroyed = false;

  constructor(options: TriggerControllerOptions) {
    this.options = options;
    this.host = options.host;
    this.canvas = options.canvas;
    this.compiled = compile(options.triggers);
    this.raf = options.raf ?? defaultRaf;
    this.caf = options.caf ?? defaultCaf;

    const wantsClick = this.compiled.some((t) => t.on === "click");
    // Hover state is needed by hover triggers AND by the cursor affordance of any trigger.
    const wantsHover = this.compiled.some((t) => t.on !== "click" || t.cursor !== null);

    if (wantsClick) this.host.addEventListener("click", this.onClick);
    if (wantsHover) {
      this.host.addEventListener("pointermove", this.onPointerMove);
      this.host.addEventListener("pointerleave", this.onPointerLeave);
    }
    this.listening = { click: wantsClick, hover: wantsHover };
  }

  get debug(): TriggerControllerDebug {
    const time = this.options.sceneTime();
    return {
      count: this.options.triggers.length,
      armed: this.compiled.filter((t) => time >= t.from && time <= t.to).length,
      hovered: this.hovered,
      inside: this.inside,
    };
  }

  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    if (this.listening.click) this.host.removeEventListener("click", this.onClick);
    if (this.listening.hover) {
      this.host.removeEventListener("pointermove", this.onPointerMove);
      this.host.removeEventListener("pointerleave", this.onPointerLeave);
    }
    if (this.pending !== null) this.caf(this.pending);
    this.pending = null;
    this.clearCursor();
  }

  // ── listeners ──────────────────────────────────────────────────────────────

  /**
   * A pointer event only belongs to the scene when it landed on the host itself. The
   * canvas is `pointer-events: none`, so anything with another target is a slotted
   * light-DOM node sitting on top — the page's own content, and its click is its own.
   */
  private ownEvent(event: Event): boolean {
    return event.target === this.host;
  }

  private readonly onClick = (event: Event): void => {
    if (!this.ownEvent(event)) return;
    const pointer = event as PointerEvent;
    const box = this.toBox(pointer.clientX, pointer.clientY);
    if (!box) return;
    const hit = this.options.hitTester.hitTest(box.x, box.y);
    this.fire("click", hit, box);
  };

  private readonly onPointerMove = (event: Event): void => {
    if (!this.ownEvent(event)) {
      // The pointer moved onto the page's own overlay: the scene is no longer hovered.
      this.leaveScene();
      return;
    }
    const pointer = event as PointerEvent;
    this.lastClientX = pointer.clientX;
    this.lastClientY = pointer.clientY;
    // Coalesce: one raycast per frame, never one per move (the scroll rule).
    if (this.pending !== null) return;
    this.pending = this.raf(() => {
      this.pending = null;
      if (!this.destroyed) this.resolveHover();
    });
  };

  private readonly onPointerLeave = (): void => this.leaveScene();

  // ── hover resolution ───────────────────────────────────────────────────────

  private leaveScene(): void {
    if (this.pending !== null) {
      this.caf(this.pending);
      this.pending = null;
    }
    if (this.hovered !== null || this.inside) this.applyHover(null, false, { x: 0, y: 0 }, null);
  }

  private resolveHover(): void {
    const box = this.toBox(this.lastClientX, this.lastClientY);
    if (!box) {
      this.applyHover(null, false, { x: 0, y: 0 }, null);
      return;
    }
    const hit = this.options.hitTester.hitTest(box.x, box.y);
    this.applyHover(hit?.id ?? null, true, box, hit?.point ?? null);
  }

  /** Diff the hover state and emit the enter/leave pairs the change implies. */
  private applyHover(
    id: string | null,
    inside: boolean,
    screen: { x: number; y: number },
    point: Vec3 | null,
  ): void {
    const previous = this.hovered;
    const wasInside = this.inside;
    this.hovered = id;
    this.inside = inside;

    // Leaves before enters, so a host swapping a label sees the old one close first.
    if (previous !== null && previous !== id) {
      this.emitFor("pointerleave", previous, screen, null);
    }
    if (wasInside && !inside) this.emitFor("pointerleave", null, screen, null);
    if (!wasInside && inside) this.emitFor("pointerenter", null, screen, null);
    if (id !== null && id !== previous) {
      this.emitFor("pointerenter", id, screen, point);
    }

    this.applyCursor(id);
  }

  /** The affordance (§11 `cursor`): set while hovering a target that declares one. */
  private applyCursor(id: string | null): void {
    const time = this.options.sceneTime();
    const rule = this.compiled.find(
      (t) => t.cursor !== null && t.target === id && time >= t.from && time <= t.to,
    );
    if (rule) {
      this.host.style.cursor = rule.cursor!;
      this.cursorApplied = true;
      return;
    }
    this.clearCursor();
  }

  private clearCursor(): void {
    if (!this.cursorApplied) return;
    this.host.style.cursor = "";
    this.cursorApplied = false;
  }

  // ── emitting ───────────────────────────────────────────────────────────────

  private fire(
    on: TriggerOn,
    hit: { id: string; point: Vec3 } | null,
    screen: { x: number; y: number },
  ): void {
    // A hit fires the object's triggers; a miss inside the box fires the whole-canvas
    // ones (`target` omitted, §11).
    this.emitFor(on, hit?.id ?? null, screen, hit?.point ?? null);
    if (hit) this.emitFor(on, null, screen, null);
  }

  private emitFor(
    on: TriggerOn,
    target: string | null,
    screen: { x: number; y: number },
    point: Vec3 | null,
  ): void {
    const time = this.options.sceneTime();
    for (const trigger of this.compiled) {
      if (trigger.on !== on || trigger.target !== target) continue;
      if (time < trigger.from || time > trigger.to) continue; // outside its `during` window
      this.options.emit({
        name: trigger.emit,
        on,
        target,
        time,
        point,
        screen: { x: screen.x, y: screen.y },
        data: trigger.data,
      });
    }
  }

  /** Client coordinates → canvas-box CSS pixels, or null when outside the box. */
  private toBox(clientX: number, clientY: number): { x: number; y: number } | null {
    const rect = this.canvas.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return null;
    const x = clientX - rect.left;
    const y = clientY - rect.top;
    if (x < 0 || y < 0 || x > rect.width || y > rect.height) return null;
    return { x, y };
  }
}
