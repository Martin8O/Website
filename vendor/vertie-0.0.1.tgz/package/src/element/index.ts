/**
 * The `element` layer: `<vertie-scene>` (C5) — the drop-in player.
 *
 * Importing this module REGISTERS the element, because the one-line embed is
 * `<script type="module" src=".../vertie.js"></script>` and nothing else: there is no
 * host JS to call a define function. The side effect is guarded, so importing the
 * package in node (tests, SSR, a bundler's analysis pass) does nothing.
 */
export {
  VertieSceneElement,
  defineVertieScene,
  defaultSceneEnv,
  DEFAULT_TAG,
  VERTIE_VERSION,
} from "./scene-element.js";

export type {
  VertieSceneEnv,
  VertieSceneDebug,
  VertieSceneDevTools,
  VertieProgressDetail,
  VertieEventDetail,
  VertieFollowDetail,
  VertieTriggerDetail,
  TriggerControllerLike,
  VertieErrorDetail,
  VertieErrorPhase,
  VertieFallbackDetail,
  VertieFallbackReason,
  VertieFallbackRung,
  VertieState,
  VertieGlobal,
  SceneSurface,
  ScenePreloaderLike,
  ElementDriver,
} from "./scene-element.js";

export { TriggerController } from "./triggers.js";
export type {
  TriggerSignal,
  TriggerControllerOptions,
  TriggerControllerDebug,
  TriggerHitTester,
} from "./triggers.js";

import { defineVertieScene } from "./scene-element.js";

defineVertieScene();
