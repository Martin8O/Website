/**
 * Minimal SPDX license-expression recognizer for the `meta.license` /
 * `attribution[].license` lints (spec §13).
 *
 * This is deliberately NOT a full SPDX license list (~600 ids) nor a complete
 * expression parser. It recognizes the curated set relevant to open web/3D
 * content plus the structural grammar (AND / OR / WITH, `+`, parentheses,
 * `LicenseRef-` / `DocumentRef-`). An unrecognized *identifier* produces a lint,
 * never a hard error — the goal is to catch typos ("CC-BY 4.0", "MIT-license"),
 * not to be an authority on licensing. Extend `KNOWN_LICENSE_IDS` as needed.
 */

/** Curated set of SPDX license identifiers likely to appear in Vertie scenes. */
export const KNOWN_LICENSE_IDS: ReadonlySet<string> = new Set([
  // Public-domain / permissive
  "CC0-1.0",
  "Unlicense",
  "MIT",
  "MIT-0",
  "BSD-2-Clause",
  "BSD-3-Clause",
  "ISC",
  "Zlib",
  "Apache-2.0",
  // Creative Commons 4.0 family (the common asset licenses)
  "CC-BY-4.0",
  "CC-BY-SA-4.0",
  "CC-BY-NC-4.0",
  "CC-BY-ND-4.0",
  "CC-BY-NC-SA-4.0",
  "CC-BY-NC-ND-4.0",
  // Creative Commons 3.0 (still common on older asset libraries)
  "CC-BY-3.0",
  "CC-BY-SA-3.0",
  // Copyleft (rare for scenes, but valid)
  "GPL-2.0-only",
  "GPL-2.0-or-later",
  "GPL-3.0-only",
  "GPL-3.0-or-later",
  "LGPL-3.0-only",
  "LGPL-3.0-or-later",
  "MPL-2.0",
]);

/** SPDX exception identifiers usable after `WITH`. Curated. */
export const KNOWN_LICENSE_EXCEPTIONS: ReadonlySet<string> = new Set([
  "LLVM-exception",
  "GCC-exception-3.1",
  "Classpath-exception-2.0",
]);

const OPERATORS = new Set(["AND", "OR", "WITH"]);

function isRecognizedLicenseToken(token: string): boolean {
  // Trailing `+` means "or-later" (e.g. `Apache-2.0+`).
  const base = token.endsWith("+") ? token.slice(0, -1) : token;
  if (base.length === 0) return false;
  // User-defined references are always accepted (custom/commercial terms).
  if (base.startsWith("LicenseRef-") || base.startsWith("DocumentRef-")) return true;
  return KNOWN_LICENSE_IDS.has(base);
}

/**
 * Returns `true` if `expr` is a recognizable SPDX license expression built from
 * known identifiers and the standard operators. Whitespace-tolerant; parses
 * `( )` grouping and `A WITH exception`. Conservative: returns `false` on
 * anything it cannot confidently recognize (the caller emits a lint, not an error).
 */
export function isRecognizedSpdxExpression(expr: string): boolean {
  if (typeof expr !== "string" || expr.trim().length === 0) return false;

  // Tokenize: parentheses are their own tokens; everything else splits on spaces.
  const tokens = expr
    .replace(/\(/g, " ( ")
    .replace(/\)/g, " ) ")
    .trim()
    .split(/\s+/);

  let depth = 0;
  // A tiny state machine: we alternate between expecting an operand and
  // expecting an operator (with parentheses handled around operands).
  let expectOperand = true;
  let sawWith = false;

  for (const tok of tokens) {
    if (tok === "(") {
      if (!expectOperand) return false;
      depth++;
      continue;
    }
    if (tok === ")") {
      if (expectOperand) return false; // ')' right after '(' or an operator
      depth--;
      if (depth < 0) return false;
      continue;
    }

    if (expectOperand) {
      if (sawWith) {
        // The token after WITH must be a recognized exception.
        if (!KNOWN_LICENSE_EXCEPTIONS.has(tok)) return false;
        sawWith = false;
        expectOperand = false;
        continue;
      }
      if (!isRecognizedLicenseToken(tok)) return false;
      expectOperand = false;
    } else {
      if (!OPERATORS.has(tok)) return false;
      if (tok === "WITH") sawWith = true;
      expectOperand = true;
    }
  }

  return depth === 0 && !expectOperand && !sawWith;
}
