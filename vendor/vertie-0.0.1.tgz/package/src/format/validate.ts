/**
 * `validateScene()` — the standalone, DOM-free Vertie scene validator (B3).
 *
 * Implements the rules in `docs/spec.md` §13 that are decidable from the scene
 * JSON document alone. Two severities:
 *   - `error` — the document is not a conformant scene (§13 "Hard errors").
 *   - `lint`  — the document is playable but violates a SHOULD (§13 "Lints").
 *
 * Additive-only discipline (ADR-004): unknown fields and the `x-*` namespace are
 * IGNORED, never rejected — there is no `additionalProperties: false` anywhere.
 *
 * ── Out of scope for this pure validator (documented, not silently dropped) ──
 * Several §13 lints require bytes or math this function deliberately does not have:
 *   • textures not KTX2 / ETC1S-vs-UASTC codec-role mismatch (§4.1) — needs GLB/KTX2 bytes.
 *   • uncompressed geometry (§4.1) — needs GLB bytes.
 *   • scene-vs-embedded-XMP metadata conflict (§3.1) — needs the GLB's KHR_xmp_json_ld packet.
 *   • keys escaping the stage frustum (§9) — needs the implicit stage-camera derivation (C3).
 * These belong to an asset-aware pass (loader / packer), not the JSON validator.
 * See `DEFERRED_LINTS` below. The "asset licensed nowhere" lint (§3.1) is emitted
 * here only in its JSON-decidable half: `ASSET_NO_ATTRIBUTION` (no scene-level
 * `attribution[]` entry) — embedded XMP, if any, may still license the asset.
 */

import { isRecognizedSpdxExpression } from "./spdx.js";

export type Severity = "error" | "lint";

/** Stable machine codes. New codes are additive; existing ones never change meaning. */
export type IssueCode =
  // structural / hard errors (§13)
  | "ROOT_NOT_OBJECT"
  | "MISSING_VERTIE"
  | "INVALID_VERTIE_VERSION"
  | "MISSING_META"
  | "MISSING_TRACKS"
  | "INVALID_ASSETS"
  | "MISSING_ASSET_SRC"
  | "MISSING_TRACK_ID"
  | "DUPLICATE_TRACK_ID"
  | "OBJECT_TRACK_MISSING_ASSET"
  | "MULTIPLE_CAMERA_TRACKS"
  | "EMPTY_KEYS"
  | "MISSING_KEY_POSITION"
  | "MISSING_KEY_ROTATION"
  | "MISSING_LEG_DURATION"
  | "NEGATIVE_DURATION"
  | "NEGATIVE_SPAN"
  | "NON_FINITE_NUMBER"
  | "INVALID_TYPE"
  | "UNKNOWN_ASSET_REF"
  | "UNKNOWN_ENVMAP_REF"
  | "UNKNOWN_FOLLOW_REF"
  | "UNKNOWN_LOOKAT_REF"
  | "UNKNOWN_TRIGGER_TARGET"
  | "MISSING_EVENT_NAME"
  | "MISSING_EVENT_AT"
  | "MISSING_TRIGGER_ON"
  | "MISSING_TRIGGER_EMIT"
  | "INVALID_DURING"
  | "BUNDLE_MISSING_SCENE_JSON"
  | "BUNDLE_PATH_ESCAPE"
  // lints (§13)
  | "MISSING_INTEGRITY"
  | "EXTERNAL_URL_IN_BUNDLE"
  | "DATA_URI_IN_BUNDLE"
  | "MISSING_META_LICENSE"
  | "MISSING_META_AUTHOR"
  | "UNRECOGNIZED_SPDX"
  | "ASSET_NO_ATTRIBUTION"
  | "UNKNOWN_TRIGGER_ON"
  | "CAMERA_TRACK_WITH_ASSET"
  | "DURING_REVERSED";

export interface ValidationIssue {
  code: IssueCode;
  severity: Severity;
  /** JSON-pointer-ish location, e.g. `/tracks/0/keys/2/p/1`. */
  path: string;
  message: string;
}

export interface ValidationResult {
  /** `true` iff there are no `error`-severity issues. */
  valid: boolean;
  errors: ValidationIssue[];
  lints: ValidationIssue[];
  /** All issues, in emission order. */
  issues: ValidationIssue[];
}

export type DeliveryMode = "reference" | "bundle";

export interface ValidateOptions {
  /**
   * Delivery mode (§14). Governs the `integrity` lint (reference) and the bundle
   * path/URL rules (bundle). Defaults to `"bundle"` when `bundleEntries` is given,
   * else `"reference"`.
   */
  mode?: DeliveryMode;
  /**
   * Archive entry paths, when validating a `.vertie` bundle (§14.2). Enables the
   * `BUNDLE_MISSING_SCENE_JSON` check. Path-escape checks run against asset `src`
   * values regardless, so this is optional.
   */
  bundleEntries?: string[];
}

/** §13 lints intentionally NOT implemented here (need asset bytes or framing math). */
export const DEFERRED_LINTS = [
  "textures-not-ktx2",
  "codec-role-mismatch",
  "uncompressed-geometry",
  "scene-vs-embedded-metadata-conflict",
  "keys-escape-stage-frustum",
] as const;

const TRIGGER_ON_V1: ReadonlySet<string> = new Set([
  "click",
  "pointerenter",
  "pointerleave",
]);

// ── small type guards ────────────────────────────────────────────────────────

function isObject(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}
function isString(v: unknown): v is string {
  return typeof v === "string";
}

// ── validation context ───────────────────────────────────────────────────────

class Ctx {
  readonly issues: ValidationIssue[] = [];
  error(code: IssueCode, path: string, message: string): void {
    this.issues.push({ code, severity: "error", path, message });
  }
  lint(code: IssueCode, path: string, message: string): void {
    this.issues.push({ code, severity: "lint", path, message });
  }

  /** Validate an optional numeric field; emits type / finiteness / range issues. */
  number(
    value: unknown,
    path: string,
    opts: { min?: number; minCode?: IssueCode } = {},
  ): void {
    if (value === undefined) return;
    if (typeof value !== "number") {
      this.error("INVALID_TYPE", path, "expected a number");
      return;
    }
    if (!Number.isFinite(value)) {
      this.error("NON_FINITE_NUMBER", path, "must be a finite number");
      return;
    }
    if (opts.min !== undefined && value < opts.min) {
      this.error(opts.minCode ?? "INVALID_TYPE", path, `must be >= ${opts.min}`);
    }
  }

  /** Validate a required fixed-length numeric tuple (Vec3 / Quat). */
  tuple(value: unknown, len: number, path: string, missingCode: IssueCode): void {
    if (!Array.isArray(value) || value.length !== len) {
      this.error(missingCode, path, `expected an array of ${len} numbers`);
      return;
    }
    value.forEach((n, i) => {
      if (typeof n !== "number") {
        this.error("INVALID_TYPE", `${path}/${i}`, "expected a number");
      } else if (!Number.isFinite(n)) {
        this.error("NON_FINITE_NUMBER", `${path}/${i}`, "must be a finite number");
      }
    });
  }
}

// ── src classification (§14) ─────────────────────────────────────────────────

type SrcKind = "relative" | "absolute-url" | "protocol-relative" | "data-uri" | "drive" | "posix-absolute";

function classifySrc(src: string): SrcKind {
  if (src.startsWith("//")) return "protocol-relative";
  if (/^data:/i.test(src)) return "data-uri";
  if (/^[a-zA-Z]:[\\/]/.test(src)) return "drive"; // single letter + colon = Windows drive
  if (/^[a-zA-Z][a-zA-Z\d+.-]*:\/\//.test(src)) return "absolute-url"; // scheme://
  if (src.startsWith("/") || src.startsWith("\\")) return "posix-absolute";
  return "relative";
}

function hasDotDotSegment(src: string): boolean {
  return src.split(/[\\/]/).includes("..");
}

// ── main entry ───────────────────────────────────────────────────────────────

export function validateScene(input: unknown, options: ValidateOptions = {}): ValidationResult {
  const ctx = new Ctx();
  const mode: DeliveryMode = options.mode ?? (options.bundleEntries ? "bundle" : "reference");

  if (!isObject(input)) {
    ctx.error("ROOT_NOT_OBJECT", "", "scene must be a JSON object");
    return finish(ctx);
  }

  validateVersion(ctx, input["vertie"]);
  const assetKeys = validateAssets(ctx, input["assets"], mode);
  validateMeta(ctx, input["meta"], assetKeys);
  validateEnvironment(ctx, input["environment"], assetKeys);
  validateStage(ctx, input["stage"]);
  ctx.number(input["duration"], "/duration", { min: 0, minCode: "NEGATIVE_DURATION" });

  const trackIds = validateTracks(ctx, input["tracks"], assetKeys);
  validateEvents(ctx, input["events"], trackIds);
  validateTriggers(ctx, input["triggers"], trackIds, isString(input["vertie"]) ? input["vertie"] : undefined);
  validateBundle(ctx, mode, options.bundleEntries);

  return finish(ctx);
}

function finish(ctx: Ctx): ValidationResult {
  const errors = ctx.issues.filter((i) => i.severity === "error");
  const lints = ctx.issues.filter((i) => i.severity === "lint");
  return { valid: errors.length === 0, errors, lints, issues: ctx.issues };
}

// ── §2 version ───────────────────────────────────────────────────────────────

function validateVersion(ctx: Ctx, vertie: unknown): void {
  if (vertie === undefined) {
    ctx.error("MISSING_VERTIE", "/vertie", "required spec version is missing");
    return;
  }
  if (!isString(vertie) || !/^\d+\.\d+$/.test(vertie)) {
    ctx.error("INVALID_VERTIE_VERSION", "/vertie", 'must be a "major.minor" string, e.g. "1.0"');
  }
}

// ── §4 assets ────────────────────────────────────────────────────────────────

function validateAssets(ctx: Ctx, assets: unknown, mode: DeliveryMode): Set<string> {
  const keys = new Set<string>();
  if (assets === undefined) return keys; // may be omitted for camera-only scenes
  if (!isObject(assets)) {
    ctx.error("INVALID_ASSETS", "/assets", "assets must be an object of key → descriptor");
    return keys;
  }
  for (const [key, descriptor] of Object.entries(assets)) {
    keys.add(key);
    const base = `/assets/${key}`;
    if (!isObject(descriptor)) {
      ctx.error("INVALID_TYPE", base, "asset descriptor must be an object");
      continue;
    }
    const src = descriptor["src"];
    if (!isString(src) || src.length === 0) {
      ctx.error("MISSING_ASSET_SRC", `${base}/src`, "asset requires a non-empty string src");
      continue;
    }
    const kind = classifySrc(src);
    if (mode === "bundle") {
      if (kind === "drive" || kind === "posix-absolute" || hasDotDotSegment(src)) {
        ctx.error(
          "BUNDLE_PATH_ESCAPE",
          `${base}/src`,
          "bundle asset paths must be relative and stay inside the archive (no '..', absolute or drive paths)",
        );
      } else if (kind === "absolute-url" || kind === "protocol-relative") {
        ctx.lint("EXTERNAL_URL_IN_BUNDLE", `${base}/src`, "bundle references an external URL — not self-contained");
      } else if (kind === "data-uri") {
        ctx.lint("DATA_URI_IN_BUNDLE", `${base}/src`, "bundles store bytes as files, not data: URIs (ADR-011)");
      }
    } else {
      // reference mode: integrity is RECOMMENDED (§14.3)
      if (descriptor["integrity"] === undefined) {
        ctx.lint("MISSING_INTEGRITY", base, "asset has no integrity hash (recommended in reference mode)");
      }
    }
  }
  return keys;
}

// ── §3 meta ──────────────────────────────────────────────────────────────────

function validateMeta(ctx: Ctx, meta: unknown, assetKeys: Set<string>): void {
  if (meta === undefined || !isObject(meta)) {
    ctx.error("MISSING_META", "/meta", "required meta block is missing or not an object");
    return;
  }

  const license = meta["license"];
  if (license === undefined) {
    ctx.lint("MISSING_META_LICENSE", "/meta/license", "scene should declare a license (SPDX expression)");
  } else if (isString(license) && !isRecognizedSpdxExpression(license)) {
    ctx.lint("UNRECOGNIZED_SPDX", "/meta/license", `unrecognized SPDX license expression: "${license}"`);
  }

  if (meta["author"] === undefined) {
    ctx.lint("MISSING_META_AUTHOR", "/meta/author", "scene should declare an author");
  }

  // Which assets are credited by a scene-level attribution entry?
  const creditedAssets = new Set<string>();
  const attribution = meta["attribution"];
  if (Array.isArray(attribution)) {
    attribution.forEach((entry, i) => {
      if (!isObject(entry)) return;
      const asset = entry["asset"];
      if (isString(asset)) creditedAssets.add(asset);
      const lic = entry["license"];
      if (isString(lic) && !isRecognizedSpdxExpression(lic)) {
        ctx.lint(
          "UNRECOGNIZED_SPDX",
          `/meta/attribution/${i}/license`,
          `unrecognized SPDX license expression: "${lic}"`,
        );
      }
    });
  }

  // §3.1: every referenced asset should be creditable from the scene JSON.
  // (Embedded XMP may still license it — hence a lint, not an error.)
  for (const key of assetKeys) {
    if (!creditedAssets.has(key)) {
      ctx.lint(
        "ASSET_NO_ATTRIBUTION",
        `/assets/${key}`,
        `asset "${key}" has no scene-level attribution entry (§3.1)`,
      );
    }
  }
}

// ── §5 environment ───────────────────────────────────────────────────────────

function validateEnvironment(ctx: Ctx, env: unknown, assetKeys: Set<string>): void {
  if (env === undefined) return;
  if (!isObject(env)) {
    ctx.error("INVALID_TYPE", "/environment", "environment must be an object");
    return;
  }
  const envMap = env["envMap"];
  if (envMap !== undefined) {
    if (!isString(envMap) || !assetKeys.has(envMap)) {
      ctx.error("UNKNOWN_ENVMAP_REF", "/environment/envMap", `envMap references unknown asset key: ${String(envMap)}`);
    }
  }
  ctx.number(env["exposure"], "/environment/exposure");
}

// ── §9 stage ─────────────────────────────────────────────────────────────────

function validateStage(ctx: Ctx, stage: unknown): void {
  if (stage === undefined) return;
  if (!isObject(stage)) {
    ctx.error("INVALID_TYPE", "/stage", "stage must be an object");
    return;
  }
  ctx.number(stage["fov"], "/stage/fov");
  const plane = stage["plane"];
  if (plane !== undefined) {
    if (!isObject(plane)) {
      ctx.error("INVALID_TYPE", "/stage/plane", "stage.plane must be an object");
    } else {
      ctx.number(plane["width"], "/stage/plane/width");
      ctx.number(plane["height"], "/stage/plane/height");
      ctx.number(plane["z"], "/stage/plane/z");
    }
  }
}

// ── §7 / §8 tracks ───────────────────────────────────────────────────────────

function validateTracks(ctx: Ctx, tracks: unknown, assetKeys: Set<string>): Set<string> {
  const ids = new Set<string>();
  if (!Array.isArray(tracks)) {
    ctx.error("MISSING_TRACKS", "/tracks", "required tracks array is missing or not an array");
    return ids;
  }

  // lookAt may reference a track defined later in the array — resolve after the pass.
  const pendingLookAt: { id: string; path: string }[] = [];

  let cameraCount = 0;
  tracks.forEach((track, ti) => {
    const base = `/tracks/${ti}`;
    if (!isObject(track)) {
      ctx.error("INVALID_TYPE", base, "track must be an object");
      return;
    }

    // id
    const id = track["id"];
    if (!isString(id) || id.length === 0) {
      ctx.error("MISSING_TRACK_ID", `${base}/id`, "track requires a unique string id");
    } else if (ids.has(id)) {
      ctx.error("DUPLICATE_TRACK_ID", `${base}/id`, `duplicate track id: "${id}"`);
    } else {
      ids.add(id);
    }

    // role: camera vs object
    const isCamera = track["role"] === "camera";
    if (isCamera) {
      cameraCount++;
      if (cameraCount > 1) {
        ctx.error("MULTIPLE_CAMERA_TRACKS", `${base}/role`, "at most one camera track is allowed (§8)");
      }
      if (track["asset"] !== undefined) {
        ctx.lint("CAMERA_TRACK_WITH_ASSET", `${base}/asset`, "camera track takes no asset — it will be ignored (§8)");
      }
      validateCamera(ctx, track["camera"], `${base}/camera`);
      validateLookAt(ctx, track["lookAt"], `${base}/lookAt`, pendingLookAt);
    } else {
      const asset = track["asset"];
      if (!isString(asset)) {
        ctx.error("OBJECT_TRACK_MISSING_ASSET", `${base}/asset`, "object track requires an asset key");
      } else if (!assetKeys.has(asset)) {
        ctx.error("UNKNOWN_ASSET_REF", `${base}/asset`, `track references unknown asset key: "${asset}"`);
      }
      validateTransform(ctx, track["transform"], `${base}/transform`);
    }

    ctx.number(track["start"], `${base}/start`);
    validateKeys(ctx, track["keys"], `${base}/keys`);
  });

  // Resolve lookAt track references against the complete id set (forward refs OK).
  for (const { id, path } of pendingLookAt) {
    if (!ids.has(id)) {
      ctx.error("UNKNOWN_LOOKAT_REF", path, `lookAt references unknown track id: "${id}"`);
    }
  }

  return ids;
}

function validateCamera(ctx: Ctx, camera: unknown, path: string): void {
  if (camera === undefined) return;
  if (!isObject(camera)) {
    ctx.error("INVALID_TYPE", path, "camera must be an object");
    return;
  }
  ctx.number(camera["fov"], `${path}/fov`);
}

function validateLookAt(ctx: Ctx, lookAt: unknown, path: string, pending: { id: string; path: string }[]): void {
  if (lookAt === undefined) return;
  if (Array.isArray(lookAt)) {
    ctx.tuple(lookAt, 3, path, "INVALID_TYPE");
    return;
  }
  if (isString(lookAt)) {
    // A track id — may be defined later; resolve after the full track pass.
    pending.push({ id: lookAt, path });
    return;
  }
  ctx.error("INVALID_TYPE", path, "lookAt must be a track id (string) or an [x,y,z] point");
}

function validateTransform(ctx: Ctx, transform: unknown, path: string): void {
  if (transform === undefined) return;
  if (!isObject(transform)) {
    ctx.error("INVALID_TYPE", path, "transform must be an object");
    return;
  }
  if (transform["position"] !== undefined) ctx.tuple(transform["position"], 3, `${path}/position`, "INVALID_TYPE");
  if (transform["rotation"] !== undefined) ctx.tuple(transform["rotation"], 4, `${path}/rotation`, "INVALID_TYPE");
  const scale = transform["scale"];
  if (scale !== undefined) {
    if (Array.isArray(scale)) ctx.tuple(scale, 3, `${path}/scale`, "INVALID_TYPE");
    else ctx.number(scale, `${path}/scale`);
  }
}

function validateKeys(ctx: Ctx, keys: unknown, path: string): void {
  if (!Array.isArray(keys) || keys.length === 0) {
    ctx.error("EMPTY_KEYS", path, "track requires at least one key");
    return;
  }
  const lastIndex = keys.length - 1;
  keys.forEach((key, ki) => {
    const base = `${path}/${ki}`;
    if (!isObject(key)) {
      ctx.error("INVALID_TYPE", base, "key must be an object");
      return;
    }
    if (key["p"] === undefined) ctx.error("MISSING_KEY_POSITION", `${base}/p`, "key requires a position p [x,y,z]");
    else ctx.tuple(key["p"], 3, `${base}/p`, "MISSING_KEY_POSITION");

    if (key["q"] === undefined) ctx.error("MISSING_KEY_ROTATION", `${base}/q`, "key requires a quaternion q [x,y,z,w]");
    else ctx.tuple(key["q"], 4, `${base}/q`, "MISSING_KEY_ROTATION");

    const duration = key["duration"];
    if (ki < lastIndex && duration === undefined) {
      ctx.error("MISSING_LEG_DURATION", `${base}/duration`, "non-final key requires a leg duration (§7.1)");
    }
    ctx.number(duration, `${base}/duration`, { min: 0, minCode: "NEGATIVE_DURATION" });
  });
}

// ── §10 events ───────────────────────────────────────────────────────────────

function validateEvents(ctx: Ctx, events: unknown, trackIds: Set<string>): void {
  if (events === undefined) return;
  if (!Array.isArray(events)) {
    ctx.error("INVALID_TYPE", "/events", "events must be an array");
    return;
  }
  events.forEach((event, ei) => {
    const base = `/events/${ei}`;
    if (!isObject(event)) {
      ctx.error("INVALID_TYPE", base, "event must be an object");
      return;
    }
    if (!isString(event["name"])) ctx.error("MISSING_EVENT_NAME", `${base}/name`, "event requires a name");
    if (event["at"] === undefined) ctx.error("MISSING_EVENT_AT", `${base}/at`, "event requires an 'at' time");
    else ctx.number(event["at"], `${base}/at`);
    ctx.number(event["span"], `${base}/span`, { min: 0, minCode: "NEGATIVE_SPAN" });

    const follow = event["follow"];
    if (follow !== undefined) {
      if (!isString(follow) || !trackIds.has(follow)) {
        ctx.error("UNKNOWN_FOLLOW_REF", `${base}/follow`, `event follows unknown track id: ${String(follow)}`);
      }
    }
  });
}

// ── §11 triggers ─────────────────────────────────────────────────────────────

function validateTriggers(ctx: Ctx, triggers: unknown, trackIds: Set<string>, _version: string | undefined): void {
  if (triggers === undefined) return;
  if (!Array.isArray(triggers)) {
    ctx.error("INVALID_TYPE", "/triggers", "triggers must be an array");
    return;
  }
  triggers.forEach((trigger, ti) => {
    const base = `/triggers/${ti}`;
    if (!isObject(trigger)) {
      ctx.error("INVALID_TYPE", base, "trigger must be an object");
      return;
    }
    const on = trigger["on"];
    if (!isString(on)) {
      ctx.error("MISSING_TRIGGER_ON", `${base}/on`, "trigger requires an 'on' input kind");
    } else if (!TRIGGER_ON_V1.has(on)) {
      // §11: players MUST ignore unknown 'on'; the validator lints it (§13).
      ctx.lint("UNKNOWN_TRIGGER_ON", `${base}/on`, `trigger 'on' value not recognized in v1: "${on}"`);
    }

    if (!isString(trigger["emit"])) ctx.error("MISSING_TRIGGER_EMIT", `${base}/emit`, "trigger requires an 'emit' signal name");

    const target = trigger["target"];
    if (target !== undefined) {
      if (!isString(target) || !trackIds.has(target)) {
        ctx.error("UNKNOWN_TRIGGER_TARGET", `${base}/target`, `trigger targets unknown track id: ${String(target)}`);
      }
    }

    const during = trigger["during"];
    if (during !== undefined) {
      if (!Array.isArray(during) || during.length !== 2 || typeof during[0] !== "number" || typeof during[1] !== "number") {
        ctx.error("INVALID_DURING", `${base}/during`, "during must be a [from, to] pair of numbers");
      } else {
        ctx.number(during[0], `${base}/during/0`);
        ctx.number(during[1], `${base}/during/1`);
        if (Number.isFinite(during[0]) && Number.isFinite(during[1]) && during[0] > during[1]) {
          ctx.lint("DURING_REVERSED", `${base}/during`, "during window is reversed (from > to)");
        }
      }
    }
  });
}

// ── §14 bundle structure ─────────────────────────────────────────────────────

function validateBundle(ctx: Ctx, mode: DeliveryMode, entries: string[] | undefined): void {
  if (mode !== "bundle" || entries === undefined) return;
  const hasRootScene = entries.some((e) => e === "scene.json");
  if (!hasRootScene) {
    ctx.error("BUNDLE_MISSING_SCENE_JSON", "", "a .vertie bundle must contain scene.json at the archive root (§14.2)");
  }
  entries.forEach((entry, i) => {
    const kind = classifySrc(entry);
    if (kind === "drive" || kind === "posix-absolute" || hasDotDotSegment(entry)) {
      ctx.error("BUNDLE_PATH_ESCAPE", `/bundle/${i}`, `archive entry escapes the bundle: "${entry}"`);
    }
  });
}
