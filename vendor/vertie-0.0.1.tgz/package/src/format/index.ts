/** The `format` layer: scene types + the pure `validateScene()` validator (B3). */
export type {
  Scene,
  Meta,
  Attribution,
  Asset,
  AssetManifest,
  Environment,
  Stage,
  StagePlane,
  Track,
  ObjectTrack,
  CameraTrack,
  Key,
  Transform,
  Extrapolate,
  Fade,
  SceneEvent,
  Trigger,
  TriggerOn,
  Vec3,
  Quat,
  Extensible,
} from "./types.js";

export {
  validateScene,
  DEFERRED_LINTS,
  type ValidationResult,
  type ValidationIssue,
  type ValidateOptions,
  type IssueCode,
  type Severity,
  type DeliveryMode,
} from "./validate.js";

export {
  isRecognizedSpdxExpression,
  KNOWN_LICENSE_IDS,
  KNOWN_LICENSE_EXCEPTIONS,
} from "./spdx.js";
