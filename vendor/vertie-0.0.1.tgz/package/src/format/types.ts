/**
 * Vertie scene document — TypeScript shape of the format described in
 * `docs/spec.md` (draft v0.3). These types describe a *well-formed* document;
 * they are the authoring/consumer surface. `validateScene()` (see `validate.ts`)
 * checks the runtime rules the type system cannot express (cross-references,
 * finiteness, cardinality) against an `unknown` input.
 *
 * The format is additive-only after 1.0 (ADR-004): every object carries an
 * open `x-*` extension namespace and players MUST ignore unknown fields, so
 * these interfaces are intentionally open (index signature for `x-*`).
 */

/** Anything under the sanctioned `x-*` extension namespace (ADR-004, §2). */
export interface Extensible {
  [key: `x-${string}`]: unknown;
}

/** A 3-component vector `[x, y, z]` (spec §7.1). */
export type Vec3 = [number, number, number];

/** A unit orientation quaternion `[x, y, z, w]`, w last (spec §7.1). */
export type Quat = [number, number, number, number];

// ── §3 meta ────────────────────────────────────────────────────────────────

/** One credit entry in the CC TASL model (spec §3.1). All fields optional. */
export interface Attribution extends Extensible {
  /** Manifest key this entry credits; omitted = scene-wide credit. */
  asset?: string;
  title?: string;
  author?: string;
  /** Source URL. */
  source?: string;
  /** SPDX license expression. */
  license?: string;
}

/** Licensing & provenance block (spec §3). Never stripped by conformant tools. */
export interface Meta extends Extensible {
  title?: string;
  description?: string;
  /** SPDX license *expression* for the scene document itself (not its assets). */
  license?: string;
  author?: string;
  attribution?: Attribution[];
  /** Canonical URL of the scene. */
  source?: string;
  /** Authoring tool + version. */
  generator?: string;
  /** ISO 8601 date or date-time. */
  created?: string;
  modified?: string;
}

// ── §4 assets ────────────────────────────────────────────────────────────────

export interface Asset extends Extensible {
  /** Absolute URL or relative path (resolved per §14). */
  src: string;
  /** SRI-style `sha256-<base64>` of the asset bytes (§4). */
  integrity?: string;
}

export type AssetManifest = Record<string, Asset>;

// ── §5 environment ───────────────────────────────────────────────────────────

export interface Environment extends Extensible {
  /** Asset key of the IBL environment map. */
  envMap?: string;
  /** Tone-mapping exposure. Default 1.0. */
  exposure?: number;
  /** `"transparent"` | `"#rrggbb"` | asset key. Default `"transparent"`. */
  background?: string;
}

// ── §9 stage ─────────────────────────────────────────────────────────────────

export interface StagePlane extends Extensible {
  width: number;
  height: number;
  /** Depth of the reference rectangle along the view axis (negative = into screen). */
  z: number;
}

export interface Stage extends Extensible {
  plane?: StagePlane;
  /** Vertical FOV of the implicit fixed camera (used when no camera track exists). */
  fov?: number;
  /** `"contain"` (default) | `"cover"`. */
  fit?: "contain" | "cover";
}

// ── §7 / §8 tracks ───────────────────────────────────────────────────────────

/** A single keyframe (spec §7.1). */
export interface Key extends Extensible {
  /** Position, world units. */
  p: Vec3;
  /** Unit orientation quaternion. */
  q: Quat;
  /** Length of the leg after this key. Required on all but the final key. */
  duration?: number;
}

/** Static base transform applied to an object asset (spec §7). */
export interface Transform extends Extensible {
  position?: Vec3;
  /** Quaternion `[x, y, z, w]`. */
  rotation?: Quat;
  /** Uniform `number` or per-axis `[x, y, z]`. Default 1. */
  scale?: number | Vec3;
}

/** Visibility outside a track's span (spec §7). */
export interface Extrapolate extends Extensible {
  before?: "hidden" | "hold";
  after?: "hidden" | "hold";
}

/** Opacity ramps at the span edges, in scene-local units (spec §7, ADR-015). */
export interface Fade extends Extensible {
  in?: number;
  out?: number;
}

/** Fields shared by object and camera tracks. */
interface TrackBase extends Extensible {
  /** Unique per document. */
  id: string;
  /** Scene-local time of the first key. Default 0. */
  start?: number;
  keys: Key[];
}

/** An object track — animates an asset (spec §7). */
export interface ObjectTrack extends TrackBase {
  role?: undefined;
  /** Manifest key of the animated asset. */
  asset: string;
  transform?: Transform;
  extrapolate?: Extrapolate;
  fade?: Fade;
}

/** The camera track — a track with a reserved role (spec §8). At most one per document. */
export interface CameraTrack extends TrackBase {
  role: "camera";
  camera?: {
    /** Vertical FOV in degrees. Default 55. */
    fov?: number;
  } & Extensible;
  /** Track id or fixed `[x, y, z]` point; derives orientation, wins over key `q`. */
  lookAt?: string | Vec3;
}

export type Track = ObjectTrack | CameraTrack;

// ── §10 events ───────────────────────────────────────────────────────────────

/** A generic named timed signal (spec §10, ADR-014). */
export interface SceneEvent extends Extensible {
  /** Author-chosen signal name, delivered verbatim to the host. */
  name: string;
  /** Scene-local time the window opens. */
  at: number;
  /** Window length. Default 0 (a point signal). */
  span?: number;
  /** Track id whose evaluated position is handed to the host while active. */
  follow?: string;
}

// ── §11 triggers ─────────────────────────────────────────────────────────────

/** v1 closed set of input kinds (spec §11). Grows additively. */
export type TriggerOn = "click" | "pointerenter" | "pointerleave";

/** A declarative input → named signal rule (spec §11, ADR-009). */
export interface Trigger extends Extensible {
  on: TriggerOn;
  /** Hit-test subject track id; omitted = whole canvas. */
  target?: string;
  /** Signal name delivered verbatim to the host. */
  emit: string;
  /** Scene-time window `[from, to]` in which the trigger is armed. */
  during?: [number, number];
  /** CSS cursor value shown while hovering the target. */
  cursor?: string;
}

// ── §2 document root ─────────────────────────────────────────────────────────

export interface Scene extends Extensible {
  /** Spec version `"major.minor"` (ADR-004). */
  vertie: string;
  meta: Meta;
  /** May be empty for camera-only scenes. */
  assets?: AssetManifest;
  environment?: Environment;
  stage?: Stage;
  /** Scene length in scene-local units. Default: derived (§2). */
  duration?: number;
  tracks: Track[];
  events?: SceneEvent[];
  triggers?: Trigger[];
}
