/**
 * Frame ↔ t arithmetic — pure, DOM-free, deterministic, unit-tested like `core`.
 *
 * The whole point of exporting from a *driver-free* timeline is that frame `i` always maps
 * to the same `t`, on any machine, at any speed. So nothing here reads a clock: timestamps
 * come from the frame index, and the wall clock is never consulted anywhere in the capture
 * loop. Two runs of the same options produce byte-identical timing.
 */
import { CaptureError } from "./types.js";

/** Microseconds per second — WebCodecs timestamps are µs integers. */
const US = 1_000_000;

export interface FramePlan {
  frames: number;
  fps: number;
  /** Wall-clock seconds the export represents. */
  duration: number;
  start: number;
  end: number;
  loop: boolean;
}

export interface FramePlanInput {
  fps?: number | undefined;
  /** Seconds. */
  duration?: number | undefined;
  /** Fallback used when `duration` is absent — the compiled scene's own length. */
  sceneDuration?: number | undefined;
  range?: readonly [number, number] | undefined;
  loop?: boolean | undefined;
}

/** Hard ceiling on a single export. 4 hours at 30 fps — a stop-the-runaway guard, not a product limit. */
const MAX_FRAMES = 432_000;

export function planFrames(input: FramePlanInput): FramePlan {
  const fps = input.fps ?? 30;
  if (!Number.isFinite(fps) || fps <= 0) {
    throw new CaptureError("config", `fps must be a positive number, got ${String(input.fps)}`);
  }

  const duration = input.duration ?? input.sceneDuration ?? 0;
  if (!Number.isFinite(duration) || duration <= 0) {
    throw new CaptureError(
      "config",
      `duration must be a positive number of seconds — got ${String(duration)}. ` +
        `The scene declares no length either, so pass \`duration\` explicitly.`,
    );
  }

  const [start, end] = input.range ?? [0, 1];
  if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || end > 1 || end <= start) {
    throw new CaptureError("config", `range must be [start, end] with 0 ≤ start < end ≤ 1, got [${start}, ${end}]`);
  }

  const frames = Math.max(1, Math.round(duration * fps));
  if (frames > MAX_FRAMES) {
    throw new CaptureError(
      "config",
      `${frames} frames (${duration}s × ${fps}fps) exceeds the ${MAX_FRAMES}-frame ceiling`,
    );
  }

  return { frames, fps, duration, start, end, loop: input.loop ?? false };
}

/**
 * The t this frame renders at.
 *
 * Non-looping: the last frame lands exactly on `end`, because a reveal that stops 1/30 of
 * the way short of its final pose looks like a bug.
 *
 * Looping: the last frame stops one step SHORT of `end`, because frame 0 and the end are
 * the same pose — writing both puts a duplicated frame at the seam, which reads as a
 * stutter every time the loop wraps.
 */
export function frameT(plan: FramePlan, index: number): number {
  const i = clampIndex(plan, index);
  const span = plan.end - plan.start;
  if (plan.frames === 1) return plan.start;
  const denom = plan.loop ? plan.frames : plan.frames - 1;
  return plan.start + (span * i) / denom;
}

/** Presentation timestamp in whole microseconds, derived from the index alone. */
export function frameTimestampUs(plan: FramePlan, index: number): number {
  return Math.round((clampIndex(plan, index) * US) / plan.fps);
}

/** How long one frame is displayed, in whole microseconds. */
export function frameDurationUs(plan: FramePlan): number {
  return Math.round(US / plan.fps);
}

/** Frames between keyframes, at least 1. */
export function keyframeEvery(plan: FramePlan, seconds: number): number {
  if (!Number.isFinite(seconds) || seconds <= 0) return 1;
  return Math.max(1, Math.round(seconds * plan.fps));
}

/**
 * A sane default bitrate: ~0.1 bits per pixel per frame, floored at 1 Mbit and capped at
 * 40 Mbit. Deliberately generous — an export is a one-off artifact people re-upload, and
 * banding in a gradient-heavy 3D scene is the thing that makes it look cheap.
 */
export function defaultBitrate(width: number, height: number, fps: number): number {
  const raw = width * height * fps * 0.1;
  return Math.round(Math.min(40_000_000, Math.max(1_000_000, raw)));
}

function clampIndex(plan: FramePlan, index: number): number {
  if (!Number.isInteger(index) || index < 0 || index >= plan.frames) {
    throw new CaptureError("config", `frame index ${index} is outside [0, ${plan.frames - 1}]`);
  }
  return index;
}
