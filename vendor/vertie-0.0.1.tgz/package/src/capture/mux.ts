/**
 * Container writing — the one place `mp4-muxer` / `webm-muxer` are touched (ADR-037).
 *
 * WebCodecs hands back encoded chunks; somebody still has to write the file around them.
 * That is exacting, silently-corrupting work (a wrong box length does not throw — it
 * produces a file some players refuse), so it is a dependency rather than our own code.
 * Both libraries are MIT and bundled into `dist/vertie.capture.js` only: the player never
 * loads this module, which is what keeps the ADR-007 core budget untouched. Their notices
 * ship in `THIRD-PARTY-NOTICES.md` and in the bundle banner, as MIT requires.
 *
 * Wrapped behind `Muxer` so the rest of capture never imports either package directly —
 * both are deprecated upstream in favour of an MPL-2.0 successor, and this seam is what
 * makes swapping (or vendoring) them a one-file change.
 */
import { ArrayBufferTarget as Mp4Target, Muxer as Mp4Muxer } from "mp4-muxer";
import { ArrayBufferTarget as WebmTarget, Muxer as WebmMuxer } from "webm-muxer";

import type { CaptureCodecName, CaptureFormat } from "./types.js";

export interface Muxer {
  readonly mimeType: string;
  add(chunk: EncodedVideoChunk, meta?: EncodedVideoChunkMetadata): void;
  finalize(): Blob;
}

export interface MuxerInput {
  format: CaptureFormat;
  codec: CaptureCodecName;
  width: number;
  height: number;
  fps: number;
}

/** MP4 codec ids `mp4-muxer` understands. */
const MP4_CODEC = { avc: "avc", av1: "av1", vp9: "vp9" } as const;
/** Matroska codec ids `webm-muxer` understands. */
const WEBM_CODEC = { vp9: "V_VP9", vp8: "V_VP8", av1: "V_AV1" } as const;

export function createMuxer(input: MuxerInput): Muxer {
  const { format, codec, width, height, fps } = input;

  if (format === "mp4") {
    const id = MP4_CODEC[codec as keyof typeof MP4_CODEC];
    const target = new Mp4Target();
    const muxer = new Mp4Muxer({
      target,
      video: { codec: id, width, height },
      // The whole file is assembled in memory anyway, so put the index up front: a
      // progressively-downloaded MP4 that cannot start until the last byte arrives is a
      // bad share link.
      fastStart: "in-memory",
      firstTimestampBehavior: "strict",
    });
    return {
      mimeType: "video/mp4",
      add: (chunk, meta) => muxer.addVideoChunk(chunk, meta),
      finalize: () => {
        muxer.finalize();
        return new Blob([target.buffer], { type: "video/mp4" });
      },
    };
  }

  const id = WEBM_CODEC[codec as keyof typeof WEBM_CODEC];
  const target = new WebmTarget();
  const muxer = new WebmMuxer({
    target,
    video: { codec: id, width, height, frameRate: fps },
    firstTimestampBehavior: "strict",
  });
  return {
    mimeType: "video/webm",
    add: (chunk, meta) => muxer.addVideoChunk(chunk, meta),
    finalize: () => {
      muxer.finalize();
      return new Blob([target.buffer], { type: "video/webm" });
    },
  };
}
