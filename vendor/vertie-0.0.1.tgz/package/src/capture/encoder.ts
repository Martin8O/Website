/**
 * The WebCodecs half of capture: negotiate a codec, encode frames, write the container.
 *
 * WebCodecs is the ONLY encode path (ADR-037). The D4 probe measured the alternative and
 * settled it: `MediaRecorder` timestamps by the wall clock, so 30 frames pushed in 54 ms
 * produced a 0.049 s file instead of a 1 s one. A fallback that silently returns a
 * wrong-length video is worse than a clear refusal, so a browser without `VideoEncoder`
 * gets `CaptureError("unsupported")` and nothing else.
 */
import { withTimeout } from "../render/timeout.js";
import { createMuxer, type Muxer } from "./mux.js";
import { codecCandidates } from "./codecs.js";
import {
  CaptureError,
  type CaptureCodecCandidate,
  type CaptureEncoderCtor,
  type CaptureEncoderLike,
  type CaptureFormat,
} from "./types.js";
import type { ScheduleFn } from "../render/schedule.js";

/** Let the encoder run this far ahead before the loop waits for it. */
const QUEUE_HIGH_WATER = 8;

export interface FrameSinkInput {
  encoder: CaptureEncoderCtor | undefined;
  format: CaptureFormat;
  width: number;
  height: number;
  fps: number;
  bitrate: number;
  frames: number;
  flushTimeoutMs: number;
  schedule: ScheduleFn;
  warn: (message: string) => void;
  signal?: AbortSignal | undefined;
}

export interface FrameSink {
  readonly candidate: CaptureCodecCandidate;
  readonly mimeType: string;
  /** Queue one frame. Takes ownership: the frame is closed here, always. */
  encode(frame: VideoFrame, keyFrame: boolean): void;
  /** Wait until the encoder is no longer running far ahead of us. */
  drain(): Promise<void>;
  /** Flush, mux and hand back the finished file. */
  finish(): Promise<Blob>;
  /** Tear down without producing a file (abort / failure path). */
  close(): void;
}

/**
 * Walk the candidate list until the browser accepts one.
 *
 * `isConfigSupported` is asked per candidate rather than assumed, because support depends
 * on the *resolution* as much as the codec — an H.264 level that carries 720p refuses
 * 1080p outright (see `codecs.ts`).
 */
export async function negotiateCodec(input: FrameSinkInput): Promise<CaptureCodecCandidate> {
  const { encoder, format, width, height, fps, bitrate } = input;
  if (!encoder) {
    throw new CaptureError(
      "unsupported",
      "vertie: video export needs the WebCodecs VideoEncoder API, which this browser does not have. " +
        "Chrome/Edge 94+, Safari 16.4+ and Firefox 130+ all support it.",
    );
  }

  const tried: string[] = [];
  for (const candidate of codecCandidates(format, width, height, fps)) {
    tried.push(candidate.codec);
    try {
      const support = await encoder.isConfigSupported({
        codec: candidate.codec,
        width,
        height,
        bitrate,
        framerate: fps,
      });
      if (support.supported === true) return candidate;
    } catch {
      // A malformed codec string throws rather than reporting `supported: false`.
      // Either way it is not usable; keep walking.
    }
  }

  throw new CaptureError(
    "no-codec",
    `vertie: no video codec this browser supports can encode ${width}×${height} @ ${fps}fps. Tried: ${tried.join(", ")}.`,
  );
}

export async function createFrameSink(input: FrameSinkInput): Promise<FrameSink> {
  const candidate = await negotiateCodec(input);
  const { width, height, fps, bitrate, frames } = input;

  if (candidate.format !== input.format) {
    input.warn(
      `vertie: ${input.format} is not encodable here, falling back to ${candidate.format} (${candidate.codec}). ` +
        `The result's \`format\` field reports what you actually got.`,
    );
  }

  const muxer: Muxer = createMuxer({ format: candidate.format, codec: candidate.name, width, height, fps });

  /** Set by the encoder's own error callback — surfaced at the next loop interaction. */
  let failure: Error | null = null;
  let closed = false;

  const Encoder = input.encoder as CaptureEncoderCtor;
  const encoder: CaptureEncoderLike = new Encoder({
    output: (chunk, meta) => {
      if (!closed) muxer.add(chunk, meta);
    },
    error: (err: DOMException) => {
      failure ??= new CaptureError("encoder", `vertie: the video encoder failed (${candidate.codec}): ${err.message}`);
    },
  });

  encoder.configure({
    codec: candidate.codec,
    width,
    height,
    bitrate,
    framerate: fps,
    // Both muxers want the container's native bitstream form, not Annex B.
    ...(candidate.name === "avc" ? { avc: { format: "avc" as const } } : {}),
  });

  const throwIfFailed = (): void => {
    if (failure) throw failure;
  };

  return {
    candidate,
    mimeType: candidate.format === "mp4" ? "video/mp4" : "video/webm",

    encode(frame, keyFrame) {
      try {
        throwIfFailed();
        encoder.encode(frame, { keyFrame });
      } finally {
        // A VideoFrame holds a GPU buffer until it is closed; leaking one per frame
        // exhausts the pool within a few seconds and stalls the whole export.
        frame.close();
      }
    },

    async drain() {
      throwIfFailed();
      // A watchdog, not a pacer: the wait itself is unbounded by nature (only the
      // encoder's own callback can lower the queue), so a stalled encoder would otherwise
      // spin here forever with no error — the C8b failure mode, one layer down from the
      // flush this guard already covers. Reading a clock here does not touch determinism:
      // frame timestamps still come from the frame index alone.
      const deadline = input.flushTimeoutMs > 0 ? Date.now() + input.flushTimeoutMs : Infinity;
      while (encoder.encodeQueueSize > QUEUE_HIGH_WATER) {
        await input.schedule();
        throwIfFailed();
        if (Date.now() > deadline) {
          throw new CaptureError(
            "timeout",
            `vertie: the video encoder stopped accepting frames — its queue has been stuck at ` +
              `${encoder.encodeQueueSize} for ${input.flushTimeoutMs} ms (${candidate.codec}, ` +
              `${width}×${height}). Try a lower resolution, or raise \`flushTimeoutMs\`.`,
          );
        }
      }
    },

    async finish() {
      throwIfFailed();
      await withTimeout(encoder.flush(), {
        ms: input.flushTimeoutMs,
        signal: input.signal,
        onSlow: (elapsed) =>
          input.warn(
            `vertie: the video encoder has been flushing ${frames} frames of ${candidate.codec} for ` +
              `${Math.round(elapsed)} ms. Still waiting — a large export legitimately takes a while.`,
          ),
        onTimeout: (elapsed) =>
          new CaptureError(
            "timeout",
            `vertie: the video encoder did not finish flushing ${frames} frames of ${candidate.codec} ` +
              `within ${input.flushTimeoutMs} ms (waited ${Math.round(elapsed)} ms). ` +
              `Raise \`flushTimeoutMs\`, or export fewer frames at a lower resolution.`,
          ),
      });
      throwIfFailed();
      encoder.close();
      closed = true;
      return muxer.finalize();
    },

    close() {
      if (closed) return;
      closed = true;
      try {
        encoder.close();
      } catch {
        // Already closed, or closed by its own error path — nothing to salvage.
      }
    },
  };
}
