/**
 * `captureScene()` — step a scene's timeline frame by frame and hand back a video file.
 *
 * Capture builds its OWN detached canvas and renderer rather than borrowing the one on the
 * page (ADR-037). Three reasons, in order of weight: the output resolution then has
 * nothing to do with the page's layout (1080p from a 400 px-wide embed); stepping t from 0
 * to 1 as fast as the encoder allows would otherwise be visible to the reader as violent
 * jitter, and any scroll of theirs would corrupt the export; and `<vertie-scene>`'s frozen
 * attribute/event contract needs no change at all. The price is a second decode and a
 * second WebGL context for the duration — the right trade for a deliberate, one-off action.
 *
 * Nothing that decides OUTPUT reads a clock. Frame `i` renders at a `t` derived from `i`
 * alone (`frames.ts`), so the same options produce the same video on any machine at any
 * speed; the only clocks anywhere are watchdogs that turn a stall into an error.
 */
import { compileScene, createSceneState, evaluate } from "../core/evaluate.js";
import { validateScene } from "../format/validate.js";
import type { Scene as VertieScene } from "../format/types.js";
import { SceneRenderer } from "../render/renderer.js";
import { createFrameSink } from "./encoder.js";
import { yieldMacrotask } from "./yield.js";
import { defaultBitrate, frameDurationUs, frameT, frameTimestampUs, keyframeEvery, planFrames } from "./frames.js";
import {
  CaptureError,
  type CaptureEnv,
  type CaptureOptions,
  type CaptureProgress,
  type CaptureResult,
  type CaptureSurface,
} from "./types.js";

/** Share of the progress bar the load phase owns — the encode loop owns the rest. */
const LOAD_SHARE = 0.1;
const FINALIZE_SHARE = 0.02;
const DEFAULT_FLUSH_TIMEOUT_MS = 30_000;

/** Can this browser export at all? Cheap, synchronous, safe to call before showing UI. */
export function captureSupport(): { webcodecs: boolean; supported: boolean } {
  const webcodecs = typeof globalThis.VideoEncoder === "function";
  return { webcodecs, supported: webcodecs };
}

export function defaultCaptureEnv(): CaptureEnv {
  return {
    encoder: typeof globalThis.VideoEncoder === "function" ? globalThis.VideoEncoder : undefined,
    createFrame: (canvas, init) => new VideoFrame(canvas, init),
    createCanvas: (width, height) => {
      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      return canvas;
    },
    createSurface: (canvas, baseUrl) =>
      new SceneRenderer(canvas, {
        // The output is exact pixels, not CSS pixels — DPR must not scale it.
        maxPixelRatio: 1,
        ...(baseUrl === undefined ? {} : { baseUrl }),
      }),
    fetchScene: async (url, signal) => {
      const res = await fetch(url, signal ? { signal } : {});
      if (!res.ok) throw new CaptureError("config", `vertie: could not fetch the scene (${res.status}) — ${url}`);
      return (await res.json()) as unknown;
    },
    documentBase: typeof document !== "undefined" ? document.baseURI : undefined,
    schedule: yieldMacrotask,
    warn: (message) => console.warn(message),
  };
}

export async function captureScene(options: CaptureOptions): Promise<CaptureResult> {
  const env: CaptureEnv = { ...defaultCaptureEnv(), ...options.env };
  const signal = options.signal;
  const started = Date.now();

  const width = Math.max(2, Math.floor(options.width ?? 1280));
  const height = Math.max(2, Math.floor(options.height ?? 720));
  // Both H.264 and VP9 encode in 4:2:0, where an odd dimension has no chroma sample to
  // pair with — encoders either refuse it or silently crop. Round rather than surprise.
  if (width % 2 !== 0 || height % 2 !== 0) {
    throw new CaptureError("config", `vertie: width and height must be even, got ${width}×${height}`);
  }

  throwIfAborted(signal);

  // ── the scene ──────────────────────────────────────────────────────────────
  let sceneDoc: VertieScene;
  let assetBase = options.assets;
  if (typeof options.scene === "string") {
    const url = options.scene;
    sceneDoc = (await env.fetchScene(url, signal)) as VertieScene;
    // Relative asset paths resolve against the SCENE document (§14.1), exactly as the
    // element does — a scene hosted apart from the page must still find its assets.
    assetBase ??= url;
  } else {
    sceneDoc = options.scene;
  }
  throwIfAborted(signal);

  const validation = validateScene(sceneDoc);
  if (!validation.valid) {
    const codes = validation.errors.map((issue) => issue.code);
    throw new CaptureError(
      "invalid-scene",
      `vertie: cannot export an invalid scene (${codes.join(", ")})`,
      validation.errors.map((issue) => `${issue.code} at ${issue.path || "<root>"}: ${issue.message}`),
    );
  }

  const compiled = compileScene(sceneDoc);
  const plan = planFrames({
    fps: options.fps,
    duration: options.duration,
    sceneDuration: compiled.duration,
    range: options.range,
    loop: options.loop,
  });

  const fps = plan.fps;
  const bitrate = options.bitrate ?? defaultBitrate(width, height, fps);
  const keyEvery = keyframeEvery(plan, options.keyframeInterval ?? 2);
  const frameDuration = frameDurationUs(plan);

  const report = (phase: CaptureProgress["phase"], frame: number, progress: number): void => {
    options.onProgress?.({ phase, frame, frames: plan.frames, progress });
  };

  // ── the detached renderer ──────────────────────────────────────────────────
  const canvas = env.createCanvas(width, height);
  const composite = options.background === undefined ? null : make2d(env, width, height, options.background);
  let surface: CaptureSurface | null = null;
  let sink: Awaited<ReturnType<typeof createFrameSink>> | null = null;

  try {
    report("load", 0, 0);
    surface = env.createSurface(canvas, absoluteBase(assetBase, env.documentBase));
    surface.resize(width, height);
    await surface.load(sceneDoc, signal ? { signal } : {});
    throwIfAborted(signal);
    // Compile shaders and upload textures before the clock matters, so frame 0 is not an
    // outlier that eats the whole flush budget.
    await surface.warm?.();
    throwIfAborted(signal);
    report("load", 0, LOAD_SHARE);

    sink = await createFrameSink({
      encoder: env.encoder,
      format: options.format ?? "mp4",
      width,
      height,
      fps,
      bitrate,
      frames: plan.frames,
      flushTimeoutMs: options.flushTimeoutMs ?? DEFAULT_FLUSH_TIMEOUT_MS,
      schedule: env.schedule,
      warn: env.warn,
      signal,
    });

    // ── the loop ─────────────────────────────────────────────────────────────
    const state = createSceneState(compiled);
    const encodeShare = 1 - LOAD_SHARE - FINALIZE_SHARE;
    for (let i = 0; i < plan.frames; i++) {
      throwIfAborted(signal);

      evaluate(compiled, frameT(plan, i), state);
      surface.apply(state);
      surface.render();

      const source = composite ? blit(composite, canvas, width, height) : canvas;
      // Constructed in the SAME task as `render()`. The D4 probe proved this captures
      // correctly without `preserveDrawingBuffer` (RGBX readback matched the drawn colour
      // exactly), so capture pays none of that flag's cost.
      const frame = env.createFrame(source, {
        timestamp: frameTimestampUs(plan, i),
        duration: frameDuration,
      });
      sink.encode(frame, i % keyEvery === 0);

      await sink.drain();
      await env.schedule();
      report("encode", i + 1, LOAD_SHARE + (encodeShare * (i + 1)) / plan.frames);
    }

    report("finalize", plan.frames, 1 - FINALIZE_SHARE);
    const candidate = sink.candidate;
    const blob = await sink.finish();
    sink = null;
    report("finalize", plan.frames, 1);

    return {
      blob,
      mimeType: blob.type,
      // What we actually got, which is not always what was asked for: a browser that
      // cannot encode H.264 still produces a WebM rather than nothing.
      format: candidate.format,
      codec: candidate.codec,
      width,
      height,
      fps,
      frames: plan.frames,
      duration: plan.frames / fps,
      elapsedMs: Date.now() - started,
    };
  } finally {
    sink?.close();
    surface?.dispose();
  }
}

/**
 * Make the asset base absolute before it reaches the renderer.
 *
 * `SceneRenderer` resolves every asset with `new URL(src, baseUrl)`, and that throws
 * outright on a relative base — so handing it the scene's own `src` verbatim breaks for
 * the most ordinary case there is: `scene: "/demo/scene.json"`. (Found live, not by a
 * unit test: every test until then passed an absolute URL.) The element normalises the
 * same way against `baseURI`; this is its counterpart on the capture side.
 */
function absoluteBase(base: string | undefined, docBase: string | undefined): string | undefined {
  if (base === undefined) return undefined;
  try {
    return new URL(base, docBase).href;
  } catch {
    // No document to resolve against (node), or genuinely malformed. An absolute URL
    // still parses without a base, so anything reaching here is relative and unresolvable
    // — say so rather than letting three throw the same error one layer deeper.
    throw new CaptureError(
      "config",
      `vertie: could not resolve the asset base "${base}" — pass an absolute URL via \`assets\`.`,
    );
  }
}

/** A 2D canvas used to put an opaque background under a scene that renders transparent. */
function make2d(env: CaptureEnv, width: number, height: number, background: string): { canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D; background: string } {
  const canvas = env.createCanvas(width, height);
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new CaptureError("config", "vertie: could not get a 2D context for the background composite");
  return { canvas, ctx, background };
}

function blit(
  target: { canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D; background: string },
  source: HTMLCanvasElement,
  width: number,
  height: number,
): HTMLCanvasElement {
  target.ctx.fillStyle = target.background;
  target.ctx.fillRect(0, 0, width, height);
  target.ctx.drawImage(source, 0, 0, width, height);
  return target.canvas;
}

function throwIfAborted(signal: AbortSignal | undefined): void {
  if (!signal?.aborted) return;
  if (signal.reason !== undefined) throw signal.reason;
  const err = new Error("vertie: capture aborted");
  err.name = "AbortError";
  throw err;
}
