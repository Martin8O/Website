/**
 * Codec negotiation — pure, so the ordering rules are unit-testable without WebCodecs.
 *
 * The list is not a constant, because H.264's codec string encodes a **level**, and a
 * level too low for the requested resolution is rejected outright: `avc1.42001f`
 * (baseline 3.1) is fine for 720p and cannot carry 1080p at all. So the level is computed
 * from the actual frame size and frame rate, and only then are profiles tried in
 * descending quality order.
 */
import type { CaptureCodecCandidate, CaptureFormat } from "./types.js";

/**
 * H.264 levels: `[id, hex, maxMacroblocksPerSecond, maxFrameMacroblocks]`, ascending
 * (Rec. H.264 Table A-1). Only the levels a browser encoder realistically offers.
 */
const AVC_LEVELS: readonly [string, string, number, number][] = [
  ["3.0", "1e", 40_500, 1_620],
  ["3.1", "1f", 108_000, 3_600],
  ["3.2", "20", 216_000, 5_120],
  ["4.0", "28", 245_760, 8_192],
  ["4.2", "2a", 522_240, 8_704],
  ["5.0", "32", 589_824, 22_080],
  ["5.1", "33", 983_040, 36_864],
  ["5.2", "34", 2_073_600, 36_864],
  ["6.0", "3c", 4_177_920, 139_264],
];

/** Profile prefixes, best first: High → Main → Constrained Baseline. */
const AVC_PROFILES = ["6400", "4d00", "42e0"] as const;

/** The smallest H.264 level that can carry this frame size and rate. */
export function avcLevelHex(width: number, height: number, fps: number): string {
  const frameMb = Math.ceil(width / 16) * Math.ceil(height / 16);
  const mbps = frameMb * fps;
  for (const [, hex, maxMbps, maxFs] of AVC_LEVELS) {
    if (frameMb <= maxFs && mbps <= maxMbps) return hex;
  }
  // Beyond every tabulated level: ask for the highest and let the encoder refuse.
  return AVC_LEVELS[AVC_LEVELS.length - 1]![1];
}

/**
 * The ordered list to negotiate through for a requested container.
 *
 * The requested format's codecs come first, then the other container's — a browser that
 * cannot encode H.264 should still produce a WebM rather than nothing, and the caller
 * learns which it got from `CaptureResult.format`.
 */
export function codecCandidates(format: CaptureFormat, width: number, height: number, fps: number): CaptureCodecCandidate[] {
  const level = avcLevelHex(width, height, fps);
  const mp4: CaptureCodecCandidate[] = [
    ...AVC_PROFILES.map((profile) => ({ name: "avc" as const, codec: `avc1.${profile}${level}`, format: "mp4" as const })),
    { name: "av1", codec: "av01.0.08M.08", format: "mp4" },
  ];
  const webm: CaptureCodecCandidate[] = [
    { name: "vp9", codec: "vp09.00.10.08", format: "webm" },
    { name: "vp8", codec: "vp8", format: "webm" },
  ];
  return format === "mp4" ? [...mp4, ...webm] : [...webm, ...mp4];
}
