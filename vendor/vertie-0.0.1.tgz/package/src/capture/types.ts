/**
 * The `capture` layer's contract (D4, ADR-037).
 *
 * Capture sits BESIDE `element`, above `core` + `render`: it owns its own detached canvas
 * and renderer, steps the timeline frame by frame and hands back a finished video file.
 * It imports nothing from `element` (and `element` imports nothing from here) — the two
 * are siblings, which is what keeps capture out of the core bundle entirely.
 */
import type { SceneState } from "../core/types.js";
import type { Scene as VertieScene } from "../format/types.js";
import type { SceneLoadOptions } from "../render/loading.js";
import type { ScheduleFn } from "../render/schedule.js";

/** Container we write. MP4 is the default: it is what social platforms accept. */
export type CaptureFormat = "mp4" | "webm";

/** Codec family, independent of the exact WebCodecs string. */
export type CaptureCodecName = "avc" | "av1" | "vp9" | "vp8";

/** One entry in the negotiation list: a WebCodecs codec string and the container it belongs in. */
export interface CaptureCodecCandidate {
  name: CaptureCodecName;
  /** The `VideoEncoderConfig.codec` string. */
  codec: string;
  format: CaptureFormat;
}

export type CapturePhase = "load" | "encode" | "finalize";

export interface CaptureProgress {
  phase: CapturePhase;
  /** Frames written so far. */
  frame: number;
  /** Total frames this capture will write. */
  frames: number;
  /** 0..1 over the whole operation, load included. */
  progress: number;
}

/**
 * Every way a capture can fail, named. Nothing here degrades silently: a browser without
 * `VideoEncoder` gets `unsupported` immediately rather than a worse file (the D4 probe
 * proved a `MediaRecorder` fallback cannot produce a correct-length video at all), and a
 * stalled encoder gets `timeout` rather than a hang (the C8b discipline).
 */
export type CaptureErrorCode =
  | "config"
  | "unsupported"
  | "no-codec"
  | "invalid-scene"
  | "encoder"
  | "timeout";

export class CaptureError extends Error {
  readonly code: CaptureErrorCode;
  /** Present on `invalid-scene`: the validator's messages, already formatted. */
  readonly details: string[];

  constructor(code: CaptureErrorCode, message: string, details: string[] = []) {
    super(message);
    this.name = "CaptureError";
    this.code = code;
    this.details = details;
  }
}

/**
 * The slice of the render layer capture drives. Deliberately its OWN interface rather than
 * an import from `element`: `SceneRenderer` satisfies both structurally, and a test can
 * satisfy this one with a stub — no three, no GPU, no canvas.
 */
export interface CaptureSurface {
  load(scene: VertieScene, options?: SceneLoadOptions): Promise<void>;
  warm?(): Promise<void>;
  apply(state: SceneState): void;
  render(): void;
  resize(width: number, height: number): void;
  dispose(): void;
}

/** What the encoder half needs from the platform; injectable so tests need no WebCodecs. */
export interface CaptureEncoderLike {
  configure(config: VideoEncoderConfig): void;
  encode(frame: VideoFrame, options?: VideoEncoderEncodeOptions): void;
  flush(): Promise<void>;
  close(): void;
  readonly encodeQueueSize: number;
}

export interface CaptureEncoderCtor {
  new (init: VideoEncoderInit): CaptureEncoderLike;
  isConfigSupported(config: VideoEncoderConfig): Promise<VideoEncoderSupport>;
}

/**
 * Capture's window seam — the same idea as `VertieSceneEnv`, scoped to what capture
 * touches. Not a public extension point; it exists so the whole layer is testable in node
 * and drivable in a hidden tab.
 */
export interface CaptureEnv {
  /** `undefined` ⟹ this browser cannot export (→ `CaptureError("unsupported")`). */
  encoder: CaptureEncoderCtor | undefined;
  /** Wraps a canvas into an encodable frame. */
  createFrame(canvas: HTMLCanvasElement, init: VideoFrameInit): VideoFrame;
  createCanvas(width: number, height: number): HTMLCanvasElement;
  createSurface(canvas: HTMLCanvasElement, baseUrl: string | undefined): CaptureSurface;
  fetchScene(url: string, signal?: AbortSignal): Promise<unknown>;
  /**
   * The page's base URL, used to make a relative scene/asset path absolute before the
   * renderer resolves against it. `undefined` outside a document (node).
   */
  documentBase: string | undefined;
  /** Hand the main thread back between frames — an export must not freeze the page. */
  schedule: ScheduleFn;
  warn(message: string): void;
}

export interface CaptureOptions {
  /** The scene document, or a URL to fetch it from. */
  scene: VertieScene | string;
  /** Base URL for relative asset `src` (§14.1). Default: the scene document's URL. */
  assets?: string;
  /** Output width in pixels. Default 1280. */
  width?: number;
  /** Output height in pixels. Default 720. */
  height?: number;
  /** Frames per second. Default 30. */
  fps?: number;
  /** Wall-clock length in SECONDS. Default: the compiled scene's own length (as D1 does). */
  duration?: number;
  /** Sub-range of the timeline to render, t ∈ [0..1]. Default `[0, 1]`. */
  range?: readonly [number, number];
  /**
   * True ⟹ the export is meant to loop: the last frame stops one step SHORT of the end,
   * so playing it back on repeat has no duplicated seam frame.
   */
  loop?: boolean;
  /** Container. Default `"mp4"`. */
  format?: CaptureFormat;
  /** Target bitrate in bits per second. Default: derived from resolution and fps. */
  bitrate?: number;
  /**
   * CSS colour painted behind the scene, e.g. `"#ffffff"`.
   *
   * A Vertie scene renders onto a transparent canvas, and video has no alpha channel — so
   * by default everything the scene does not cover encodes as black. Set this when the
   * scene was composed against a light page, or the export will look broken. Costs one
   * full-frame blit per frame.
   */
  background?: string;
  /** Seconds between keyframes. Default 2. */
  keyframeInterval?: number;
  signal?: AbortSignal;
  onProgress?: (progress: CaptureProgress) => void;
  /** Budget for the encoder's final flush, in ms. Default 30 000; `0` disables. */
  flushTimeoutMs?: number;
  /** Test/verification seam. */
  env?: Partial<CaptureEnv>;
}

export interface CaptureResult {
  blob: Blob;
  mimeType: string;
  format: CaptureFormat;
  /** The WebCodecs codec string that was actually negotiated. */
  codec: string;
  width: number;
  height: number;
  fps: number;
  frames: number;
  /**
   * Length in seconds, computed as `frames / fps` — our own truth.
   *
   * ⚠ A WebM container's own `Duration` header reports the LAST FRAME'S TIMESTAMP
   * (`(frames−1)/fps`), because Matroska stores no duration for the final block. Every
   * frame is present and plays at the right time; only that one metadata field is a frame
   * short. MP4 reports the full length, which is one more reason it is the default.
   */
  duration: number;
  /** Wall-clock ms the whole capture took. */
  elapsedMs: number;
}
