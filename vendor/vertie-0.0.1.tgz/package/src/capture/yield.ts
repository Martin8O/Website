/**
 * Capture's yield — deliberately NOT `render/schedule.ts`'s `yieldToBrowser`.
 *
 * That one prefers `scheduler.yield()`, which is right for the decode pipeline: it hands
 * the thread back and then **resumes at continuation priority**, ahead of ordinary tasks,
 * so a load finishes promptly. In the encode loop that behaviour is a livelock, and it was
 * found the only way it could be — by running a real export.
 *
 * The backpressure loop waits for `encodeQueueSize` to fall, and the only thing that can
 * lower it is `VideoEncoder`'s own output callback, which arrives as an ordinary task.
 * Yielding at continuation priority jumps that queue: the loop resumes, finds the queue
 * still full, yields again, and the callback it is waiting for never gets a slot. The page
 * pegs one core and nothing ever completes.
 *
 * A `MessageChannel` message is a plain macrotask with no priority boost, so anything
 * already queued — the encoder's callbacks included — runs first. It is also not subject
 * to the background-tab timer throttling that would otherwise cripple `setTimeout(0)`
 * (Chrome clamps chained timers to ~1/min in a long-hidden tab, which is exactly the
 * preview pane every verification here runs in).
 */

/** Hand the thread back at ordinary priority and come back after the existing queue. */
export function yieldMacrotask(): Promise<void> {
  if (typeof MessageChannel === "function") {
    return new Promise((resolve) => {
      const channel = new MessageChannel();
      channel.port1.onmessage = (): void => {
        channel.port1.close();
        channel.port2.close();
        resolve();
      };
      channel.port2.postMessage(0);
    });
  }
  return new Promise((resolve) => setTimeout(resolve, 0));
}
