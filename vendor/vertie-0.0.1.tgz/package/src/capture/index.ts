/**
 * The `capture` layer (D4, ADR-037) — a Vertie scene in, a finished video file out.
 *
 * Published as the SEPARATE entry `vertie/capture` (`dist/vertie.capture.js`), never from
 * the package root. That is not tidiness: the muxers this layer bundles would otherwise
 * land in every embed on the web, and the ADR-007 core budget (≤ 90 kB gz excl. three)
 * would pay for a feature almost no page uses. `element` does not import this, and this
 * does not import `element`.
 *
 *   import { captureScene, captureSupport } from "vertie/capture";
 *
 *   const { blob } = await captureScene({ scene: "/scene.json", width: 1920, height: 1080 });
 *
 * There is exactly one encode path: WebCodecs. The D4 probe measured `MediaRecorder` and
 * ruled it out — it timestamps by the wall clock, so a fast export yields a video that is
 * correct frame by frame but a fraction of its intended length. A browser without
 * `VideoEncoder` therefore gets `CaptureError("unsupported")`, not a worse file.
 */
export { captureScene, captureSupport, defaultCaptureEnv } from "./recorder.js";

export { CaptureError } from "./types.js";
export type {
  CaptureOptions,
  CaptureResult,
  CaptureProgress,
  CapturePhase,
  CaptureFormat,
  CaptureCodecName,
  CaptureCodecCandidate,
  CaptureErrorCode,
  CaptureEnv,
  CaptureSurface,
  CaptureEncoderLike,
  CaptureEncoderCtor,
} from "./types.js";

export { planFrames, frameT, frameTimestampUs, frameDurationUs, keyframeEvery, defaultBitrate } from "./frames.js";
export type { FramePlan, FramePlanInput } from "./frames.js";

export { codecCandidates, avcLevelHex } from "./codecs.js";
