/**
 * Vertie package entry point — the five layers, in dependency order:
 *   - `format`  — scene types + the `validateScene()` validator (B3). Pure, DOM-free.
 *   - `core`    — the deterministic scene evaluator: scene + t → poses (C2). Pure, DOM-free.
 *   - `drivers` — input → progress t ∈ [0..1]; scroll first (C4). DOM, three-free.
 *   - `render`  — the three.js/WebGL renderer: `SceneState` → pixels (C3). Needs three (peer).
 *   - `element` — `<vertie-scene>`, the drop-in player (C5). Registers on import.
 *
 * NB importing this entry registers the custom element (guarded: a no-op without
 * `customElements`) — the one-line embed has no host JS to call `defineVertieScene()`.
 */
export * from "./format/index.js";
export * from "./core/index.js";
export * from "./drivers/index.js";
export * from "./render/index.js";
export * from "./element/index.js";
