/**
 * VRAM estimation (ADR-007: on mobile, resident texture memory — not download size —
 * is the binding constraint). A rough, pure byte estimate exposed on the debug hook so
 * a later perf pass can act on real numbers. The renderer sums geometry bytes from the
 * three.js buffers directly; the non-trivial part is textures, where the codec and
 * mip chain change the resident cost by ~4×, so that lives here and is unit-tested.
 *
 * These are estimates, not GPU truth (drivers pad/align, compress differently). C3 ships
 * the measurement foundation; the adaptive-quality downshift policy is a later prompt.
 */

export interface TextureVramInput {
  width: number;
  height: number;
  /** Bytes per texel for an *uncompressed* texture. Default 4 (RGBA8). */
  bytesPerPixel?: number;
  /** GPU-compressed (KTX2/Basis → ETC/BC/ASTC): ~1 byte/texel, not 4. */
  compressed?: boolean;
  /** Whether a full mip chain is resident (+~1/3 the base level). */
  mipmaps?: boolean;
}

/** Rough resident bytes for one texture (ADR-007: ~1× for KTX2 vs ~4× uncompressed). */
export function estimateTextureBytes(t: TextureVramInput): number {
  const w = Math.max(0, Math.floor(t.width));
  const h = Math.max(0, Math.floor(t.height));
  const perTexel = t.compressed ? 1 : (t.bytesPerPixel ?? 4);
  let bytes = w * h * perTexel;
  if (t.mipmaps) bytes = Math.round(bytes * (4 / 3));
  return bytes;
}
