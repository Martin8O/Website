/**
 * Reading a glTF document's header without decoding it (C8b).
 *
 * When a decode times out we want to say *why* it probably hung, and the answer is in the
 * asset itself: `extensionsUsed` names the extensions the file needs, and exactly two of
 * them — `KHR_draco_mesh_compression` and `KHR_texture_basisu` — pull a decoder payload
 * over the network and can therefore hang. Naming them (and their decoder URL) turns
 * "it stopped at decoding" into a one-line diagnosis.
 *
 * Pure and three-free, like `sniff.ts` next to it. This runs ONLY on the failure path, so
 * it may parse the whole JSON chunk; the happy path never calls it.
 */

/** `extensionsUsed` from a GLB's JSON chunk or a text glTF document; `[]` if unreadable. */
export function gltfExtensionsUsed(input: ArrayBuffer | Uint8Array): string[] {
  const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
  try {
    const json = gltfJsonText(bytes);
    if (json === null) return [];
    const doc: unknown = JSON.parse(json);
    const used = (doc as { extensionsUsed?: unknown } | null)?.extensionsUsed;
    if (!Array.isArray(used)) return [];
    return used.filter((name): name is string => typeof name === "string");
  } catch {
    // A truncated download, a decoder that got HTML, a `.gltf` we cannot parse — the
    // diagnosis is a courtesy, it may never become a second failure of its own.
    return [];
  }
}

/** GLB header: 'glTF' magic · version · total length, then length/type-tagged chunks. */
const GLB_MAGIC = 0x46546c67; // 'glTF', little-endian u32
const CHUNK_JSON = 0x4e4f534a; // 'JSON'
const GLB_HEADER_BYTES = 12;
const CHUNK_HEADER_BYTES = 8;

/** The JSON text of a glTF document — chunk 0 of a GLB, or the whole file when it is text. */
function gltfJsonText(bytes: Uint8Array): string | null {
  const decoder = new TextDecoder();
  if (bytes.byteLength < GLB_HEADER_BYTES) return null;

  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (view.getUint32(0, true) !== GLB_MAGIC) return decoder.decode(bytes); // text .gltf

  const chunkLength = view.getUint32(GLB_HEADER_BYTES, true);
  const chunkType = view.getUint32(GLB_HEADER_BYTES + 4, true);
  if (chunkType !== CHUNK_JSON) return null;
  const start = GLB_HEADER_BYTES + CHUNK_HEADER_BYTES;
  if (start + chunkLength > bytes.byteLength) return null;
  return decoder.decode(bytes.subarray(start, start + chunkLength));
}
