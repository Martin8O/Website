/**
 * Where the Draco/Basis decoder payloads (WASM + their JS wrappers) come from.
 *
 * C3 shipped a hand-pinned jsDelivr URL as the default. C7 removes it: a production
 * embed must not depend on a third-party origin, and a hand-pinned version is a silent
 * drift waiting to happen (bump three, forget the string, decode against the wrong
 * decoder). Two build shapes, two correct answers:
 *
 *  - **npm / bundler build** (`vertie.js`, three EXTERNAL): return `undefined` and let
 *    three resolve its own payloads. Since r165 `DRACOLoader`/`KTX2Loader` default their
 *    URLs to `new URL('../libs/…', import.meta.url)` — they follow whichever copy of
 *    three the page actually loaded, so the version always matches and a bundler emits
 *    the payloads as its own assets. Nothing to configure, nothing to pin.
 *
 *  - **standalone build** (`vertie.standalone.js`, three INLINED): inlining breaks that
 *    link — three's module URL is now *our* bundle. So that build ships its own copy of
 *    the payloads in `dist/decoders/` and points at them relative to `import.meta.url`,
 *    which resolves to the same origin/CDN path the bundle itself was served from.
 *
 * `SceneRendererOptions.decoderPath` overrides both (self-hosting elsewhere, an offline
 * kiosk, a custom decoder build).
 */

/** Build-time flag: true only in the standalone bundle (see `vite.standalone.config.ts`). */
declare const __VERTIE_SELF_HOSTED_DECODERS__: boolean | undefined;

/** Directory (inside `dist/`) holding the shipped payloads: `draco/` + `basis/`. */
export const SELF_HOSTED_DECODER_DIR = "decoders/";

/**
 * The decoder base URL for this build, or `undefined` to let three resolve its own.
 * The trailing slash is part of the contract — callers append `draco/` / `basis/`.
 */
export function defaultDecoderPath(): string | undefined {
  const selfHosted =
    typeof __VERTIE_SELF_HOSTED_DECODERS__ !== "undefined" && __VERTIE_SELF_HOSTED_DECODERS__;
  if (!selfHosted) return undefined;
  return new URL(SELF_HOSTED_DECODER_DIR, import.meta.url).href;
}

// ── diagnosing a decode that never came back (C8b) ───────────────────────────
//
// Only two glTF extensions fetch a decoder payload at runtime, and they are the only two
// that can hang: everything else three needs is already in the module graph (meshopt's
// decoder is a plain import, and the KHR_* material/transform extensions are code).

/** Where each payload-fetching extension gets its decoder from. */
export interface DecoderSources {
  /** Effective URL of the Draco wrapper (`DRACOLoader.decoderPaths.js`). */
  draco: string;
  /** Effective base of the Basis/KTX2 transcoder, or three's own when unset. */
  ktx2: string;
}

/** glTF extension → which decoder payload it needs. */
export const PAYLOAD_EXTENSIONS: Record<string, keyof DecoderSources> = {
  KHR_draco_mesh_compression: "draco",
  KHR_texture_basisu: "ktx2",
};

export interface DecodeTimeoutInfo {
  /** Track id, or `"environment"`. */
  id: string;
  /** The asset URL being decoded. */
  url: string;
  /** Budget that ran out (ms). */
  ms: number;
  /** `extensionsUsed` of the asset, when it could be read (empty for the env map). */
  extensions: readonly string[];
  sources: DecoderSources;
}

/**
 * The message a hung decode gets. It names the asset, the decoder payload that most
 * likely never became a working worker, and the one check that settles it — because the
 * failure looks identical from the outside no matter which of the two decoders stalled.
 */
export function describeDecodeTimeout(info: DecodeTimeoutInfo, stalled = false): string {
  const what = stalled
    ? `vertie: still decoding ${info.id} after ${Math.round(info.ms)} ms`
    : `vertie: decode of ${info.id} timed out after ${Math.round(info.ms)} ms`;

  const needed = [...new Set(info.extensions.map((ext) => PAYLOAD_EXTENSIONS[ext]).filter(Boolean))];
  const suspects = (needed.length > 0 ? needed : (["draco", "ktx2"] as const)) as (keyof DecoderSources)[];
  const list = suspects.map((key) => `${key} → ${info.sources[key]}`).join(" · ");
  const via =
    needed.length > 0
      ? `The asset uses ${info.extensions.filter((e) => PAYLOAD_EXTENSIONS[e]).join(", ")}, so its decoder payload had to be fetched: ${list}.`
      : `If it is compressed, a decoder payload had to be fetched: ${list}.`;

  return [
    `${what} — ${info.url}.`,
    via,
    "three builds a worker from whatever that URL returns and never reports back if it is not the decoder",
    "(a dev server answering index.html with status 200 is the classic case), so the load hangs silently.",
    "Check that URL in the network log, or raise `decodeTimeoutMs` if the device is simply slow.",
  ].join(" ");
}
