/**
 * The yield seam (C4b): hand the main thread back between decode units.
 *
 * A decode is a long task. Three decodes back-to-back are one *very* long task, and a
 * long task means the scroll driver's rAF (and the browser's own input handling) waits.
 * Awaiting `yieldToBrowser()` between units breaks the work into pieces the scheduler
 * can interleave with a frame.
 *
 * Preference order: `scheduler.yield()` (continues at user-visible priority, so the work
 * resumes promptly but after pending input/rendering) → `requestIdleCallback` (with a
 * timeout so a busy page cannot starve the load) → `setTimeout(0)` (universal floor,
 * also the path node takes in tests).
 */

/** Injectable yield function — the pipeline never calls the global directly. */
export type ScheduleFn = () => Promise<void>;

/** Cap on how long an idle yield may wait before the load continues regardless. */
const IDLE_TIMEOUT_MS = 50;

interface SchedulerLike {
  yield?: () => Promise<void>;
}

type IdleCallback = (callback: () => void, options?: { timeout: number }) => number;

export function yieldToBrowser(): Promise<void> {
  const scheduler = (globalThis as { scheduler?: SchedulerLike }).scheduler;
  if (typeof scheduler?.yield === "function") return scheduler.yield();

  const idle = (globalThis as { requestIdleCallback?: IdleCallback }).requestIdleCallback;
  if (typeof idle === "function") {
    return new Promise((resolve) => idle(() => resolve(), { timeout: IDLE_TIMEOUT_MS }));
  }

  return new Promise((resolve) => setTimeout(resolve, 0));
}
