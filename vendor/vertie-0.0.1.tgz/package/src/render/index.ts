/**
 * The `render` layer: the one three.js/WebGL renderer (ADR-010) that turns evaluated
 * `SceneState` poses into pixels.
 *
 * `format` → `core` → drivers → **`render` (this)** → element. This is the first and
 * only place three.js enters the codebase; three (and `three/examples/jsm/*`) is a
 * peer dependency, external to the core bundle. The public face is `<vertie-scene>`
 * (C5), which wraps `SceneRenderer`; these exports are the layer boundary it consumes.
 */
export { SceneRenderer } from "./renderer.js";
export type { SceneRendererOptions, SceneRendererDebug } from "./renderer.js";

export { ScenePreloader, defaultPreloaderEnv, DEFAULT_ROOT_MARGIN } from "./preload.js";
export type {
  PreloadPhase,
  PreloadTarget,
  ScenePreloaderOptions,
  ScenePreloaderEnv,
  ScenePreloaderDebug,
} from "./preload.js";

export type { LoadProgressEvent, SceneLoadOptions } from "./loading.js";
export { yieldToBrowser, type ScheduleFn } from "./schedule.js";
export { fetchBytes, type BytesProgress, type FetchBytesOptions } from "./fetch.js";

export {
  createLoaderBundle,
  loadGltf,
  parseGltf,
  loadEquirect,
  type LoaderBundle,
} from "./assets.js";
export { defaultDecoderPath, SELF_HOSTED_DECODER_DIR } from "./decoders.js";

export { boxToNdc, ndcToBox, projectPoint, pickTrack } from "./pick.js";
export type { ScreenPoint, PickResult, PickCandidate } from "./pick.js";

export {
  stageCameraPose,
  DEFAULT_STAGE_FOV,
  frustumClampScale,
  NO_FRUSTUM_CLAMP,
  DEFAULT_CLAMP_MARGIN,
  type StageCamera,
  type FrustumClamp,
} from "./stage.js";
export { sniffKindFromUrl, sniffKindFromBytes, resolveAssetKind, type AssetKind } from "./sniff.js";
export { estimateTextureBytes, type TextureVramInput } from "./vram.js";
