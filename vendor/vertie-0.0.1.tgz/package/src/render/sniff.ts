/**
 * Asset-kind detection (spec §4: "asset kind is inferred from content, not from the
 * key"). Two pure functions — one from the URL/extension (cheap, the common path) and
 * one from the leading bytes (authoritative, used when the extension is absent or
 * untrustworthy). No DOM, no three: trivially unit-testable.
 */

/** The asset kinds the render layer routes to a loader. */
export type AssetKind = "gltf" | "ktx2" | "hdr" | "image" | "unknown";

/** Kind from a URL/path extension (ignores query + fragment). */
export function sniffKindFromUrl(url: string): AssetKind {
  const path = url.split(/[?#]/, 1)[0] ?? url;
  const dot = path.lastIndexOf(".");
  if (dot < 0) return "unknown";
  switch (path.slice(dot + 1).toLowerCase()) {
    case "glb":
    case "gltf":
      return "gltf";
    case "ktx2":
      return "ktx2";
    case "hdr":
      return "hdr";
    case "png":
    case "jpg":
    case "jpeg":
    case "webp":
    case "avif":
      return "image";
    default:
      return "unknown";
  }
}

/**
 * Kind from the URL, falling back to the bytes when the URL cannot say (C8).
 *
 * Not every URL has a path to read an extension from. An object URL (`blob:…`) — how a
 * page plays a file the user just dropped — is a bare UUID, and so is many a CDN's
 * content-addressed path; `data:` URIs have no path at all. The extension check answers
 * "unknown" for all of them, which is exactly the case the byte sniffer exists for
 * (spec §4: the kind comes from the content, not the key).
 *
 * `readBytes` is only called when it is actually needed, so the common path (a real
 * filename) still costs nothing.
 */
export async function resolveAssetKind(
  url: string,
  readBytes: (url: string) => Promise<ArrayBuffer>,
): Promise<{ kind: AssetKind; bytes?: ArrayBuffer }> {
  const fromUrl = sniffKindFromUrl(url);
  if (fromUrl !== "unknown") return { kind: fromUrl };
  const bytes = await readBytes(url);
  return { kind: sniffKindFromBytes(new Uint8Array(bytes)), bytes };
}

const startsWith = (bytes: Uint8Array, sig: readonly number[]): boolean =>
  bytes.length >= sig.length && sig.every((b, i) => bytes[i] === b);

// KTX2: «KTX 20»\r\n\x1A\n  ·  GLB: "glTF"  ·  Radiance HDR: "#?RADIANCE" / "#?RGBE"
const KTX2_MAGIC = [0xab, 0x4b, 0x54, 0x58, 0x20, 0x32, 0x30, 0xbb, 0x0d, 0x0a, 0x1a, 0x0a] as const;
const GLB_MAGIC = [0x67, 0x6c, 0x54, 0x46] as const; // "glTF"
const HDR_MAGIC = [0x23, 0x3f] as const; // "#?"
const PNG_MAGIC = [0x89, 0x50, 0x4e, 0x47] as const;
const JPEG_MAGIC = [0xff, 0xd8, 0xff] as const;

/** Kind from the leading bytes — authoritative when the extension is missing/ambiguous. */
export function sniffKindFromBytes(bytes: Uint8Array): AssetKind {
  if (startsWith(bytes, KTX2_MAGIC)) return "ktx2";
  if (startsWith(bytes, GLB_MAGIC)) return "gltf";
  if (startsWith(bytes, HDR_MAGIC)) return "hdr";
  if (startsWith(bytes, PNG_MAGIC) || startsWith(bytes, JPEG_MAGIC)) return "image";
  // RIFF....WEBP
  if (startsWith(bytes, [0x52, 0x49, 0x46, 0x46]) && bytes.length >= 12 && startsWith(bytes.subarray(8), [0x57, 0x45, 0x42, 0x50])) {
    return "image";
  }
  // A leading '{' or whitespace then '{' is a text glTF document.
  for (let i = 0; i < bytes.length && i < 8; i++) {
    const c = bytes[i]!;
    if (c === 0x7b) return "gltf"; // '{'
    if (c !== 0x20 && c !== 0x09 && c !== 0x0a && c !== 0x0d && c !== 0xef && c !== 0xbb && c !== 0xbf) break;
  }
  return "unknown";
}
