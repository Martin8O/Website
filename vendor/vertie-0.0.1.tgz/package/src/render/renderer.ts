/**
 * The render layer (spec §5/§7/§8/§9): the ONE renderer (three.js/WebGL, ADR-010). It
 * turns the evaluator's per-frame `SceneState` into pixels. Layer boundary: it consumes
 * a validated `Scene` (structure, assets, transforms, environment, stage) at `load()`
 * and a `SceneState` (poses) at `apply()`; it owns no timeline and no rAF loop — the
 * driver (C4) invalidates and calls `render()` on demand (§ scroll rule: work in rAF,
 * render only on change).
 *
 * Mobile discipline (ADR-007): DPR capped at 2, GPU resources released on `dispose()`
 * (VRAM reclaim), a lightweight `park()`/`unpark()` for offscreen scenes, and a
 * frame-time + VRAM measurement surface on `debug` for a later adaptive-quality pass.
 * C3 ships the measurement foundation; the auto-downshift policy is a later prompt.
 */

import * as THREE from "three";
import type { Scene as VertieScene, ObjectTrack, CameraTrack, Track, Transform, Vec3 } from "../format/types.js";
import type { SceneState } from "../core/types.js";
import {
  createLoaderBundle,
  parseGltf,
  loadEquirect,
  type LoaderBundle,
} from "./assets.js";
import { defaultDecoderPath, describeDecodeTimeout } from "./decoders.js";
import { fetchBytes } from "./fetch.js";
import { gltfExtensionsUsed } from "./gltf-meta.js";
import { withTimeout } from "./timeout.js";
import { yieldToBrowser } from "./schedule.js";
import type { SceneLoadOptions } from "./loading.js";
import { boxToNdc, pickTrack, projectPoint } from "./pick.js";
import type { PickCandidate, PickResult, ScreenPoint } from "./pick.js";
import {
  DEFAULT_CLAMP_MARGIN,
  frustumClampScale,
  NO_FRUSTUM_CLAMP,
  stageCameraPose,
  type FrustumClamp,
} from "./stage.js";
import { estimateTextureBytes } from "./vram.js";

/** DPR cap — the binding mobile constraint is VRAM, and DPR² drives framebuffer VRAM (ADR-007). */
const MAX_PIXEL_RATIO = 2;
/**
 * How long one asset decode may take before the load fails instead of hanging (C8b).
 * Generous on purpose: a big Draco mesh on a Galaxy-A50-class device is seconds, not
 * tens of seconds, and killing a decode that would have succeeded is the worse failure.
 * A broken decoder payload never finishes at all, so the exact figure only decides how
 * long the diagnosis takes — and `onSlow` puts it in the console at a quarter of it.
 */
const DEFAULT_DECODE_TIMEOUT_MS = 30_000;
/** Reused by `trackWorldPosition` so a per-frame `follow` event allocates nothing. */
const worldScratch = new THREE.Vector3();
const NEAR = 0.1;
const FAR = 2000;

export interface SceneRendererOptions {
  /** Device-pixel-ratio cap. Default 2 (ADR-007). */
  maxPixelRatio?: number;
  /** Base URL for resolving relative asset `src` (reference mode, §14.1). Default: document base. */
  baseUrl?: string;
  /**
   * Base URL for the Draco/Basis decoder payloads (must end in `/`; `draco/` and
   * `basis/` are appended). Default: three resolves its own, except in the standalone
   * bundle, which uses its shipped `decoders/` copy (ADR-030, `decoders.ts`).
   */
  decoderPath?: string;
  /**
   * Budget for a single asset decode, in ms. Default 30 000; `0` disables the guard.
   * Exists because three's Draco/KTX2 workers never report back when their decoder
   * payload is unreachable — without a bounded wait the player hangs silently (C8b).
   */
  decodeTimeoutMs?: number;
  /** Multisample antialiasing. Default true. */
  antialias?: boolean;
  /** Keep the drawing buffer for `readPixels` verification. Default false (perf). */
  preserveDrawingBuffer?: boolean;
  /**
   * The §9 **data-aware clamp** (ADR-017's optional runtime policy): scale the authored
   * keys laterally so none leaves the stage camera's frustum at its own depth. Off by
   * default — it changes framing, so a scene only gets it when the host asks.
   *
   * `true` = clamp keys to the frustum edge; a number in (0..1] = the fraction of the
   * half-frustum a key may occupy (a pivot has a model hanging off it, so a margin below
   * 1 is usually what you want). Ignored, with a warning, for a scene that carries its
   * own camera track — the frustum moves, so there is no single factor to compute.
   */
  frustumClamp?: boolean | number;
}

/** What `guardDecode` needs to name the thing that stalled (C8b). */
interface DecodeUnit {
  /** Track id, or `"environment"`. */
  id: string;
  url: string;
  /** The fetched glTF bytes, when there are any — read for `extensionsUsed` on timeout. */
  bytes?: ArrayBuffer;
  signal?: AbortSignal | undefined;
}

/** One object track's scene-graph node + the material state needed for opacity/fade (§7). */
interface TrackNode {
  id: string;
  /** The animated pose (position/quaternion from `SceneState`) lives on this group. */
  group: THREE.Group;
  /** The loaded model under it, carrying the track's static `transform` (§7). */
  model: THREE.Object3D;
  /** Original material opacity/transparency, so `fade` composes rather than clobbers. */
  materials: { mat: THREE.Material; opacity: number; transparent: boolean }[];
  lastOpacity: number;
}

/** A plain, JSON-serializable snapshot for the `window.__vertie` verification hook. */
export interface SceneRendererDebug {
  ready: boolean;
  /** True once `warm()` has compiled shaders + uploaded textures (C4b anti-jank). */
  warmed: boolean;
  parked: boolean;
  disposed: boolean;
  frames: number;
  lastFrameMs: number;
  avgFrameMs: number;
  pixelRatio: number;
  size: { width: number; height: number };
  hasCameraTrack: boolean;
  /** Active §9 clamp factors; `{x:1,y:1}` when the policy is off or does not apply. */
  frustumClamp: FrustumClamp;
  camera: { position: Vec3; quaternion: [number, number, number, number]; fov: number };
  tracks: { id: string; position: Vec3; quaternion: [number, number, number, number]; visible: boolean }[];
  info: { geometries: number; textures: number; triangles: number; calls: number };
  vramBytes: number;
}

/**
 * `frustumClamp` option → a margin, or null for "policy off". An out-of-range number is
 * warned about and ignored rather than silently reinterpreted: this is a public option,
 * and quietly turning `2` into `1` would hide the author's mistake behind a plausible frame.
 */
function parseClampMargin(option: boolean | number | undefined): number | null {
  if (option === undefined || option === false) return null;
  if (option === true) return DEFAULT_CLAMP_MARGIN;
  if (typeof option === "number" && option > 0 && option <= 1) return option;
  // String(), not JSON.stringify(): the element hands us Number("wide") = NaN, and
  // JSON.stringify(NaN) is "null" — a message that names the wrong mistake is worse than none.
  console.warn(
    `vertie: frustumClamp must be true or a number in (0..1] — got ${String(option)}; clamp disabled`,
  );
  return null;
}

export class SceneRenderer {
  private readonly renderer: THREE.WebGLRenderer;
  private readonly scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private readonly loaders: LoaderBundle;
  private readonly baseUrl: string;
  private readonly maxPixelRatio: number;
  private readonly decodeTimeoutMs: number;

  private readonly nodes = new Map<string, TrackNode>();
  private stage: VertieScene["stage"];
  private hasCameraTrack = false;

  /** §9 clamp margin, or null when the policy is off. Parsed once, in the constructor. */
  private readonly clampMargin: number | null;
  /** Every authored key position, kept for the clamp; empty while the policy is off. */
  private clampKeys: Vec3[] = [];
  /** Current per-axis factors — recomputed with the stage camera, applied in `apply()`. */
  private clamp: FrustumClamp = NO_FRUSTUM_CLAMP;
  /** The camera-track warning is worth saying once, not every resize. */
  private clampWarned = false;

  /** Built on the first hit-test; a scene without triggers never allocates one. */
  private raycaster: THREE.Raycaster | null = null;

  private pmrem: THREE.PMREMGenerator | null = null;
  private envTarget: THREE.WebGLRenderTarget | null = null;
  private envSource: THREE.Texture | null = null;

  private width = 1;
  private height = 1;
  private ready = false;
  private warmed = false;
  private parked = false;
  private disposed = false;
  private frames = 0;
  private lastFrameMs = 0;
  private avgFrameMs = 0;

  constructor(canvas: HTMLCanvasElement, options: SceneRendererOptions = {}) {
    this.maxPixelRatio = options.maxPixelRatio ?? MAX_PIXEL_RATIO;
    this.decodeTimeoutMs = options.decodeTimeoutMs ?? DEFAULT_DECODE_TIMEOUT_MS;
    this.clampMargin = parseClampMargin(options.frustumClamp);
    this.baseUrl = options.baseUrl ?? (typeof document !== "undefined" ? document.baseURI : "http://localhost/");

    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: options.antialias ?? true,
      alpha: true,
      preserveDrawingBuffer: options.preserveDrawingBuffer ?? false,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.setClearColor(0x000000, 0);

    this.camera = new THREE.PerspectiveCamera(55, 1, NEAR, FAR);

    this.loaders = createLoaderBundle(this.renderer, options.decoderPath ?? defaultDecoderPath());

    const w = canvas.clientWidth || canvas.width || 1;
    const h = canvas.clientHeight || canvas.height || 1;
    this.resize(w, h);
  }

  /**
   * Build the scene graph from a validated `Scene`: load each object track's asset,
   * set up the PMREM environment and background, and place the fixed stage camera when
   * the scene has no camera track.
   *
   * Staged since C4b: **bytes first, concurrently** (network parallelism, off the main
   * thread), then **one decode at a time with a yield in between** — three back-to-back
   * decodes are one very long task, and a long task is a dropped scroll frame. The
   * behavior for a caller that passes no options is unchanged.
   */
  async load(scene: VertieScene, options: SceneLoadOptions = {}): Promise<void> {
    const { signal, onProgress } = options;
    const schedule = options.schedule ?? yieldToBrowser;

    this.stage = scene.stage;
    this.renderer.toneMappingExposure = scene.environment?.exposure ?? 1;
    this.hasCameraTrack = scene.tracks.some((t) => isCameraTrack(t));
    this.collectClampKeys(scene);

    const assets = scene.assets ?? {};

    // The environment's fetch and decode cannot be split (three's texture loaders own
    // their own request), so it is started here to overlap the model fetches and
    // installed — the GPU-side PMREM work — down in the serial section.
    const envKey = scene.environment?.envMap;
    const envSrc = envKey ? assets[envKey]?.src : undefined;
    let envPromise: Promise<THREE.Texture> | null = null;
    if (envSrc !== undefined) {
      const envUrl = this.resolve(envSrc);
      const envLoad = loadEquirect(envUrl, this.loaders);
      // three's loaders take no AbortSignal, so an aborted load cannot cancel this
      // request — it can only make sure the texture that still arrives is not left
      // orphaned. This watches the UNGUARDED promise on purpose: the guard below rejects
      // on abort, and a texture landing after that must still be disposed, not leaked.
      envLoad.then(
        (texture) => {
          if (signal?.aborted) texture.dispose();
        },
        () => {},
      );
      // The clock starts where the work STARTS, not where it is awaited: the environment
      // decode runs alongside the model fetches, so guarding it at the await below would
      // only notice a hang once every model had already decoded.
      envPromise = this.guardDecode(envLoad, { id: "environment", url: envUrl, signal });
      envPromise.catch(() => {}); // may never be awaited (an earlier decode can throw first)
    }

    const units: { track: ObjectTrack; url: string }[] = [];
    for (const track of scene.tracks) {
      if (isCameraTrack(track)) continue;
      const asset = assets[track.asset];
      if (asset) units.push({ track, url: this.resolve(asset.src) });
    }

    // 1. Network — all model bytes at once.
    const buffers = await Promise.all(
      units.map(async (unit) => {
        const report = (loaded: number, total: number, done: boolean): void =>
          onProgress?.({ id: unit.track.id, step: "fetch", loaded, total, done });
        const bytes = await fetchBytes(unit.url, {
          signal,
          onProgress: onProgress ? (p) => report(p.loaded, p.total, false) : undefined,
        });
        report(bytes.byteLength, bytes.byteLength, true);
        return bytes;
      }),
    );

    // 2. Decode — serially, yielding between units so a scroll frame can slip in.
    for (let i = 0; i < units.length; i++) {
      signal?.throwIfAborted();
      const unit = units[i]!;
      const bytes = buffers[i]!;
      const gltf = await this.guardDecode(parseGltf(bytes, unit.url, this.loaders), {
        id: unit.track.id,
        url: unit.url,
        bytes,
        signal,
      });
      this.addTrackNode(unit.track, gltf.scene);
      onProgress?.({ id: unit.track.id, step: "decode", loaded: 1, total: 1, done: true });
      if (i < units.length - 1) await schedule();
    }

    if (envPromise) {
      const equirect = await envPromise;
      if (signal?.aborted) {
        equirect.dispose(); // arrived after the caller gave up — do not leak it
        signal.throwIfAborted();
      }
      this.installEnvironment(equirect);
      onProgress?.({ id: "environment", step: "decode", loaded: 1, total: 1, done: true });
    }

    signal?.throwIfAborted();
    this.applyBackground(scene.environment?.background);
    // A camera-track scene skips the stage camera entirely, but a host that asked for the
    // §9 clamp still deserves to hear that it does not apply — so run the policy either way.
    if (this.hasCameraTrack) this.updateFrustumClamp();
    else this.applyStageCamera();
    this.ready = true;
  }

  /**
   * Put a clock on one decode (C8b). three's Draco/KTX2 loaders build a worker out of
   * whatever their decoder URL returned; when that is not the decoder — a wrong path, a
   * dev server answering `index.html`, an offline CDN — the worker dies at init and the
   * decode promise never settles. Nothing downstream can see that: the player just says
   * "decoding" forever. A bounded wait turns it into a `vertie-error` naming the URL.
   *
   * The diagnosis (which extensions this asset needs → which decoder payload) is built
   * only when the clock actually runs out, so the happy path pays for a timer and nothing
   * else.
   */
  private guardDecode<T>(work: Promise<T>, unit: DecodeUnit): Promise<T> {
    const describe = (ms: number, stalled: boolean): string =>
      describeDecodeTimeout(
        {
          id: unit.id,
          url: unit.url,
          ms,
          extensions: unit.bytes ? gltfExtensionsUsed(unit.bytes) : [],
          sources: this.loaders.decoderSources(),
        },
        stalled,
      );

    return withTimeout(work, {
      ms: this.decodeTimeoutMs,
      signal: unit.signal,
      onTimeout: (ms) => new Error(describe(ms, false)),
      // A slow device is allowed to be slow — but the diagnosis should be readable long
      // before the deadline, because the deadline is also how long the page looks broken.
      onSlow: (ms) => console.warn(describe(ms, true)),
    });
  }

  /**
   * Compile shaders and upload textures for the loaded scene (C4b). Without this the
   * FIRST `render()` pays both — tens to hundreds of milliseconds — and with a scroll
   * driver that first frame lands exactly when the user starts scrolling. Uses
   * `KHR_parallel_shader_compile` where available (`compileAsync`).
   */
  async warm(): Promise<void> {
    if (this.disposed || this.warmed) return;
    await this.renderer.compileAsync(this.scene, this.camera);
    if (this.disposed) return;

    // Shader compile is only half of it: a texture uploads on first draw unless forced.
    const seen = new Set<string>();
    this.scene.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (!mesh.isMesh) return;
      for (const mat of Array.isArray(mesh.material) ? mesh.material : [mesh.material]) {
        if (!mat) continue;
        for (const tex of materialTextures(mat, seen)) this.initTexture(tex);
      }
    });
    const background = this.scene.background;
    if (background && (background as THREE.Texture).isTexture) this.initTexture(background as THREE.Texture);

    this.warmed = true;
  }

  /** Upload one texture, skipping kinds `initTexture` does not handle (cube maps). */
  private initTexture(texture: THREE.Texture): void {
    if ((texture as THREE.CubeTexture).isCubeTexture) return;
    this.renderer.initTexture(texture);
  }

  private resolve(src: string): string {
    return new URL(src, this.baseUrl).href;
  }

  private installEnvironment(equirect: THREE.Texture): void {
    this.envSource = equirect;
    this.pmrem ??= new THREE.PMREMGenerator(this.renderer);
    this.pmrem.compileEquirectangularShader();
    this.envTarget = this.pmrem.fromEquirectangular(equirect);
    this.scene.environment = this.envTarget.texture;
  }

  private addTrackNode(track: ObjectTrack, model: THREE.Object3D): void {
    const group = new THREE.Group();
    group.name = track.id;
    applyTransform(model, track.transform);
    group.add(model);
    group.visible = false; // apply() reveals it per SceneState
    this.scene.add(group);

    const materials: TrackNode["materials"] = [];
    model.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (!mesh.isMesh) return;
      for (const mat of Array.isArray(mesh.material) ? mesh.material : [mesh.material]) {
        materials.push({ mat, opacity: mat.opacity, transparent: mat.transparent });
      }
    });
    this.nodes.set(track.id, { id: track.id, group, model, materials, lastOpacity: 1 });
  }

  private applyBackground(background: string | undefined): void {
    if (!background || background === "transparent") {
      this.scene.background = null;
      return;
    }
    if (background.startsWith("#")) {
      this.scene.background = new THREE.Color(background);
      return;
    }
    // Asset key: reuse the loaded equirect as the backdrop, else stay transparent.
    this.scene.background = this.envSource ?? null;
  }

  /**
   * Cache the authored key positions the §9 clamp measures. Object tracks only: a camera
   * track's keys describe where the viewer stands, not what must stay in frame.
   */
  private collectClampKeys(scene: VertieScene): void {
    if (this.clampMargin === null) {
      this.clampKeys = [];
      return;
    }
    const keys: Vec3[] = [];
    for (const track of scene.tracks) {
      if (isCameraTrack(track)) continue;
      for (const key of track.keys) keys.push(key.p);
    }
    this.clampKeys = keys;
  }

  /**
   * Recompute the §9 factors for the current aspect. Called wherever the stage camera is
   * placed, because that is exactly when the frustum changed.
   */
  private updateFrustumClamp(): void {
    if (this.clampMargin === null) return;
    if (this.hasCameraTrack) {
      if (!this.clampWarned) {
        this.clampWarned = true;
        console.warn(
          "vertie: frustumClamp ignored — this scene has a camera track, so the frustum moves and no single factor applies (spec §9)",
        );
      }
      this.clamp = NO_FRUSTUM_CLAMP;
      return;
    }
    const aspect = this.height > 0 ? this.width / this.height : 1;
    this.clamp = frustumClampScale(this.stage, this.clampKeys, aspect, this.clampMargin);
  }

  private applyStageCamera(): void {
    const aspect = this.height > 0 ? this.width / this.height : 1;
    this.updateFrustumClamp();
    const sc = stageCameraPose(this.stage, aspect);
    this.camera.position.set(sc.position[0], sc.position[1], sc.position[2]);
    this.camera.quaternion.set(sc.quaternion[0], sc.quaternion[1], sc.quaternion[2], sc.quaternion[3]);
    this.camera.fov = sc.fov;
    this.camera.updateProjectionMatrix();
  }

  /**
   * Write one frame of evaluated state onto the scene graph (allocation-free, §12).
   *
   * The §9 clamp is applied HERE and nowhere else, on purpose: the pose goes into the graph
   * already scaled, so `trackWorldPosition`, `project` (hence §10 `follow`) and `hitTest`
   * all report the object where the viewer actually sees it, with no second code path to
   * keep in sync. `state` itself is never touched — the evaluator stays pure and
   * aspect-free, which is the boundary ADR-017 drew.
   */
  apply(state: SceneState): void {
    const { x: cx, y: cy } = this.clamp;
    for (const ts of state.tracks) {
      const node = this.nodes.get(ts.id);
      if (!node) continue;
      node.group.visible = ts.visible;
      if (!ts.visible) continue;
      const p = ts.pose.p;
      const q = ts.pose.q;
      node.group.position.set(p[0] * cx, p[1] * cy, p[2]);
      node.group.quaternion.set(q[0], q[1], q[2], q[3]);
      if (ts.opacity !== node.lastOpacity) {
        for (const m of node.materials) {
          m.mat.opacity = m.opacity * ts.opacity;
          m.mat.transparent = m.transparent || ts.opacity < 1;
        }
        node.lastOpacity = ts.opacity;
      }
    }

    if (state.camera) {
      // A camera track: the evaluator has already folded `lookAt` into pose.q (§8).
      const cp = state.camera.pose.p;
      const cq = state.camera.pose.q;
      this.camera.position.set(cp[0], cp[1], cp[2]);
      this.camera.quaternion.set(cq[0], cq[1], cq[2], cq[3]);
      if (this.camera.fov !== state.camera.fov) {
        this.camera.fov = state.camera.fov;
        this.camera.updateProjectionMatrix();
      }
    }
  }

  // ── screen space & picking (C9: §10 `follow`, §11 triggers) ──────────────────

  /**
   * Project a world point into the canvas box (CSS pixels, top-left origin) — what a
   * `follow` event hands the host so it can park a DOM label on a moving object.
   * Matrices are refreshed here because `apply()` writes transforms without them and a
   * caller may project between frames.
   */
  project(world: Vec3): ScreenPoint {
    this.camera.updateMatrixWorld();
    return projectPoint(this.camera, world, this.width, this.height);
  }

  /**
   * Where a track's object actually IS: its animated pose composed with the static
   * `transform` the author placed the model with (§7, `world = TRS(pose)·TRS(transform)`).
   *
   * This is what `follow` reports (§10). The evaluator's bare pose would be the literal
   * reading, but it points at the group's origin — so a model offset by `transform` would
   * hand the host a screen point next to the thing the viewer sees, which is the one job
   * `follow` has. The offset is static scene data, so this stays fully deterministic.
   */
  trackWorldPosition(id: string): Vec3 | null {
    const node = this.nodes.get(id);
    if (!node) return null;
    node.group.updateMatrixWorld();
    const p = node.model.getWorldPosition(worldScratch);
    return [p.x, p.y, p.z];
  }

  /**
   * Which track's rendered object is under this canvas-box point (CSS pixels), if any.
   * Only tracks that are actually drawn are candidates — hidden by `extrapolate`, or
   * faded to nothing by `fade`, means not hittable (§11: you cannot hit what is not
   * drawn). Returns the nearest hit.
   */
  hitTest(x: number, y: number): PickResult | null {
    if (this.disposed || !this.ready) return null;
    const candidates: PickCandidate[] = [];
    for (const node of this.nodes.values()) {
      if (!node.group.visible || node.lastOpacity <= 0) continue;
      candidates.push({ id: node.id, object: node.group });
    }
    if (candidates.length === 0) return null;

    this.camera.updateMatrixWorld();
    this.scene.updateMatrixWorld();
    this.raycaster ??= new THREE.Raycaster();
    const [ndcX, ndcY] = boxToNdc(x, y, this.width, this.height);
    return pickTrack(this.raycaster, this.camera, ndcX, ndcY, candidates);
  }

  /** Render exactly one frame (on demand). Records frame time for the perf surface. */
  render(): void {
    if (this.disposed) return;
    const t0 = performance.now();
    this.renderer.render(this.scene, this.camera);
    this.lastFrameMs = performance.now() - t0;
    this.avgFrameMs = this.frames === 0 ? this.lastFrameMs : this.avgFrameMs * 0.9 + this.lastFrameMs * 0.1;
    this.frames++;
  }

  /** Resize the drawing buffer (DPR capped at 2) and keep the camera aspect correct. */
  resize(width: number, height: number): void {
    this.width = Math.max(1, Math.floor(width));
    this.height = Math.max(1, Math.floor(height));
    const dpr = typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1;
    this.renderer.setPixelRatio(Math.min(dpr, this.maxPixelRatio));
    this.renderer.setSize(this.width, this.height, false);
    this.camera.aspect = this.width / this.height;
    if (this.hasCameraTrack) this.camera.updateProjectionMatrix();
    else this.applyStageCamera();
  }

  /** Lightweight offscreen suspend: free the PMREM env target VRAM; `unpark()` rebuilds it. */
  park(): void {
    if (this.parked || this.disposed) return;
    if (this.envTarget) {
      this.envTarget.dispose();
      this.envTarget = null;
      this.scene.environment = null;
    }
    this.parked = true;
  }

  /** Undo `park()`: regenerate the environment from the retained equirect source. */
  unpark(): void {
    if (!this.parked || this.disposed) return;
    if (this.envSource && this.pmrem) {
      this.envTarget = this.pmrem.fromEquirectangular(this.envSource);
      this.scene.environment = this.envTarget.texture;
    }
    this.parked = false;
    // A new environment map invalidates the compiled programs, so the scene is no
    // longer warm — the next `render()` would pay the recompile. Call `warm()` again
    // (the offscreen park/unpark policy itself belongs to the element, C6).
    this.warmed = false;
  }

  /** Release every GPU resource (geometries, materials, textures, targets, context). */
  dispose(): void {
    if (this.disposed) return;
    disposeObject(this.scene);
    this.envTarget?.dispose();
    this.envSource?.dispose();
    this.pmrem?.dispose();
    this.loaders.dispose();
    this.renderer.dispose();
    this.renderer.forceContextLoss();
    this.nodes.clear();
    this.disposed = true;
    this.ready = false;
    this.warmed = false;
  }

  // ── verification surface (the element owns `window.__vertie` for real in C5) ──────

  /** WebGL context — for in-page `gl.readPixels` verification. */
  getContext(): WebGLRenderingContext | WebGL2RenderingContext {
    return this.renderer.getContext();
  }

  getCanvas(): HTMLCanvasElement {
    return this.renderer.domElement;
  }

  /** RGBA bytes read back from the drawing buffer (origin bottom-left, device pixels). */
  readPixels(x: number, y: number, w = 1, h = 1): Uint8Array {
    const gl = this.renderer.getContext();
    const buf = new Uint8Array(w * h * 4);
    gl.readPixels(x, y, w, h, gl.RGBA, gl.UNSIGNED_BYTE, buf);
    return buf;
  }

  /** RGBA of the center device pixel — a one-call "did it paint?" probe. */
  readCenterPixel(): [number, number, number, number] {
    const gl = this.renderer.getContext();
    const px = this.readPixels((gl.drawingBufferWidth / 2) | 0, (gl.drawingBufferHeight / 2) | 0);
    return [px[0]!, px[1]!, px[2]!, px[3]!];
  }

  get debug(): SceneRendererDebug {
    const mem = this.renderer.info.memory;
    const render = this.renderer.info.render;
    return {
      ready: this.ready,
      warmed: this.warmed,
      parked: this.parked,
      disposed: this.disposed,
      frames: this.frames,
      lastFrameMs: this.lastFrameMs,
      avgFrameMs: this.avgFrameMs,
      pixelRatio: this.renderer.getPixelRatio(),
      size: { width: this.width, height: this.height },
      hasCameraTrack: this.hasCameraTrack,
      frustumClamp: { x: this.clamp.x, y: this.clamp.y },
      camera: {
        position: [this.camera.position.x, this.camera.position.y, this.camera.position.z],
        quaternion: [this.camera.quaternion.x, this.camera.quaternion.y, this.camera.quaternion.z, this.camera.quaternion.w],
        fov: this.camera.fov,
      },
      tracks: [...this.nodes.values()].map((n) => ({
        id: n.id,
        position: [n.group.position.x, n.group.position.y, n.group.position.z],
        quaternion: [n.group.quaternion.x, n.group.quaternion.y, n.group.quaternion.z, n.group.quaternion.w],
        visible: n.group.visible,
      })),
      info: { geometries: mem.geometries, textures: mem.textures, triangles: render.triangles, calls: render.calls },
      vramBytes: this.estimateVram(),
    };
  }

  private estimateVram(): number {
    let bytes = 0;
    const geometries = new Set<string>();
    const textures = new Set<string>();
    this.scene.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (!mesh.isMesh) return;
      const geo = mesh.geometry;
      if (geo && !geometries.has(geo.uuid)) {
        geometries.add(geo.uuid);
        for (const name in geo.attributes) bytes += geo.attributes[name]!.array.byteLength;
        if (geo.index) bytes += geo.index.array.byteLength;
      }
      for (const mat of Array.isArray(mesh.material) ? mesh.material : [mesh.material]) {
        bytes += accumulateTextureVram(mat, textures);
      }
    });
    if (this.envTarget) {
      const s = this.envTarget.width;
      bytes += estimateTextureBytes({ width: s, height: s, compressed: false, mipmaps: true }) * 6;
    }
    return bytes;
  }
}

// ── module helpers ──────────────────────────────────────────────────────────

function isCameraTrack(t: Track): t is CameraTrack {
  return t.role === "camera";
}

/** Apply a track's static base transform to the loaded model (§7: `world = TRS(pose)·TRS(transform)`). */
function applyTransform(model: THREE.Object3D, transform: Transform | undefined): void {
  if (!transform) return;
  if (transform.position) model.position.set(transform.position[0], transform.position[1], transform.position[2]);
  if (transform.rotation) {
    model.quaternion.set(transform.rotation[0], transform.rotation[1], transform.rotation[2], transform.rotation[3]);
  }
  if (transform.scale !== undefined) {
    if (typeof transform.scale === "number") model.scale.setScalar(transform.scale);
    else model.scale.set(transform.scale[0], transform.scale[1], transform.scale[2]);
  }
}

/**
 * Every texture a material references, each yielded once across the shared `seen` set
 * (materials share maps). Used by both the VRAM estimate and `warm()`'s upload pass.
 */
function* materialTextures(material: THREE.Material, seen: Set<string>): Generator<THREE.Texture> {
  const record = material as unknown as Record<string, unknown>;
  for (const key in record) {
    const value = record[key];
    if (!value || typeof value !== "object") continue;
    const tex = value as THREE.Texture;
    if (!tex.isTexture || seen.has(tex.uuid)) continue;
    seen.add(tex.uuid);
    yield tex;
  }
}

/** Sum resident bytes of a material's textures once each (dedup by uuid). */
function accumulateTextureVram(material: THREE.Material, seen: Set<string>): number {
  let bytes = 0;
  for (const tex of materialTextures(material, seen)) {
    if (!tex.image) continue;
    const img = tex.image as { width?: number; height?: number };
    bytes += estimateTextureBytes({
      width: img.width ?? 0,
      height: img.height ?? 0,
      compressed: (tex as THREE.CompressedTexture).isCompressedTexture === true,
      mipmaps: tex.generateMipmaps || (Array.isArray(tex.mipmaps) && tex.mipmaps.length > 1),
    });
  }
  return bytes;
}

/** Recursively dispose geometries, material textures, and materials under `root`. */
function disposeObject(root: THREE.Object3D): void {
  root.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (!mesh.isMesh) return;
    mesh.geometry?.dispose();
    for (const mat of Array.isArray(mesh.material) ? mesh.material : [mesh.material]) {
      if (!mat) continue;
      const record = mat as unknown as Record<string, unknown>;
      for (const key in record) {
        const value = record[key] as THREE.Texture | undefined;
        if (value && value.isTexture) value.dispose();
      }
      mat.dispose();
    }
  });
}
