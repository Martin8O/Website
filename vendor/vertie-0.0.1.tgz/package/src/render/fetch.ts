/**
 * Asset bytes over the network — deliberately separated from decoding (C4b).
 *
 * three's loaders fuse "fetch" and "parse" into one call, which is exactly what makes
 * an asset load jank: the parse (geometry decode, image decode) runs the instant the
 * bytes land, wherever that falls in the frame. Splitting the two lets the pipeline
 * pull the bytes early and concurrently (network is parallel and off the main thread)
 * and then schedule the decodes one at a time, yielding between them.
 *
 * three-free by construction — this module is plain `fetch`, so it stays unit-testable
 * without a GPU.
 */

/** Byte counts for one in-flight asset. `total` is 0 when the server reports no length. */
export interface BytesProgress {
  loaded: number;
  total: number;
}

export interface FetchBytesOptions {
  /** Aborts the request (and any in-progress streaming read). */
  signal?: AbortSignal | undefined;
  /** Called as chunks arrive. Streaming is only used when this is provided. */
  onProgress?: ((progress: BytesProgress) => void) | undefined;
}

/**
 * Fetch an asset as raw bytes. With `onProgress` the body is streamed so byte progress
 * is real (the `Content-Length` header when present, otherwise `total` stays 0 and only
 * `loaded` grows — a compressed/chunked response cannot honestly report a total).
 */
export async function fetchBytes(url: string, options: FetchBytesOptions = {}): Promise<ArrayBuffer> {
  const { signal, onProgress } = options;
  const response = await fetch(url, signal ? { signal } : {});
  if (!response.ok) {
    throw new Error(`vertie: fetch failed (${response.status} ${response.statusText}) for ${url}`);
  }

  const header = response.headers.get("content-length");
  const declared = header === null ? 0 : Number(header);
  const total = Number.isFinite(declared) && declared > 0 ? declared : 0;
  const body = response.body;

  if (!onProgress || !body) {
    const buffer = await response.arrayBuffer();
    onProgress?.({ loaded: buffer.byteLength, total: total || buffer.byteLength });
    return buffer;
  }

  const reader = body.getReader();
  const chunks: Uint8Array[] = [];
  let loaded = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    if (!value) continue;
    chunks.push(value);
    loaded += value.byteLength;
    onProgress({ loaded, total });
  }

  const bytes = new Uint8Array(loaded);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return bytes.buffer;
}
