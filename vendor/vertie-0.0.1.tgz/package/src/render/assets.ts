/**
 * Asset loading for the render layer: GLB/glTF models and the IBL environment map.
 *
 * The three.js loaders and their decoders are wired here. Decoder *payloads*
 * (Draco/Basis WASM) are lazy by construction — the loader fetches them only when a
 * loaded asset actually uses that extension (§4.1). The addon loaders themselves are
 * external to the core bundle (three + `three/examples/jsm/*` are marked external in
 * the lib build), so none of this counts against the ADR-007 size budget.
 *
 * WHERE those payloads come from is decided in `decoders.ts` (C7): `undefined` means
 * "let three resolve its own", which is the right answer whenever three is a real,
 * separately-loaded module. Only the standalone bundle passes an explicit path.
 *
 * Reference mode only (§14.1): `src` is resolved against a base URL. `.vertie` bundle
 * (ZIP) unpacking is a separate prompt.
 */

import * as THREE from "three";
import { GLTFLoader, type GLTF } from "three/examples/jsm/loaders/GLTFLoader.js";
import { DRACOLoader } from "three/examples/jsm/loaders/DRACOLoader.js";
import { KTX2Loader } from "three/examples/jsm/loaders/KTX2Loader.js";
import { HDRLoader } from "three/examples/jsm/loaders/HDRLoader.js";
import { MeshoptDecoder } from "three/examples/jsm/libs/meshopt_decoder.module.js";
import { resolveAssetKind } from "./sniff.js";
import { fetchBytes } from "./fetch.js";
import type { DecoderSources } from "./decoders.js";

/** GLTFLoader wired with the three decoders, plus a `dispose` for their worker pools. */
export interface LoaderBundle {
  gltf: GLTFLoader;
  ktx2: KTX2Loader;
  /** Where the payload-fetching decoders actually load from (C8b diagnosis). */
  decoderSources(): DecoderSources;
  dispose(): void;
}

/**
 * Build the GLTF loader with Draco + meshopt + KTX2 decoders attached. Attaching is
 * cheap; each decoder only fetches its payload the first time a primitive/texture needs
 * it (our own B4 assets exercise meshopt + Draco; KTX2 is wired but unexercised until
 * real KTX2 assets land).
 *
 * `decoderPath` is a base URL ending in `/`; leave it `undefined` to keep three's own
 * defaults (which resolve relative to the three module that was loaded — see
 * `decoders.ts`). Setting a path is an override, so it is only wired when one is given.
 */
export function createLoaderBundle(
  renderer: THREE.WebGLRenderer,
  decoderPath?: string,
): LoaderBundle {
  const draco = new DRACOLoader();
  if (decoderPath) draco.setDecoderPath(`${decoderPath}draco/`);
  const ktx2 = new KTX2Loader();
  if (decoderPath) ktx2.setTranscoderPath(`${decoderPath}basis/`);
  ktx2.detectSupport(renderer);
  const gltf = new GLTFLoader();
  gltf.setDRACOLoader(draco);
  gltf.setKTX2Loader(ktx2);
  gltf.setMeshoptDecoder(MeshoptDecoder);
  return {
    gltf,
    ktx2,
    // Read off the loaders rather than off `decoderPath`, so the default case — three
    // resolving its own payloads relative to its module URL — reports a real URL too.
    // `decoderPaths` exists on DRACOLoader since r18x but is absent from @types/three,
    // hence the narrow structural read (with the configured path as the fallback).
    decoderSources: () => ({
      draco:
        (draco as unknown as { decoderPaths?: { js?: string } }).decoderPaths?.js ??
        (decoderPath ? `${decoderPath}draco/` : "three's own bundled draco/ decoder"),
      ktx2: ktx2.transcoderPath || "three's own bundled basis/ transcoder",
    }),
    dispose() {
      draco.dispose();
      ktx2.dispose();
    },
  };
}

/** Load a GLB/glTF model (Draco/meshopt/KTX2 handled by the wired decoders). */
export function loadGltf(url: string, bundle: LoaderBundle): Promise<GLTF> {
  return bundle.gltf.loadAsync(url);
}

/**
 * Decode already-fetched glTF bytes (C4b): the second half of `loadGltf`, callable when
 * the pipeline decides — not the instant the bytes land. `url` is only used to derive the
 * base path for a `.gltf`'s external resources (`.bin`, loose textures); a self-contained
 * `.glb` never touches it.
 */
export function parseGltf(bytes: ArrayBuffer, url: string, bundle: LoaderBundle): Promise<GLTF> {
  const cut = url.lastIndexOf("/");
  return bundle.gltf.parseAsync(bytes, cut === -1 ? "" : url.slice(0, cut + 1));
}

/**
 * Load an environment map as an equirectangular texture, ready for PMREM. HDR via
 * `HDRLoader`, KTX2 via the shared `KTX2Loader`, ordinary images via `TextureLoader`.
 * Callers pass the resolved absolute URL.
 *
 * The kind normally comes from the extension (§4), but a URL does not always have one:
 * an object URL for a file the user dropped is a bare UUID. Guessing "image" there sent
 * a Radiance HDR into an `<img>`, which fails with a bare `Event` and no explanation
 * (found in C8, driving the playground). So when the URL is uninformative the bytes
 * decide — and since they had to be fetched to be sniffed, the loader is handed those
 * same bytes through a temporary object URL rather than made to fetch them twice.
 */
export async function loadEquirect(url: string, bundle: LoaderBundle): Promise<THREE.Texture> {
  const { kind, bytes } = await resolveAssetKind(url, (target) => fetchBytes(target));
  const source = bytes === undefined ? url : URL.createObjectURL(new Blob([bytes]));
  try {
    let texture: THREE.Texture;
    if (kind === "hdr") {
      texture = await new HDRLoader().loadAsync(source);
    } else if (kind === "ktx2") {
      texture = await bundle.ktx2.loadAsync(source);
    } else {
      texture = await new THREE.TextureLoader().loadAsync(source);
    }
    texture.mapping = THREE.EquirectangularReflectionMapping;
    return texture;
  } finally {
    if (bytes !== undefined) URL.revokeObjectURL(source);
  }
}
