/**
 * Screen-space projection and object picking (spec §10 `follow`, §11 triggers) — the
 * two things only the renderer can answer, because both need the live camera and the
 * real scene graph.
 *
 * Coordinates here are **CSS pixels relative to the canvas box**, top-left origin: the
 * same space `clientX/clientY − rect.left/top` gives a host page, so a follow point can
 * be dropped straight into `style.transform` and a pointer position needs no conversion
 * before it is hit-tested. Device pixels and DPR stay inside the renderer, where they
 * belong (`readPixels` is the one place that speaks them, and it says so).
 */

import * as THREE from "three";
import type { Vec3 } from "../format/types.js";

/** A point in the canvas box, plus whether it is actually on screen. */
export interface ScreenPoint {
  /** CSS pixels from the box's left edge. */
  x: number;
  /** CSS pixels from the box's top edge. */
  y: number;
  /** False when the point is behind the camera or outside the box. */
  visible: boolean;
}

/** What a hit-test found: the track whose rendered object was struck, and where. */
export interface PickResult {
  id: string;
  /** World-space point of the intersection. */
  point: Vec3;
  /** Distance from the camera, for choosing the topmost of several hits. */
  distance: number;
}

/** One raycast candidate: a track id and the node its geometry hangs under. */
export interface PickCandidate {
  id: string;
  object: THREE.Object3D;
}

/**
 * Canvas-box CSS pixels → normalized device coordinates. Pure (no three, no DOM), so
 * the mapping that every pointer coordinate passes through is unit-testable on its own.
 * A zero-sized box maps to the center rather than dividing by zero.
 */
export function boxToNdc(x: number, y: number, width: number, height: number): [number, number] {
  const nx = width > 0 ? (x / width) * 2 - 1 : 0;
  const ny = height > 0 ? -((y / height) * 2 - 1) : 0;
  return [nx, ny];
}

/** Normalized device coordinates → canvas-box CSS pixels (the inverse of `boxToNdc`). */
export function ndcToBox(nx: number, ny: number, width: number, height: number): [number, number] {
  return [((nx + 1) / 2) * width, ((1 - ny) / 2) * height];
}

const scratch = new THREE.Vector3();

/**
 * Project a world point into the canvas box. `visible` is false when the point is
 * behind the camera (NDC z outside [-1, 1]) or lands outside the box — a host moving a
 * label with the projected point needs to know both, and neither is recoverable from
 * the x/y pair alone.
 */
export function projectPoint(
  camera: THREE.Camera,
  world: Vec3,
  width: number,
  height: number,
): ScreenPoint {
  scratch.set(world[0], world[1], world[2]).project(camera);
  const [x, y] = ndcToBox(scratch.x, scratch.y, width, height);
  const onScreen =
    scratch.z >= -1 && scratch.z <= 1 && scratch.x >= -1 && scratch.x <= 1 && scratch.y >= -1 && scratch.y <= 1;
  return { x, y, visible: onScreen };
}

const pointer = new THREE.Vector2();

/**
 * Raycast the candidates and return the nearest hit. Candidates are filtered by the
 * caller, not here: §11 says a trigger can only fire while its track is actually drawn,
 * and "drawn" (visible, not faded to nothing) is the renderer's knowledge, not the
 * raycaster's.
 */
export function pickTrack(
  raycaster: THREE.Raycaster,
  camera: THREE.Camera,
  ndcX: number,
  ndcY: number,
  candidates: PickCandidate[],
): PickResult | null {
  if (candidates.length === 0) return null;
  pointer.set(ndcX, ndcY);
  raycaster.setFromCamera(pointer, camera);

  let best: PickResult | null = null;
  for (const candidate of candidates) {
    // Per candidate rather than one flat call: the intersection carries the struck mesh,
    // and walking back up to its owning group would be slower and easy to get wrong when
    // a GLB nests deeply.
    const hits = raycaster.intersectObject(candidate.object, true);
    const hit = hits[0];
    if (!hit) continue;
    if (best && hit.distance >= best.distance) continue;
    best = {
      id: candidate.id,
      point: [hit.point.x, hit.point.y, hit.point.z],
      distance: hit.distance,
    };
  }
  return best;
}
