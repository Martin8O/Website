/**
 * The decode/preload pipeline (C4b) — the anti-jank half of the scroll story.
 *
 * C4 made the driver cheap: passive listeners, all work in rAF, the loop stops when
 * settled. None of that survives an asset decode landing mid-gesture: a GLB parse and
 * the first frame's shader compile are long tasks, and a long task is a dropped frame
 * no matter how careful the driver is. So the pipeline does the expensive work EARLY,
 * gated on the scroll region approaching the viewport (IntersectionObserver with a
 * generous `rootMargin`), and hands the main thread back between decode units.
 *
 * Sequence: gate → fetch all model bytes concurrently → decode one at a time (yielding
 * in between) → `warm()` (compile shaders + upload textures) → ready. By the time the
 * region is on screen and t starts moving, the only per-frame cost left is the draw.
 *
 * three-free and DOM-light by construction: it drives a narrow `PreloadTarget` seam and
 * reads the DOM only through an injectable `env` — so it is unit-testable in node, and
 * verifiable in a hidden preview tab where IntersectionObserver never fires.
 */

import type { ObjectTrack, Scene } from "../format/types.js";
import type { LoadProgressEvent, SceneLoadOptions } from "./loading.js";
import { yieldToBrowser, type ScheduleFn } from "./schedule.js";

/**
 * How early to start. `rootMargin` grows the viewport the observer tests against, so
 * "150% 0px" means: begin roughly one and a half screens before the region scrolls in —
 * enough lead time for fetch + decode + warm on a mid-range device, without pulling
 * assets for a region the visitor may never reach.
 */
export const DEFAULT_ROOT_MARGIN = "150% 0px";

/** Share of a model unit's progress attributed to its download (the rest is its decode). */
const FETCH_SHARE = 0.7;
/** Share of the whole pipeline attributed to `warm()`. */
const WARM_SHARE = 0.1;

export type PreloadPhase = "idle" | "fetching" | "decoding" | "warming" | "ready" | "aborted" | "error";

/**
 * The slice of the renderer the pipeline drives. Narrow on purpose — `SceneRenderer`
 * satisfies it structurally, and the tests can satisfy it without three or a GPU.
 */
export interface PreloadTarget {
  load(scene: Scene, options?: SceneLoadOptions): Promise<void>;
  warm(): Promise<void>;
}

/** DOM/time seam — injectable so tests are deterministic and hidden tabs are drivable. */
export interface ScenePreloaderEnv {
  /**
   * Call `onNear` once `target` comes within `rootMargin` of the viewport; return a
   * teardown. An environment with no IntersectionObserver must call `onNear`
   * immediately — a gate that can never open would mean a scene that never loads.
   */
  observe(target: Element, rootMargin: string, onNear: () => void): () => void;
  /** px from the viewport's bottom edge to the target's top edge (> 0 = still below the fold). */
  distanceToViewport(target: Element): number;
  now(): number;
  schedule: ScheduleFn;
}

export interface ScenePreloaderOptions {
  /** IntersectionObserver `rootMargin` for `startWhenNear`. Default `"150% 0px"`. */
  rootMargin?: string;
  /** Run `warm()` after loading. Default true — skipping it defeats the purpose. */
  warm?: boolean;
  /** Called whenever progress (0..1) or the phase changes. */
  onProgress?: (progress: number, phase: PreloadPhase) => void;
  onPhase?: (phase: PreloadPhase) => void;
  /** Test / hidden-tab seam. */
  env?: Partial<ScenePreloaderEnv>;
}

/** Plain snapshot for the `window.__vertie` no-screenshot verification channel. */
export interface ScenePreloaderDebug {
  phase: PreloadPhase;
  progress: number;
  gated: boolean;
  gateFired: boolean;
  started: boolean;
  /**
   * How far below the fold the region still was when the preload fired (px). Positive =
   * the lead time actually bought; NaN when the preload was not gate-started.
   */
  startedAtDistancePx: number;
  units: number;
  decoded: number;
  bytes: { loaded: number; total: number };
  fetchMs: number;
  decodeMs: number;
  warmMs: number;
  totalMs: number;
  /** Longest single decode step observed — the piece that would have blocked a frame. */
  longestDecodeMs: number;
  error: string | null;
}

interface PlannedUnit {
  id: string;
  /** Model assets report fetch + decode; the environment reports decode only. */
  hasFetch: boolean;
}

interface UnitState {
  fetched: number;
  decoded: number;
  loaded: number;
  total: number;
}

/** Which assets this scene will load — the denominator progress needs before any event. */
function planUnits(scene: Scene): PlannedUnit[] {
  const assets = scene.assets ?? {};
  const units: PlannedUnit[] = [];
  for (const track of scene.tracks) {
    if (track.role === "camera") continue;
    if (assets[(track as ObjectTrack).asset]) units.push({ id: track.id, hasFetch: true });
  }
  const envKey = scene.environment?.envMap;
  if (envKey && assets[envKey]) units.push({ id: "environment", hasFetch: false });
  return units;
}

function abortError(): Error {
  const Ctor = (globalThis as { DOMException?: typeof DOMException }).DOMException;
  if (typeof Ctor === "function") return new Ctor("vertie: preload aborted", "AbortError");
  const err = new Error("vertie: preload aborted");
  err.name = "AbortError";
  return err;
}

function isAbortError(err: unknown): boolean {
  return err instanceof Error && err.name === "AbortError";
}

export function defaultPreloaderEnv(): ScenePreloaderEnv {
  return {
    observe(target, rootMargin, onNear) {
      if (typeof IntersectionObserver !== "function") {
        onNear();
        return () => {};
      }
      const observer = new IntersectionObserver(
        (entries) => {
          if (entries.some((entry) => entry.isIntersecting)) onNear();
        },
        { rootMargin },
      );
      observer.observe(target);
      return () => observer.disconnect();
    },
    distanceToViewport(target) {
      const rect = target.getBoundingClientRect();
      const viewport = typeof window === "undefined" ? 0 : window.innerHeight;
      return rect.top - viewport;
    },
    now: () => (typeof performance === "undefined" ? Date.now() : performance.now()),
    schedule: yieldToBrowser,
  };
}

export class ScenePreloader {
  private readonly target: PreloadTarget;
  private readonly scene: Scene;
  private readonly env: ScenePreloaderEnv;
  private readonly rootMargin: string;
  private readonly doWarm: boolean;
  private readonly onProgressFn: ScenePreloaderOptions["onProgress"];
  private readonly onPhaseFn: ScenePreloaderOptions["onPhase"];

  private readonly controller = new AbortController();
  private readonly planned: PlannedUnit[];
  private readonly units = new Map<string, UnitState>();

  private phaseValue: PreloadPhase = "idle";
  private progressValue = 0;
  private runPromise: Promise<void> | null = null;
  private gatePromise: Promise<void> | null = null;
  private gateTeardown: (() => void) | null = null;
  private rejectGate: ((reason: Error) => void) | null = null;
  private gated = false;
  private gateFired = false;
  private warmDone = false;
  private destroyed = false;
  private startedAtDistancePx = NaN;
  private errorMessage: string | null = null;

  private startedAt = 0;
  private lastFetchAt = 0;
  private firstDecodeAt = 0;
  private lastDecodeAt = 0;
  private loadEndedAt = 0;
  private warmMs = 0;
  private longestDecodeMs = 0;

  constructor(target: PreloadTarget, scene: Scene, options: ScenePreloaderOptions = {}) {
    this.target = target;
    this.scene = scene;
    this.env = { ...defaultPreloaderEnv(), ...options.env };
    this.rootMargin = options.rootMargin ?? DEFAULT_ROOT_MARGIN;
    this.doWarm = options.warm ?? true;
    this.onProgressFn = options.onProgress;
    this.onPhaseFn = options.onPhase;
    this.planned = planUnits(scene);
  }

  get phase(): PreloadPhase {
    return this.phaseValue;
  }

  get progress(): number {
    return this.progressValue;
  }

  get debug(): ScenePreloaderDebug {
    let loaded = 0;
    let total = 0;
    let decoded = 0;
    for (const unit of this.units.values()) {
      loaded += unit.loaded;
      total += unit.total;
      decoded += unit.decoded;
    }
    return {
      phase: this.phaseValue,
      progress: this.progressValue,
      gated: this.gated,
      gateFired: this.gateFired,
      started: this.runPromise !== null,
      startedAtDistancePx: this.startedAtDistancePx,
      units: this.planned.length,
      decoded,
      bytes: { loaded, total },
      fetchMs: this.firstDecodeAt === 0 ? 0 : this.firstDecodeAt - this.startedAt,
      decodeMs: this.firstDecodeAt === 0 ? 0 : this.lastDecodeAt - this.firstDecodeAt,
      warmMs: this.warmMs,
      totalMs: this.loadEndedAt === 0 ? 0 : this.loadEndedAt - this.startedAt,
      longestDecodeMs: this.longestDecodeMs,
      error: this.errorMessage,
    };
  }

  /**
   * Arm the gate: load once `target` comes within `rootMargin` of the viewport. The
   * returned promise resolves when the scene is ready (rejects on error or teardown).
   * Idempotent — a second call returns the same promise.
   */
  startWhenNear(target: Element, options: { rootMargin?: string } = {}): Promise<void> {
    if (this.gatePromise) return this.gatePromise;
    const rootMargin = options.rootMargin ?? this.rootMargin;

    this.gatePromise = new Promise<void>((resolve, reject) => {
      if (this.controller.signal.aborted) {
        reject(abortError());
        return;
      }
      this.rejectGate = reject;
      this.gated = true;

      const onNear = (): void => {
        if (this.gateFired || this.controller.signal.aborted) return;
        this.gateFired = true;
        this.startedAtDistancePx = this.measureDistance(target);
        this.closeGate();
        resolve(this.start());
      };

      // The observe seam may fire synchronously (no IntersectionObserver → load now),
      // i.e. before there is a teardown handle to store — hence the post-hoc check.
      const teardown = this.env.observe(target, rootMargin, onNear);
      if (this.gateFired) teardown();
      else this.gateTeardown = teardown;
    });
    this.gatePromise.catch(() => {}); // the caller may ignore it; never an unhandled rejection
    return this.gatePromise;
  }

  /** Start immediately (no gate). Idempotent — later calls return the same promise. */
  start(): Promise<void> {
    if (!this.runPromise) {
      this.runPromise = this.run();
      this.runPromise.catch(() => {});
    }
    return this.runPromise;
  }

  /**
   * Cancel: abort in-flight fetches, stop before the next decode, disconnect the gate.
   * Terminal — a preloader is single-shot, so a cancelled one is not restartable
   * (a half-built scene graph must be thrown away with its renderer, not resumed).
   */
  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    const reject = this.rejectGate;
    this.closeGate();
    this.controller.abort(abortError());
    if (this.phaseValue !== "ready" && this.phaseValue !== "error") this.setPhase("aborted");
    reject?.(abortError());
  }

  /** Alias of `destroy()` — name parity with `AbortController` for load-side callers. */
  abort(): void {
    this.destroy();
  }

  private async run(): Promise<void> {
    this.startedAt = this.env.now();
    try {
      this.controller.signal.throwIfAborted();
      this.setPhase("fetching");
      await this.target.load(this.scene, {
        signal: this.controller.signal,
        schedule: this.env.schedule,
        onProgress: (event) => this.onLoadProgress(event),
      });
      this.controller.signal.throwIfAborted();

      if (this.doWarm) {
        this.setPhase("warming");
        const warmStart = this.env.now();
        await this.target.warm();
        this.warmMs = this.env.now() - warmStart;
        this.controller.signal.throwIfAborted();
      }
      this.warmDone = true;
      this.loadEndedAt = this.env.now();
      this.emit();
      this.setPhase("ready");
    } catch (err) {
      this.loadEndedAt = this.env.now();
      if (isAbortError(err) || this.controller.signal.aborted) {
        this.setPhase("aborted");
      } else {
        this.errorMessage = err instanceof Error ? err.message : String(err);
        this.setPhase("error");
        this.controller.abort(abortError()); // stop the sibling fetches still in flight
      }
      throw err;
    }
  }

  private onLoadProgress(event: LoadProgressEvent): void {
    let unit = this.units.get(event.id);
    if (!unit) {
      unit = { fetched: 0, decoded: 0, loaded: 0, total: 0 };
      this.units.set(event.id, unit);
    }

    if (event.step === "fetch") {
      unit.loaded = Math.max(unit.loaded, event.loaded);
      unit.total = Math.max(unit.total, event.total);
      unit.fetched = event.done ? 1 : unit.total > 0 ? Math.min(1, event.loaded / unit.total) : 0;
      if (event.done) this.lastFetchAt = this.env.now();
    } else {
      unit.decoded = 1;
      unit.fetched = 1; // you cannot decode what has not fully arrived
      const now = this.env.now();
      // Gap since the previous decode landed ≈ how long this unit's decode ran. The
      // first one measures from the end of the fetch phase (decodes only start once
      // the bytes are in) — measuring it from `startedAt` would bill it the download.
      const since = this.lastDecodeAt || this.lastFetchAt || this.startedAt;
      this.longestDecodeMs = Math.max(this.longestDecodeMs, now - since);
      if (this.firstDecodeAt === 0) {
        this.firstDecodeAt = now;
        this.setPhase("decoding");
      }
      this.lastDecodeAt = now;
    }
    this.emit();
  }

  private measureDistance(target: Element): number {
    try {
      return this.env.distanceToViewport(target);
    } catch {
      return NaN; // a diagnostic must never break the load
    }
  }

  private closeGate(): void {
    this.gateTeardown?.();
    this.gateTeardown = null;
    this.rejectGate = null;
  }

  private setPhase(phase: PreloadPhase): void {
    if (this.phaseValue === phase) return;
    this.phaseValue = phase;
    this.onProgressFn?.(this.progressValue, phase); // a phase change is progress news too
    this.onPhaseFn?.(phase);
  }

  /** Recompute progress (monotonic — a lying Content-Length must not walk it back). */
  private emit(): void {
    let sum = 0;
    for (const planned of this.planned) {
      const unit = this.units.get(planned.id);
      if (!unit) continue;
      sum += planned.hasFetch ? FETCH_SHARE * unit.fetched + (1 - FETCH_SHARE) * unit.decoded : unit.decoded;
    }
    const loadPart = this.planned.length === 0 ? 1 : sum / this.planned.length;
    const warmShare = this.doWarm ? WARM_SHARE : 0;
    const next = (1 - warmShare) * loadPart + warmShare * (this.warmDone ? 1 : 0);

    const clamped = Math.min(1, Math.max(this.progressValue, next));
    if (clamped === this.progressValue) return;
    this.progressValue = clamped;
    this.onProgressFn?.(clamped, this.phaseValue);
  }
}
