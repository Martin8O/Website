/**
 * A bounded wait (C8b) — the guard that turns three's silent decoder hang into an error.
 *
 * three's Draco/KTX2 loaders fetch their decoder payload with a `FileLoader`, then build
 * a worker out of the text they got back. A server that answers 200 with *something else*
 * — a dev server serving `index.html` for an unknown path, a stale CDN, a wrong
 * `decoderPath` — satisfies that fetch, and the worker then dies at init without ever
 * posting a message. The decode promise never settles: no error, no console output, the
 * player sits at "decoding" forever (C8 lost real time to exactly this).
 *
 * Nothing in the load pipeline could catch it, because nothing was watching the clock.
 * `withTimeout` is that clock: pure, three-free, DOM-free, unit-testable with fake timers.
 * The error is built lazily — assembling the diagnosis may cost real work (parsing a
 * glTF header), and the whole point is that it costs nothing on the happy path.
 */

/** Fraction of the budget after which a still-pending wait warns (see `onSlow`). */
export const SLOW_WARNING_FRACTION = 0.25;

export interface TimeoutGuard {
  /** Budget in ms. Zero, negative or non-finite disables the guard entirely. */
  ms: number;
  /** Built only when the deadline is actually hit. */
  onTimeout: (elapsedMs: number) => Error;
  /**
   * Fired once at `SLOW_WARNING_FRACTION` of the budget while the work is still pending.
   * A slow decode on a weak device is legitimate, so it must not be killed early — but
   * the diagnosis should reach the console in seconds, not at the deadline.
   */
  onSlow?: ((elapsedMs: number) => void) | undefined;
  /** Abort the wait early (a cancelled load must not stay pending behind a hung worker). */
  signal?: AbortSignal | undefined;
  /** Injectable clock/timers — the tests use fake ones. */
  timers?: TimeoutTimers | undefined;
}

/** The two timer functions and the clock, isolated so tests can drive them. */
export interface TimeoutTimers {
  setTimeout: (fn: () => void, ms: number) => unknown;
  clearTimeout: (handle: unknown) => void;
  now: () => number;
}

const defaultTimers: TimeoutTimers = {
  setTimeout: (fn, ms) => setTimeout(fn, ms),
  clearTimeout: (handle) => clearTimeout(handle as ReturnType<typeof setTimeout>),
  now: () => (typeof performance === "undefined" ? Date.now() : performance.now()),
};

/**
 * Resolve/reject exactly as `work` does, unless the budget runs out first — in which case
 * the returned promise rejects with `onTimeout(elapsed)`. Timers are always cleared, so a
 * fast decode leaves nothing behind that could keep a timer queue (or a test) alive.
 */
export function withTimeout<T>(work: Promise<T>, guard: TimeoutGuard): Promise<T> {
  const { ms, signal } = guard;
  const timers = guard.timers ?? defaultTimers;
  if (!Number.isFinite(ms) || ms <= 0) return work;

  const started = timers.now();
  let deadline: unknown;
  let slow: unknown;
  let onAbort: (() => void) | undefined;

  const clear = (): void => {
    timers.clearTimeout(deadline);
    if (slow !== undefined) timers.clearTimeout(slow);
    if (onAbort) signal?.removeEventListener("abort", onAbort);
  };

  const raced = new Promise<never>((_resolve, reject) => {
    deadline = timers.setTimeout(() => reject(guard.onTimeout(timers.now() - started)), ms);
    if (guard.onSlow) {
      slow = timers.setTimeout(() => guard.onSlow?.(timers.now() - started), ms * SLOW_WARNING_FRACTION);
    }
    if (signal) {
      if (signal.aborted) reject(asAbortReason(signal));
      else {
        onAbort = (): void => reject(asAbortReason(signal));
        signal.addEventListener("abort", onAbort, { once: true });
      }
    }
  });

  // The loser of the race still settles later; a rejection nobody awaits any more would
  // surface as an unhandled rejection, so it is claimed here.
  work.catch(() => {});
  raced.catch(() => {});

  return Promise.race([work, raced]).finally(clear);
}

/** The signal's own reason, or a plain `AbortError` when it carries none. */
function asAbortReason(signal: AbortSignal): unknown {
  if (signal.reason !== undefined) return signal.reason;
  const err = new Error("vertie: aborted");
  err.name = "AbortError";
  return err;
}
