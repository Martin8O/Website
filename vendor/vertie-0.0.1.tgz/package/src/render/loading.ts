/**
 * The load-stage contract (C4b) — defined once, here, because two modules meet on it:
 * `SceneRenderer.load()` emits these events, and `ScenePreloader` aggregates them into
 * a phase + a 0..1 progress figure. Keeping the shape in a three-free module is what
 * lets the preloader (and its tests) stay free of three and of a GPU.
 */

import type { ScheduleFn } from "./schedule.js";

/**
 * One step of one asset. `id` is the object track's id, or `"environment"` for the
 * env map. Model assets report both steps; the environment reports only `"decode"`,
 * because three's texture loaders own their own fetch and cannot be split.
 */
export interface LoadProgressEvent {
  id: string;
  step: "fetch" | "decode";
  /** Bytes received (fetch) or 1 when the decode finished. */
  loaded: number;
  /** Expected bytes when the server declared a length, else 0 = unknown. */
  total: number;
  /** True on the event that completes this step. */
  done: boolean;
}

export interface SceneLoadOptions {
  /** Abort in-flight fetches and stop before the next decode. Terminal — no resume. */
  signal?: AbortSignal | undefined;
  /** Per-asset step reporting (drives `ScenePreloader`'s progress/phase). */
  onProgress?: ((event: LoadProgressEvent) => void) | undefined;
  /** Yield between decode units. Default `yieldToBrowser`. */
  schedule?: ScheduleFn | undefined;
}
