/**
 * The implicit fixed camera derived from a scene's `stage` (spec §8/§9): when a scene
 * has no `role:"camera"` track, the `stage` declaration acts as the camera. This is
 * the pure framing math — position the camera down +Z so the authored reference plane
 * (`width × height`, centered on the view axis at depth `z`) fits the viewport per
 * `fit`. No DOM, no three (plain trig) → unit-testable with golden values.
 *
 * Also here since E1: the per-key data-aware frustum clamp (§9) — still not a mandatory
 * feature (ADR-017 keeps it an OPTIONAL runtime policy, off unless a host asks for it),
 * but it lives next to the framing math it is about, and is just as pure.
 */

import type { Vec3, Quat, Stage } from "../format/types.js";

/** Vertical FOV of the proven stage camera when the scene declares none (spec §8/§9). */
export const DEFAULT_STAGE_FOV = 55;

/** A fixed camera placement: identity orientation looks down −Z (three convention). */
export interface StageCamera {
  position: Vec3;
  quaternion: Quat;
  /** Vertical field of view in degrees. */
  fov: number;
}

/**
 * Camera pose that frames the stage plane at the given viewport `aspect` (width/height).
 * With no `plane` we cannot frame a composition — fall back to a sensible fixed camera
 * on +Z. `fit: "contain"` (default) keeps the whole plane visible; `"cover"` fills the
 * viewport (the plane may overflow).
 */
export function stageCameraPose(stage: Stage | undefined, aspect: number): StageCamera {
  const fov = stage?.fov ?? DEFAULT_STAGE_FOV;
  const plane = stage?.plane;
  const quaternion: Quat = [0, 0, 0, 1]; // identity → looks down −Z

  if (!plane || !(aspect > 0)) {
    return { position: [0, 0, 5], quaternion, fov };
  }

  const tanV = Math.tan((fov * Math.PI) / 180 / 2);
  // Distance at which the plane half-height (vertical) / half-width (horizontal) just
  // touches the frustum edge. Horizontal uses the aspect-widened half-FOV.
  const distV = plane.height / 2 / tanV;
  const distH = plane.width / 2 / (aspect * tanV);
  const fit = stage?.fit ?? "contain";
  const dist = fit === "cover" ? Math.min(distV, distH) : Math.max(distV, distH);

  // Plane sits at depth `plane.z`; the camera stands `dist` in front of it (toward +Z).
  return { position: [0, 0, plane.z + dist], quaternion, fov };
}

/**
 * Per-axis scale factors from the §9 data-aware clamp. `1` = the authored data, untouched;
 * the clamp never scales UP, because the bake is the maximum the author composed for.
 */
export interface FrustumClamp {
  x: number;
  y: number;
}

/**
 * The identity clamp — what a scene gets when the policy is off or cannot apply. Frozen
 * because it is both a public export and the value a renderer holds internally: an
 * unfrozen singleton would let one consumer's stray write retune every scene on the page.
 */
export const NO_FRUSTUM_CLAMP: FrustumClamp = Object.freeze({ x: 1, y: 1 });

/** Fraction of the half-frustum a key may occupy when the policy is switched on bare. */
export const DEFAULT_CLAMP_MARGIN = 1;

/** Below this the key sits on the view axis and constrains nothing. */
const AXIS_EPSILON = 1e-3;

/**
 * The §9 **data-aware clamp**: scale each lateral axis so every authored key stays inside
 * the stage camera's frustum **at its own depth**, never scaling above the authored 1×.
 *
 * Why this exists (E1, ADR-017's "optional runtime policy" finally having a consumer):
 * choreography is often baked deliberately WIDE — "the maneuver must span the screen" — and
 * `fit: "contain"` only promises the reference PLANE, so a key that lives well in front of
 * or behind the plane can sit outside the viewport at a viewport the author never saw. The
 * origin engine solved it with a runtime lateral factor; this is that factor, generalized to
 * both axes and to any scene.
 *
 * `margin` is how much of the half-frustum a key may occupy (the origin engine used 0.87 —
 * a key is a pivot, and the model hanging off it needs room too).
 *
 * Deliberately key-based, not curve-based: a centripetal Catmull-Rom leg can overshoot its
 * keys slightly, so a key that lands exactly on the margin may still graze the edge mid-leg.
 * Sampling the curve would make the factor depend on the evaluator, and the whole point of
 * ADR-017 is that this policy stays outside it.
 */
export function frustumClampScale(
  stage: Stage | undefined,
  keys: Iterable<Vec3>,
  aspect: number,
  margin: number = DEFAULT_CLAMP_MARGIN,
): FrustumClamp {
  // No plane = no authored composition to protect, and the fallback camera is arbitrary.
  if (!stage?.plane || !(aspect > 0) || !(margin > 0)) return NO_FRUSTUM_CLAMP;

  const { position, fov } = stageCameraPose(stage, aspect);
  const camZ = position[2];
  const tanV = Math.tan((fov * Math.PI) / 180 / 2);

  let x = 1;
  let y = 1;
  for (const p of keys) {
    // Distance from the camera to the key's own depth — the whole point of the rule.
    const dist = camZ - p[2];
    if (!(dist > 0)) continue; // at or behind the camera: no meaningful half-extent
    const halfH = dist * tanV;
    const halfW = halfH * aspect;
    const ax = Math.abs(p[0]);
    const ay = Math.abs(p[1]);
    if (ax > AXIS_EPSILON) x = Math.min(x, (margin * halfW) / ax);
    if (ay > AXIS_EPSILON) y = Math.min(y, (margin * halfH) / ay);
  }
  return { x, y };
}
