/**
 * Timeline events (spec §10) — the pure half. Like everything in `core`, this is a
 * deterministic function of scene time: no DOM, no three, no wall clock. The element
 * turns what comes out of here into `vertie-event` DOM events (C9); the player itself
 * renders nothing for an event (ADR-014).
 *
 * The one non-obvious rule is that an event window is tested against the **interval**
 * `[previous, current]`, not against the current sample alone. A driver hands us
 * discrete, damped samples of t, so a `span: 0` point event almost never lands exactly
 * on a sample — and a fast scroll can jump clean over a whole window. Sampling alone
 * would silently drop both. Comparing intervals makes a point event fire the moment the
 * scrub crosses it (in either direction), and makes a skipped window emit `enter` and
 * `leave` in the same frame so a host that toggles something on `enter` is never left
 * stuck with it on.
 */

import type { Scene, SceneEvent } from "../format/types.js";

/** Which edge of an event's window this transition reports (§10). */
export type EventPhase = "enter" | "progress" | "leave";

/** Precompiled event — window resolved once, `x-*` payload extracted once. */
export interface CompiledEvent {
  name: string;
  /** Scene-local time the window opens. */
  at: number;
  /** Window length (0 = a point signal). */
  span: number;
  /** `at + span`. */
  end: number;
  /** Track id whose evaluated position is handed to the host while active, if any. */
  follow: string | undefined;
  /** The verbatim `x-*` payload, delivered to the host unchanged. */
  data: Record<string, unknown>;
}

/** One thing that happened to one event window during a single `update()`. */
export interface EventTransition {
  /** Index into the `CompiledEvent[]` this tracker was built from. */
  index: number;
  event: CompiledEvent;
  phase: EventPhase;
  /** Position inside the window, 0..1 (always 0 for a point event). */
  progress: number;
}

/** Everything under the sanctioned `x-*` namespace, copied out verbatim (ADR-004). */
function extractPayload(event: SceneEvent): Record<string, unknown> {
  const data: Record<string, unknown> = {};
  for (const key of Object.keys(event)) {
    if (key.startsWith("x-")) data[key] = (event as unknown as Record<string, unknown>)[key];
  }
  return data;
}

/**
 * Compile a scene's `events` into the immutable lookup `EventTracker` reads. Assumes a
 * document that passed `validateScene` (name/at present, `follow` resolvable — §13).
 */
export function compileEvents(scene: Scene): CompiledEvent[] {
  return (scene.events ?? []).map((event) => {
    const span = event.span ?? 0;
    return {
      name: event.name,
      at: event.at,
      span,
      end: event.at + span,
      follow: event.follow,
      data: extractPayload(event),
    };
  });
}

const clamp01 = (x: number): number => (x > 0 ? (x > 1 ? 1 : x) : 0);

/** Position inside the window; a point event has no inside, so it reports 0. */
function progressAt(event: CompiledEvent, time: number): number {
  return event.span > 0 ? clamp01((time - event.at) / event.span) : 0;
}

/** Does `[a, b]` (either order) touch the closed window `[at, end]`? */
function crosses(event: CompiledEvent, a: number, b: number): boolean {
  const lo = a < b ? a : b;
  const hi = a < b ? b : a;
  return lo <= event.end && hi >= event.at;
}

/**
 * Turns a stream of scene times into event transitions. Stateful by necessity (an
 * `enter` is only meaningful relative to what was active before) but still pure in the
 * `core` sense: given the same construction and the same sequence of `update()` calls it
 * produces the same output on every conformant player, with no reference to the outside
 * world.
 *
 * The transition array is reused between calls — read it (or copy what you need) before
 * the next `update()`.
 */
export class EventTracker {
  private readonly active: boolean[];
  /** Per-frame scratch: 1 = closed this frame, 2 = opened this frame. */
  private readonly touched: Uint8Array;
  private readonly out: EventTransition[] = [];
  private previous = 0;
  private seeded = false;

  constructor(private readonly events: CompiledEvent[]) {
    this.active = new Array<boolean>(events.length).fill(false);
    this.touched = new Uint8Array(events.length);
  }

  /** Currently-open window names, in document order (verification surface). */
  get activeNames(): string[] {
    const names: string[] = [];
    for (let i = 0; i < this.events.length; i++) if (this.active[i]) names.push(this.events[i]!.name);
    return names;
  }

  /**
   * Forget all history. The next `update()` seeds from that time WITHOUT crossing
   * detection — a scene that becomes ready while the page is already scrolled to t=1
   * must not replay its whole timeline into the host.
   */
  reset(): void {
    this.active.fill(false);
    this.previous = 0;
    this.seeded = false;
  }

  /**
   * Advance to `time` and return everything that happened since the last call. Order
   * within a frame: every `leave` (document order), then every `enter`, then `progress`
   * for windows that stayed open — so a host swapping one caption for another always
   * sees the old one close before the new one opens.
   */
  update(time: number): EventTransition[] {
    this.out.length = 0;

    if (!this.seeded) {
      this.seeded = true;
      this.previous = time;
      for (let i = 0; i < this.events.length; i++) {
        const event = this.events[i]!;
        const inside = time >= event.at && time <= event.end;
        this.active[i] = inside;
        if (inside) this.push(i, "enter", progressAt(event, time));
      }
      return this.out;
    }

    const from = this.previous;
    this.previous = time;
    this.touched.fill(0);

    // Leaves first, across every event, before any enter (see the ordering note above).
    for (let i = 0; i < this.events.length; i++) {
      const event = this.events[i]!;
      if (!this.active[i]) continue;
      if (time >= event.at && time <= event.end) continue;
      this.active[i] = false;
      this.touched[i] = 1;
      // Report the edge we left through, not the sample we happened to land on.
      this.push(i, "leave", time < event.at ? 0 : event.span > 0 ? 1 : 0);
    }

    for (let i = 0; i < this.events.length; i++) {
      const event = this.events[i]!;
      // Still open, or already closed this frame — a window cannot be re-entered inside
      // one monotone interval, so a leave this frame ends the story for this event.
      if (this.active[i] || this.touched[i] === 1) continue;
      if (time >= event.at && time <= event.end) {
        this.active[i] = true;
        this.touched[i] = 2;
        this.push(i, "enter", progressAt(event, time));
      } else if (crosses(event, from, time)) {
        // Jumped clean over the window in one frame: the host still gets both edges, so
        // nothing it turned on at `enter` can be left on forever.
        const forward = from < time;
        this.push(i, "enter", forward ? 0 : 1);
        this.push(i, "leave", forward ? 1 : 0);
      }
    }

    // Only windows that were already open report progress; an `enter` this same frame
    // already carried the position.
    for (let i = 0; i < this.events.length; i++) {
      if (!this.active[i] || this.touched[i] === 2) continue;
      this.push(i, "progress", progressAt(this.events[i]!, time));
    }

    return this.out;
  }

  private push(index: number, phase: EventPhase, progress: number): void {
    this.out.push({ index, event: this.events[index]!, phase, progress });
  }
}
