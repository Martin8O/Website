/**
 * The `core` layer: the pure, DOM-free, deterministic scene evaluator (spec §12).
 *
 * `format` (types + validation) → **`core` (this)** → drivers → render → element.
 * Depends only on `format` types; imports no DOM, no three.js. A 1:1 port of the
 * proven Website engine (`climbMath.ts`) plus `lookAt` camera derivation.
 */
export { compileScene, evaluate, createSceneState } from "./evaluate.js";

export {
  buildWarp,
  evalWarp,
  catmullRomAt,
  slerpQuat,
  lookAtQuat,
  WORLD_UP,
  type Warp,
} from "./interpolate.js";

export { compileEvents, EventTracker } from "./events.js";
export type { CompiledEvent, EventTransition, EventPhase } from "./events.js";

export type {
  Pose,
  TrackState,
  CameraState,
  SceneState,
  CompiledTrack,
  CompiledCamera,
  CompiledScene,
} from "./types.js";
