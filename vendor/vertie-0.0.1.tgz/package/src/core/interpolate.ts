/**
 * Pure interpolation primitives — the mathematical heart of the evaluator
 * (spec §12, "Evaluation semantics — normative").
 *
 * `buildWarp` / `evalWarp` / `catmullRomAt` / `slerpQuat` are a **faithful 1:1
 * port** of the production-proven engine `climbMath.ts` from the Website repo
 * (the code that already renders the site's hero climb). Porting rather than
 * reinventing is deliberate: the Website carries the golden tests, and Vertie's
 * `test/core/climb-golden.test.ts` pins this port to that engine's output to
 * ≤1e-9. `lookAtQuat` is the one addition the climb never needed (spec §8 /
 * ADR-016: a camera that derives its orientation from a target).
 *
 * Everything here is pure, DOM-free and three-free (CLAUDE.md hard rule) and
 * allocation-conscious (out-params on the per-frame path).
 */

import type { Vec3, Quat } from "../format/types.js";

// ── monotone-cubic time warp (Fritsch–Carlson) ──────────────────────────────
// One monotone interpolant u(t) through the knots (Ti → i/(n-1)): exact at every
// knot, monotone non-decreasing (no reversal/overshoot), C1-continuous, clamped
// to [0,1] outside the span. A zero-length leg evaluates as an instant cut.

/** A compiled time-warp: knot times `x`, normalized targets `y`, tangents `m`. */
export interface Warp {
  readonly x: readonly number[];
  readonly y: readonly number[];
  readonly m: readonly number[];
  readonly n: number;
}

// The `!` non-null assertions below are on numeric array reads whose indices are
// in-bounds by construction (loop bounds / knot counts); `noUncheckedIndexedAccess`
// cannot see that, and this is trusted internal math (not untrusted input).

/** Build the Fritsch–Carlson warp through `n` knot times `sc` (ascending). */
export function buildWarp(sc: readonly number[], n: number): Warp {
  const y = Array.from({ length: n }, (_, i) => i / (n - 1));
  const seg = n - 1;
  const d = new Array<number>(seg);
  const m = new Array<number>(n).fill(0);
  for (let i = 0; i < seg; i++) {
    const dx = sc[i + 1]! - sc[i]!;
    d[i] = dx > 1e-9 ? (y[i + 1]! - y[i]!) / dx : Infinity;
  }
  for (let i = 0; i < n; i++) {
    if (i === 0) m[i] = isFinite(d[0]!) ? d[0]! : 0;
    else if (i === seg) m[i] = isFinite(d[seg - 1]!) ? d[seg - 1]! : 0;
    else {
      const a = d[i - 1]!;
      const b = d[i]!;
      m[i] = !isFinite(a) || !isFinite(b) || a <= 0 || b <= 0 ? 0 : (a + b) / 2;
    }
  }
  for (let i = 0; i < seg; i++) {
    // Fritsch–Carlson clamp → guaranteed monotone (no overshoot / reversal).
    const di = d[i]!;
    if (!isFinite(di) || di === 0) {
      m[i] = 0;
      m[i + 1] = 0;
      continue;
    }
    const a = m[i]! / di;
    const b = m[i + 1]! / di;
    const s = a * a + b * b;
    if (s > 9) {
      const tau = 3 / Math.sqrt(s);
      m[i] = tau * a * di;
      m[i + 1] = tau * b * di;
    }
  }
  return { x: sc, y, m, n };
}

/** Evaluate the warp at time `f`, returning `u ∈ [0,1]` (clamped outside span). */
export function evalWarp(w: Warp, f: number): number {
  const { x, y, m, n } = w;
  if (f <= x[0]!) return 0;
  if (f >= x[n - 1]!) return 1;
  let i = 0;
  while (i < n - 2 && f > x[i + 1]!) i++;
  const dx = x[i + 1]! - x[i]!;
  if (dx < 1e-9) return y[i + 1]!; // instant cut
  const h = (f - x[i]!) / dx;
  const h2 = h * h;
  const h3 = h2 * h;
  const m0 = m[i]! * dx;
  const m1 = m[i + 1]! * dx;
  return (
    (2 * h3 - 3 * h2 + 1) * y[i]! +
    (h3 - 2 * h2 + h) * m0 +
    (-2 * h3 + 3 * h2) * y[i + 1]! +
    (h3 - h2) * m1
  );
}

// ── centripetal Catmull-Rom (THREE.CatmullRomCurve3's default) ───────────────
// Ported so a runtime path IS the lab path (uniform CR bends corners differently).

interface Cubic {
  c0: number;
  c1: number;
  c2: number;
  c3: number;
}

function nonuniformCR(
  x0: number,
  x1: number,
  x2: number,
  x3: number,
  dt0: number,
  dt1: number,
  dt2: number,
): Cubic {
  let t1 = (x1 - x0) / dt0 - (x2 - x0) / (dt0 + dt1) + (x2 - x1) / dt1;
  let t2 = (x2 - x1) / dt1 - (x3 - x1) / (dt1 + dt2) + (x3 - x2) / dt2;
  t1 *= dt1;
  t2 *= dt1;
  return { c0: x1, c1: t1, c2: -3 * x1 + 3 * x2 - 2 * t1 - t2, c3: 2 * x1 - 2 * x2 + t1 + t2 };
}

const cubicAt = (c: Cubic, t: number): number => c.c0 + (c.c1 + (c.c2 + c.c3 * t) * t) * t;

/**
 * Evaluate the centripetal Catmull-Rom through `points` at `u ∈ [0,1]`, writing
 * into `out`. Faithful port of THREE.CatmullRomCurve3.getPoint: `dt = ‖Δp‖^0.5`
 * parameterization with degenerate-segment guards and reflected virtual ends.
 * The curve parameter is uniform per segment — pacing is entirely the warp's job.
 */
export function catmullRomAt(points: readonly Vec3[], u: number, out: Vec3): void {
  const l = points.length;
  if (l === 1) {
    const only = points[0]!;
    out[0] = only[0];
    out[1] = only[1];
    out[2] = only[2];
    return;
  }
  const p = (l - 1) * u;
  let intPoint = Math.floor(p);
  let weight = p - intPoint;
  if (weight === 0 && intPoint === l - 1) {
    intPoint = l - 2;
    weight = 1;
  }
  if (intPoint < 0) {
    intPoint = 0;
    weight = 0;
  }
  // In-bounds by construction (l ≥ 2, 0 ≤ intPoint ≤ l−2); reflect virtual ends.
  const first = points[0]!;
  const second = points[1]!;
  const last = points[l - 1]!;
  const penult = points[l - 2]!;
  const p1 = points[intPoint]!;
  const p2 = points[Math.min(intPoint + 1, l - 1)]!;
  const p0: Vec3 =
    intPoint > 0
      ? points[intPoint - 1]!
      : [2 * first[0] - second[0], 2 * first[1] - second[1], 2 * first[2] - second[2]];
  const p3: Vec3 =
    intPoint + 2 < l
      ? points[intPoint + 2]!
      : [2 * last[0] - penult[0], 2 * last[1] - penult[1], 2 * last[2] - penult[2]];

  const d2 = (a: Vec3, b: Vec3): number =>
    (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2;
  let dt1 = Math.pow(d2(p1, p2), 0.25);
  let dt0 = Math.pow(d2(p0, p1), 0.25);
  let dt2 = Math.pow(d2(p2, p3), 0.25);
  if (dt1 < 1e-4) dt1 = 1.0;
  if (dt0 < 1e-4) dt0 = dt1;
  if (dt2 < 1e-4) dt2 = dt1;

  out[0] = cubicAt(nonuniformCR(p0[0], p1[0], p2[0], p3[0], dt0, dt1, dt2), weight);
  out[1] = cubicAt(nonuniformCR(p0[1], p1[1], p2[1], p3[1], dt0, dt1, dt2), weight);
  out[2] = cubicAt(nonuniformCR(p0[2], p1[2], p2[2], p3[2], dt0, dt1, dt2), weight);
}

// ── quaternion interpolation ─────────────────────────────────────────────────

/** Quaternion slerp `(x, y, z, w)`, shortest-path, output re-normalized. */
export function slerpQuat(a: Quat, b: Quat, t: number, out: Quat): void {
  let bx = b[0];
  let by = b[1];
  let bz = b[2];
  let bw = b[3];
  let cos = a[0] * bx + a[1] * by + a[2] * bz + a[3] * bw;
  if (cos < 0) {
    cos = -cos;
    bx = -bx;
    by = -by;
    bz = -bz;
    bw = -bw;
  }
  let s0: number;
  let s1: number;
  if (cos > 0.9995) {
    s0 = 1 - t;
    s1 = t;
  } else {
    const omega = Math.acos(Math.min(cos, 1));
    const sin = Math.sin(omega);
    s0 = Math.sin((1 - t) * omega) / sin;
    s1 = Math.sin(t * omega) / sin;
  }
  const x = s0 * a[0] + s1 * bx;
  const y = s0 * a[1] + s1 * by;
  const z = s0 * a[2] + s1 * bz;
  const w = s0 * a[3] + s1 * bw;
  const len = Math.hypot(x, y, z, w) || 1;
  out[0] = x / len;
  out[1] = y / len;
  out[2] = z / len;
  out[3] = w / len;
}

// ── look-at orientation (spec §8 / ADR-016) — the one non-port ───────────────
// A camera at `eye` aimed at `target`. Mirrors three.js `Matrix4.lookAt` (basis
// z = eye−target, x = up×z, y = z×x; camera looks down its local −z) followed by
// `Quaternion.setFromRotationMatrix`, so a three.js renderer that does
// `camera.quaternion.setFromRotationMatrix(m.lookAt(...))` derives the identical
// orientation — the ADR-010 golden-image guarantee reaches the camera too.

/** Default world up used for `lookAt` derivation. */
export const WORLD_UP: Vec3 = [0, 1, 0];

/**
 * Write into `out` the orientation of a camera at `eye` looking at `target`,
 * with world up `up`. Degenerate cases (eye==target, look‖up) are nudged exactly
 * as three.js does, so the result is always a valid unit quaternion.
 */
export function lookAtQuat(eye: Vec3, target: Vec3, up: Vec3, out: Quat): void {
  // z = normalize(eye - target)
  let zx = eye[0] - target[0];
  let zy = eye[1] - target[1];
  let zz = eye[2] - target[2];
  if (zx * zx + zy * zy + zz * zz === 0) zz = 1;
  let inv = 1 / Math.hypot(zx, zy, zz);
  zx *= inv;
  zy *= inv;
  zz *= inv;
  // x = normalize(up × z)
  let xx = up[1] * zz - up[2] * zy;
  let xy = up[2] * zx - up[0] * zz;
  let xz = up[0] * zy - up[1] * zx;
  if (xx * xx + xy * xy + xz * xz === 0) {
    // up ‖ z → nudge z (three.js perturbation) and retry.
    if (Math.abs(up[2]) === 1) zx += 0.0001;
    else zz += 0.0001;
    inv = 1 / Math.hypot(zx, zy, zz);
    zx *= inv;
    zy *= inv;
    zz *= inv;
    xx = up[1] * zz - up[2] * zy;
    xy = up[2] * zx - up[0] * zz;
    xz = up[0] * zy - up[1] * zx;
  }
  inv = 1 / Math.hypot(xx, xy, xz);
  xx *= inv;
  xy *= inv;
  xz *= inv;
  // y = z × x  (already unit: z,x orthonormal)
  const yx = zy * xz - zz * xy;
  const yy = zz * xx - zx * xz;
  const yz = zx * xy - zy * xx;
  // Rotation matrix columns are (x, y, z); convert to quaternion.
  matrixToQuat(xx, yx, zx, xy, yy, zy, xz, yz, zz, out);
}

/** three.js `Quaternion.setFromRotationMatrix` (column-major basis passed row-wise). */
function matrixToQuat(
  m11: number, m12: number, m13: number,
  m21: number, m22: number, m23: number,
  m31: number, m32: number, m33: number,
  out: Quat,
): void {
  const trace = m11 + m22 + m33;
  if (trace > 0) {
    const s = 0.5 / Math.sqrt(trace + 1.0);
    out[3] = 0.25 / s;
    out[0] = (m32 - m23) * s;
    out[1] = (m13 - m31) * s;
    out[2] = (m21 - m12) * s;
  } else if (m11 > m22 && m11 > m33) {
    const s = 2.0 * Math.sqrt(1.0 + m11 - m22 - m33);
    out[3] = (m32 - m23) / s;
    out[0] = 0.25 * s;
    out[1] = (m12 + m21) / s;
    out[2] = (m13 + m31) / s;
  } else if (m22 > m33) {
    const s = 2.0 * Math.sqrt(1.0 + m22 - m11 - m33);
    out[3] = (m13 - m31) / s;
    out[0] = (m12 + m21) / s;
    out[1] = 0.25 * s;
    out[2] = (m23 + m32) / s;
  } else {
    const s = 2.0 * Math.sqrt(1.0 + m33 - m11 - m22);
    out[3] = (m21 - m12) / s;
    out[0] = (m13 + m31) / s;
    out[1] = (m23 + m32) / s;
    out[2] = 0.25 * s;
  }
}
