/**
 * Output & compile-artifact types for the evaluator (`core` layer).
 *
 * `SceneState` is what the renderer (Phase C3) consumes each frame: it is a pure
 * function of the driver parameter, carrying nothing DOM- or GPU-specific. The
 * `Compiled*` types are the precomputed lookup built once by `compileScene`, so
 * `evaluate` on the `out` path allocates no new `SceneState` per frame (the curve
 * evaluator still creates small scratch temporaries — a candidate future micro-opt).
 */

import type { Vec3, Quat } from "../format/types.js";
import type { Warp } from "./interpolate.js";

/** A world-space placement: position + unit orientation quaternion. */
export interface Pose {
  p: Vec3;
  q: Quat;
}

/** Evaluated state of one object track at a given scene time. */
export interface TrackState {
  /** Track id (matches the scene's `ObjectTrack.id`). */
  id: string;
  /** Pose, always clamped to the track's span edges outside it (§12.4). */
  pose: Pose;
  /** Whether the object is rendered here (in-span, or `extrapolate` = "hold"). */
  visible: boolean;
  /** Opacity 0..1 from `fade` ramps (1 when held outside span, 0 when hidden). */
  opacity: number;
}

/** Evaluated camera state. `null` on the `SceneState` when the scene has no camera track. */
export interface CameraState {
  pose: Pose;
  /** Vertical field of view in degrees (§8, default 55). */
  fov: number;
}

/** The complete per-frame evaluation result. */
export interface SceneState {
  /** Scene-local time this state was evaluated at (`t · duration`). */
  time: number;
  /** One entry per object track, in document order. */
  tracks: TrackState[];
  /** The camera, or `null` for a camera-less scene (§8: falls back to `stage`). */
  camera: CameraState | null;
}

/** Precompiled object track — key times, warp and point list built once. */
export interface CompiledTrack {
  id: string;
  /** Manifest key of the animated asset. */
  asset: string;
  /** Absolute scene-local time of each key: `start + Σ preceding durations` (§6). */
  keyTimes: number[];
  /** Key positions and orientations, indexed with `keyTimes`. */
  points: Vec3[];
  quats: Quat[];
  /** Warp through `keyTimes`; `null` for a single-key (constant-pose) track. */
  warp: Warp | null;
  /** Span end = last key time (a trailing final-key `duration` is scene tail room, not span). */
  spanEnd: number;
  /** Rendered outside the span before / after it (§7 `extrapolate`, default hidden). */
  holdBefore: boolean;
  holdAfter: boolean;
  /** `fade` ramp lengths in scene-local units (§7, default 0 = instant). */
  fadeIn: number;
  fadeOut: number;
}

/** Precompiled camera track (§8). */
export interface CompiledCamera {
  keyTimes: number[];
  points: Vec3[];
  quats: Quat[];
  warp: Warp | null;
  fov: number;
  /** `lookAt` target: a track id (string) or a fixed point (Vec3); undefined = use key `q`. */
  lookAt: string | Vec3 | undefined;
}

/** The result of `compileScene` — the immutable lookup `evaluate` reads. */
export interface CompiledScene {
  /** Effective scene length (explicit root `duration`, else derived — §2). */
  duration: number;
  tracks: CompiledTrack[];
  camera: CompiledCamera | null;
}
