/**
 * The scene evaluator (spec §12): a validated `Scene` + a driver parameter
 * `t ∈ [0..1]` → per-track poses and the camera pose. Two steps:
 *
 *   compileScene(scene)          — once: precompute key times, warps, points.
 *   evaluate(compiled, t, out?)  — per frame: pure, deterministic; the `out` path
 *                                  reuses the SceneState buffer (no per-frame state
 *                                  allocation — the ported curve eval still creates
 *                                  small scratch temporaries, as the origin does).
 *
 * The driver boundary (spec §6): the driver yields normalized `t`; the evaluator
 * maps it to `sceneTime = t · duration`. Host-specific rebasing constants live in
 * the driver, never in scene data — which is exactly why this stays a pure
 * function of scene time.
 */

import type { Scene, Track, CameraTrack, ObjectTrack, Vec3, Quat } from "../format/types.js";
import type {
  CompiledScene,
  CompiledTrack,
  CompiledCamera,
  SceneState,
  Pose,
} from "./types.js";
import { buildWarp, evalWarp, catmullRomAt, slerpQuat, lookAtQuat, WORLD_UP } from "./interpolate.js";

const DEFAULT_FOV = 55;

const isCamera = (t: Track): t is CameraTrack => t.role === "camera";

/** Absolute scene-local time of each key: `start + Σ preceding durations` (§6). */
function keyTimesOf(track: Track): number[] {
  const start = track.start ?? 0;
  const times = [start];
  for (let i = 0; i < track.keys.length - 1; i++) {
    times.push(times[i]! + (track.keys[i]!.duration ?? 0));
  }
  return times;
}

/** Total time the track claims for the derived scene duration: includes a trailing final-key `duration` (§2). */
function durationContribution(track: Track): number {
  const start = track.start ?? 0;
  let sum = start;
  for (const k of track.keys) sum += k.duration ?? 0;
  return sum;
}

function compileTrack(track: ObjectTrack): CompiledTrack {
  const keyTimes = keyTimesOf(track);
  const n = track.keys.length;
  return {
    id: track.id,
    asset: track.asset,
    keyTimes,
    points: track.keys.map((k) => [...k.p] as Vec3),
    quats: track.keys.map((k) => [...k.q] as Quat),
    warp: n > 1 ? buildWarp(keyTimes, n) : null,
    spanEnd: keyTimes[n - 1]!,
    holdBefore: track.extrapolate?.before === "hold",
    holdAfter: track.extrapolate?.after === "hold",
    fadeIn: track.fade?.in ?? 0,
    fadeOut: track.fade?.out ?? 0,
  };
}

function compileCamera(track: CameraTrack): CompiledCamera {
  const keyTimes = keyTimesOf(track);
  const n = track.keys.length;
  return {
    keyTimes,
    points: track.keys.map((k) => [...k.p] as Vec3),
    quats: track.keys.map((k) => [...k.q] as Quat),
    warp: n > 1 ? buildWarp(keyTimes, n) : null,
    fov: track.camera?.fov ?? DEFAULT_FOV,
    lookAt: track.lookAt,
  };
}

/**
 * Compile a scene into the immutable lookup `evaluate` reads. Builds each track's
 * warp exactly once and resolves the effective scene duration (explicit root
 * `duration`, else derived from track and event ends — §2). Assumes a scene that
 * passed `validateScene` (e.g. every track has ≥ 1 key — a §13 hard error otherwise).
 */
export function compileScene(scene: Scene): CompiledScene {
  const tracks: CompiledTrack[] = [];
  let camera: CompiledCamera | null = null;
  for (const track of scene.tracks) {
    if (isCamera(track)) {
      // At most one camera track per document (validator enforces §8); first wins.
      if (!camera) camera = compileCamera(track);
    } else {
      tracks.push(compileTrack(track));
    }
  }

  let duration: number;
  if (typeof scene.duration === "number" && isFinite(scene.duration)) {
    duration = scene.duration;
  } else {
    duration = 0;
    for (const track of scene.tracks) duration = Math.max(duration, durationContribution(track));
    for (const ev of scene.events ?? []) duration = Math.max(duration, ev.at + (ev.span ?? 0));
  }

  return { duration, tracks, camera };
}

// ── per-frame evaluation ─────────────────────────────────────────────────────

// Clamp to [0,1]; a non-finite driver value (NaN) maps to 0 rather than poisoning
// the whole SceneState with NaN (the driver contract is t ∈ [0..1], §6).
const clamp01 = (x: number): number => (x > 0 ? (x > 1 ? 1 : x) : 0);

/** Pose at `sceneTime` for a compiled track/camera, written into `out` (clamped outside span). */
function poseAt(
  keyTimes: number[],
  points: Vec3[],
  quats: Quat[],
  warp: CompiledTrack["warp"],
  sceneTime: number,
  out: Pose,
): void {
  const n = keyTimes.length;
  if (n === 1 || !warp) {
    const p0 = points[0]!;
    const q0 = quats[0]!;
    out.p[0] = p0[0];
    out.p[1] = p0[1];
    out.p[2] = p0[2];
    out.q[0] = q0[0];
    out.q[1] = q0[1];
    out.q[2] = q0[2];
    out.q[3] = q0[3];
    return;
  }
  const u = evalWarp(warp, sceneTime);
  catmullRomAt(points, u, out.p);
  const g = u * (n - 1);
  const i = Math.min(Math.floor(g), n - 2);
  slerpQuat(quats[i]!, quats[i + 1]!, g - i, out.q);
}

/** Allocate a reusable `SceneState` shaped for `compiled` (the per-frame `out` buffer). */
export function createSceneState(compiled: CompiledScene): SceneState {
  return {
    time: 0,
    tracks: compiled.tracks.map((ct) => ({
      id: ct.id,
      pose: { p: [0, 0, 0], q: [0, 0, 0, 1] },
      visible: false,
      opacity: 0,
    })),
    camera: compiled.camera ? { pose: { p: [0, 0, 0], q: [0, 0, 0, 1] }, fov: compiled.camera.fov } : null,
  };
}

/**
 * Evaluate the scene at driver parameter `t ∈ [0..1]` (clamped). Pass a reusable
 * `out` (from `createSceneState`) to run allocation-free; omit it to get a fresh
 * state. Deterministic — equal inputs give equal output on every conformant player.
 */
export function evaluate(compiled: CompiledScene, t: number, out?: SceneState): SceneState {
  const state = out ?? createSceneState(compiled);
  const sceneTime = clamp01(t) * compiled.duration;
  state.time = sceneTime;

  for (let i = 0; i < compiled.tracks.length; i++) {
    const ct = compiled.tracks[i]!;
    const ts = state.tracks[i]!;
    poseAt(ct.keyTimes, ct.points, ct.quats, ct.warp, sceneTime, ts.pose);

    const start = ct.keyTimes[0]!;
    // A zero-width span (single key, or coincident first/last key time) is a
    // persistent constant pose (§7/§12.4): always in-span, never a measure-zero flash.
    const zeroWidth = ct.spanEnd <= start;
    const inSpan = zeroWidth || (sceneTime >= start && sceneTime <= ct.spanEnd);
    if (inSpan) {
      ts.visible = true;
      let op = 1;
      if (!zeroWidth) {
        if (ct.fadeIn > 0) op = Math.min(op, clamp01((sceneTime - start) / ct.fadeIn));
        if (ct.fadeOut > 0) op = Math.min(op, clamp01((ct.spanEnd - sceneTime) / ct.fadeOut));
      }
      ts.opacity = op;
    } else {
      ts.visible = sceneTime < start ? ct.holdBefore : ct.holdAfter;
      ts.opacity = ts.visible ? 1 : 0;
    }
  }

  if (compiled.camera && state.camera) {
    const cc = compiled.camera;
    poseAt(cc.keyTimes, cc.points, cc.quats, cc.warp, sceneTime, state.camera.pose);
    state.camera.fov = cc.fov;
    resolveLookAt(cc, state);
  }

  return state;
}

/** Override the camera orientation from `lookAt` (§8): a fixed point or another track's position. */
function resolveLookAt(cc: CompiledCamera, state: SceneState): void {
  if (cc.lookAt === undefined || !state.camera) return;
  let target: Vec3 | undefined;
  if (typeof cc.lookAt === "string") {
    const followed = state.tracks.find((ts) => ts.id === cc.lookAt);
    target = followed?.pose.p; // graceful: unresolved id → keep the slerped key `q`
  } else {
    target = cc.lookAt;
  }
  if (target) lookAtQuat(state.camera.pose.p, target, WORLD_UP, state.camera.pose.q);
}
