/**
 * The `drivers` layer: input modality → the single progress parameter t ∈ [0..1]
 * (spec §6 driver boundary). C4 ships the flagship scroll driver; D1 adds the time /
 * autoplay driver and the registry that names them; D2 the view driver; D3 the pointer /
 * scrub driver; E1b the external driver, whose "input" is the host itself — every one
 * behind the same `Driver` interface.
 *
 * The two shared loops (`TimelineClock`, `ChaseLoop`) are deliberately NOT exported: they
 * are the seam drivers are built from, not a public extension point.
 */
export type { Driver } from "./types.js";
export { ScrollDriver } from "./scroll.js";
export type { ScrollDriverOptions, ScrollDriverDebug, ScrollDriverEnv } from "./scroll.js";
export { TimeDriver } from "./time.js";
export type { TimeDriverOptions, TimeDriverDebug, TimeDriverEnv } from "./time.js";
export { ViewDriver, thresholdReachable } from "./view.js";
export type { ViewDriverOptions, ViewDriverDebug, ViewDriverEnv } from "./view.js";
export { PointerDriver, pointerProgress } from "./pointer.js";
export type {
  PointerDriverOptions,
  PointerDriverDebug,
  PointerDriverEnv,
  PointerAxis,
  PointerBox,
} from "./pointer.js";
export { ExternalDriver } from "./external.js";
export type { ExternalDriverOptions, ExternalDriverDebug } from "./external.js";
export { DRIVER_KINDS, isDriverKind, resolveDriverKind, createDriver } from "./registry.js";
export type { DriverKind, DriverSpec } from "./registry.js";
export {
  scrollProgress,
  dampFactor,
  regionMetrics,
  regionRange,
  SETTLE_EPSILON,
} from "./progress.js";
export type { RegionMetrics, RegionRange } from "./progress.js";
