/**
 * The scroll driver (C4): the flagship input — the scrollbar is the timeline.
 *
 * Hard rules (the jank contract, from the plan's gapfill 3.3–3.4):
 *  - scroll/resize listeners are PASSIVE and do ZERO work — the handler only sets a
 *    flag and schedules a rAF (`wake()`). Scroll is async on the compositor thread;
 *    any work in the handler lags the page.
 *  - ALL reads (scroll position, layout measurement) and all math happen inside rAF.
 *  - Layout is measured only on invalidation (first frame, resize, `invalidate()`) —
 *    never per frame.
 *  - On-demand rendering: subscribers are called only when t changes, and the rAF
 *    loop runs only while the damped value is settling. A settled driver schedules
 *    no frames and costs nothing.
 * All four are enforced by `ChaseLoop` (`chase.ts`), extracted at D3 so the pointer
 * driver obeys them by construction instead of by copy. What stays here is the part
 * that is actually about scrolling: the listeners, the cached region measurement, and
 * the scroll→t mapping — handed to the loop as its `sample()`.
 *
 * Progress mapping (the sticky-canvas scrollytelling pattern): the `target` element
 * is a tall scroll region; t goes 0→1 as the page scrolls from the region's top
 * (aligned with the viewport top) to the point where its bottom meets the viewport
 * bottom — i.e. across `regionHeight − viewportHeight` px of scrolling.
 *
 * Lenis compatibility: pass `getScroll: () => lenis.scroll` to read a smoothed
 * virtual scroll position instead of `window.scrollY` (and set `damping: 0` if the
 * source already smooths). Duck-typed on purpose — Lenis is NOT a dependency
 * (runtime dep fence: three.js only). NB `getScroll` replaces the scroll *read*; the
 * region is still measured against the real document, which is correct for
 * native-scroll-based libraries (Lenis) but not for transform-based ones.
 */

import type { Driver } from "./types.js";
import { ChaseLoop } from "./chase.js";
import { regionMetrics, regionRange, scrollProgress, type RegionMetrics } from "./progress.js";

export type { RegionMetrics };

/**
 * The driver's window/time seam, injectable so the loop is deterministic in node
 * tests (real DOM defaults are used in the browser). Not a public extension point.
 */
export interface ScrollDriverEnv {
  raf(cb: (now: number) => void): number;
  caf(handle: number): void;
  scrollY(): number;
  measure(target: Element): RegionMetrics;
  /** Registered passively — the options object is part of the contract, not a detail. */
  addListener(type: "scroll" | "resize", fn: () => void, options: { passive: true }): void;
  removeListener(type: "scroll" | "resize", fn: () => void): void;
  /**
   * Watch for layout shifts that move or resize the region WITHOUT a window resize —
   * a lazy image or late web font above it, an accordion, a cookie bar. Without this
   * the cached metrics silently go stale and t stops matching the real scroll
   * position. Returns a teardown function.
   */
  observeLayout(target: Element, onChange: () => void): () => void;
  prefersReducedMotion(): boolean;
}

export interface ScrollDriverOptions {
  /**
   * Damping rate λ (1/s) for the exponential chase of the scroll target — the rAF
   * interpolation that smooths native scroll steps. 0 = no damping (t tracks the
   * scroll exactly). Default 8 (≈ 120 ms to cover 63 % of a jump).
   */
  damping?: number;
  /** Shift the region start down by this many px (driver-side range mapping, §11). */
  offsetStart?: number;
  /** Pull the region end up by this many px. */
  offsetEnd?: number;
  /** External scroll source (e.g. `() => lenis.scroll`). Default: `window.scrollY`. */
  getScroll?: () => number;
  /**
   * When the user prefers reduced motion, disable damping so t never lags the real
   * scroll position (no synthetic ease-out motion). Default true. Sampled once at
   * construction; the full reduced-motion poster fallback — and reacting to the
   * setting changing mid-session — is the element's job (C6).
   */
  respectReducedMotion?: boolean;
  /** Test seam — override pieces of the window/time environment. */
  env?: Partial<ScrollDriverEnv>;
}

/** Plain snapshot for the `window.__vertie` no-screenshot verification channel. */
export interface ScrollDriverDebug {
  t: number;
  targetT: number;
  /** True once the first frame has run AND the damped value has caught up. */
  settled: boolean;
  /** False until the first frame has run — `settled` alone is not a readiness signal. */
  primed: boolean;
  frames: number;
  measures: number;
  destroyed: boolean;
}

function defaultEnv(): ScrollDriverEnv {
  return {
    raf: (cb) => requestAnimationFrame(cb),
    caf: (handle) => cancelAnimationFrame(handle),
    scrollY: () => window.scrollY,
    measure: (target) => regionMetrics(target.getBoundingClientRect(), window.scrollY, window.innerHeight),
    addListener: (type, fn, options) => window.addEventListener(type, fn, options),
    removeListener: (type, fn) => window.removeEventListener(type, fn),
    observeLayout: (target, onChange) => {
      if (typeof ResizeObserver !== "function") return () => {};
      // The target catches its own growth; the document element catches content
      // above it changing height (which moves the region without resizing it).
      const observer = new ResizeObserver(onChange);
      observer.observe(target);
      if (typeof document !== "undefined") observer.observe(document.documentElement);
      return () => observer.disconnect();
    },
    prefersReducedMotion: () =>
      typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches,
  };
}

export class ScrollDriver implements Driver {
  private readonly target: Element;
  private readonly env: ScrollDriverEnv;
  private readonly damping: number;
  private readonly offsetStart: number;
  private readonly offsetEnd: number;
  private readonly getScroll: (() => number) | undefined;
  private readonly unobserveLayout: () => void;
  private readonly loop: ChaseLoop;

  private regionStart = 0;
  private regionSize = 0;
  private metricsDirty = true;
  private measures = 0;
  private destroyedFlag = false;

  // Stable bound handlers so removeListener() can match them.
  private readonly onScroll = (): void => this.loop.wake();
  private readonly onLayoutChange = (): void => this.invalidate();

  constructor(target: Element, options: ScrollDriverOptions = {}) {
    this.target = target;
    this.env = { ...defaultEnv(), ...options.env };
    const reduced = (options.respectReducedMotion ?? true) && this.env.prefersReducedMotion();
    this.damping = reduced ? 0 : (options.damping ?? 8);
    this.offsetStart = options.offsetStart ?? 0;
    this.offsetEnd = options.offsetEnd ?? 0;
    this.getScroll = options.getScroll;
    this.loop = new ChaseLoop({
      damping: this.damping,
      sample: () => this.sample(),
      ...(options.env ? { env: options.env } : {}),
    });

    this.env.addListener("scroll", this.onScroll, { passive: true });
    this.env.addListener("resize", this.onLayoutChange, { passive: true });
    this.unobserveLayout = this.env.observeLayout(target, this.onLayoutChange);
    this.loop.wake(); // initial frame: measure, map, emit the starting t
  }

  get t(): number {
    return this.loop.t;
  }

  get debug(): ScrollDriverDebug {
    return {
      t: this.loop.t,
      targetT: this.loop.target,
      settled: this.loop.settled,
      primed: this.loop.primed,
      frames: this.loop.frames,
      measures: this.measures,
      destroyed: this.destroyedFlag,
    };
  }

  /**
   * The loop's per-frame read: re-measure the region if it was invalidated, then map the
   * current scroll position onto t. Everything in here is deliberately inside the rAF.
   */
  private sample(): number {
    if (this.metricsDirty) {
      const range = regionRange(this.env.measure(this.target), this.offsetStart, this.offsetEnd);
      this.regionStart = range.start;
      this.regionSize = range.size;
      this.metricsDirty = false;
      this.measures++;
    }
    const scroll = this.getScroll ? this.getScroll() : this.env.scrollY();
    return scrollProgress(scroll, this.regionStart, this.regionSize);
  }

  /**
   * Register a sink for t changes. If the driver has already run a frame (and may
   * well have settled, so no further frame is scheduled), a frame is forced so the
   * new subscriber receives the current value — otherwise a consumer that subscribes
   * after an `await` would never get an initial value and would render nothing until
   * the user scrolls.
   */
  subscribe(fn: (t: number) => void): () => void {
    return this.loop.subscribe(fn);
  }

  /**
   * Force the region to be re-measured on the next frame. Call it after changing
   * layout the driver cannot observe (and the `observeLayout` seam does not catch).
   */
  invalidate(): void {
    this.metricsDirty = true;
    this.loop.wake();
  }

  destroy(): void {
    if (this.destroyedFlag) return;
    this.destroyedFlag = true;
    this.env.removeListener("scroll", this.onScroll);
    this.env.removeListener("resize", this.onLayoutChange);
    this.unobserveLayout();
    this.loop.destroy();
  }
}
