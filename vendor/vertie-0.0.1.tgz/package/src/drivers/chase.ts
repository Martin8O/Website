/**
 * The damped chase loop (extracted at D3): the machinery every driver whose input the
 * USER moves needs — an on-demand rAF loop, exponential damping that is frame-rate
 * independent, a capped frame delta, emit-on-change, the owed initial value, and the
 * settle rule that stops the loop when there is nothing left to do.
 *
 * C4 wrote all of it inside `ScrollDriver`; the pointer driver needs the identical
 * behaviour with a different sample, and a second hand-written copy of these rules is
 * exactly how two drivers drift apart (the same reason D2 extracted `TimelineClock` for
 * the drivers that move on a clock). The two loops stay separate on purpose: a clock
 * advances by itself and needs gates, a chase only ever reacts to input and needs none.
 *
 * The one thing a caller supplies is `sample()`, called INSIDE the frame — that is where
 * the jank contract lives: event handlers do nothing but `wake()`, and every read
 * (scroll position, layout measurement, pointer mapping) happens in the rAF that follows.
 *
 * Layer note: no DOM beyond the injected `raf`/`caf`.
 */

import { SETTLE_EPSILON, dampFactor } from "./progress.js";

/** dt cap — a long rAF stall (background tab, GC) damps like one slow frame, no snap. */
export const MAX_DT_MS = 100;

/**
 * The frame-scheduling seam, injectable so the loop is deterministic in node tests. Not a
 * public extension point. There is no clock of its own: rAF hands the frame timestamp in.
 */
export interface ChaseLoopEnv {
  raf(cb: (now: number) => void): number;
  caf(handle: number): void;
}

export interface ChaseLoopOptions {
  /**
   * Damping rate λ (1/s) for the exponential chase. 0 (or less) = no damping: the value
   * tracks the sample exactly, one frame per change.
   */
  damping?: number;
  /**
   * Read the current target, called once per frame from inside the rAF. Must be cheap
   * and must never throw — it is the only place a driver is allowed to touch layout.
   */
  sample: () => number;
  /** Test seam — override the frame scheduler. */
  env?: Partial<ChaseLoopEnv>;
}

export type ChaseSubscriber = (t: number) => void;

function defaultEnv(): ChaseLoopEnv {
  return {
    raf: (cb) => requestAnimationFrame(cb),
    caf: (handle) => cancelAnimationFrame(handle),
  };
}

export class ChaseLoop {
  private readonly env: ChaseLoopEnv;
  private readonly damping: number;
  private readonly sample: () => number;

  private readonly subscribers = new Set<ChaseSubscriber>();
  /** Subscribers that joined after the first frame and still owe an initial value. */
  private readonly pendingInitial = new Set<ChaseSubscriber>();

  private current = 0;
  private targetValue = 0;
  private emitted = NaN; // NaN ≠ anything → the next frame always emits
  private primedFlag = false; // the very first frame snaps to the sample (no ease-in at load)
  private snapOnce = false; // a caller asked for the next frame to land, not to ease
  private lastNow = NaN; // NaN = loop freshly woken → this frame only establishes the baseline
  private framePending = false; // separate from the handle: 0 is a legal handle value
  private rafHandle = 0;
  private frameCount = 0;
  private destroyedFlag = false;

  constructor(options: ChaseLoopOptions) {
    this.env = { ...defaultEnv(), ...options.env };
    this.damping = options.damping ?? 0;
    this.sample = options.sample;
  }

  /** Current (damped) value. */
  get t(): number {
    return this.current;
  }

  /** What the last frame sampled — where `t` is heading. */
  get target(): number {
    return this.targetValue;
  }

  /** True once the first frame has run AND the damped value has caught up. */
  get settled(): boolean {
    return this.primedFlag && this.current === this.targetValue;
  }

  /** False until the first frame has run — `settled` alone is not a readiness signal. */
  get primed(): boolean {
    return this.primedFlag;
  }

  get frames(): number {
    return this.frameCount;
  }

  get destroyed(): boolean {
    return this.destroyedFlag;
  }

  /**
   * Register a sink for value changes. If the loop has already run a frame (and may well
   * have settled, so no further frame is scheduled), a frame is forced so the new
   * subscriber receives the current value — otherwise a consumer that subscribes after an
   * `await` would never get an initial value and would render nothing until the next input.
   */
  subscribe(fn: ChaseSubscriber): () => void {
    this.subscribers.add(fn);
    if (this.primedFlag && !this.destroyedFlag) {
      // Owe THIS subscriber a value — deliberately not a blanket "re-emit to everyone",
      // which a subscriber that subscribes from its own callback would turn into an
      // endless wake loop.
      this.pendingInitial.add(fn);
      this.wake();
    }
    return () => {
      this.subscribers.delete(fn);
      this.pendingInitial.delete(fn);
    };
  }

  /**
   * Land on the next frame's sample instead of easing toward it. For a jump the user
   * *asked* for — a scrub control being dragged, a seek — where damping is not smoothing
   * but lag: the control would be showing one position while the scene showed another.
   */
  snapNextFrame(): void {
    this.snapOnce = true;
  }

  /** Schedule a frame if none is pending. The ONLY thing an event handler may do. */
  wake(): void {
    if (this.destroyedFlag || this.framePending) return;
    this.framePending = true;
    this.rafHandle = this.env.raf(this.frame);
  }

  private readonly frame = (now: number): void => {
    // Cleared FIRST: an event arriving during this body must be able to schedule the
    // next frame rather than be swallowed.
    this.framePending = false;
    if (this.destroyedFlag) return;
    this.frameCount++;

    this.targetValue = this.sample();

    if (!this.primedFlag || this.damping <= 0 || this.snapOnce) {
      this.current = this.targetValue; // first frame ever / undamped / asked: land, no ease
      this.primedFlag = true;
      this.snapOnce = false;
    } else if (!Number.isNaN(this.lastNow)) {
      // Cap dt so a long rAF stall damps like one slow frame instead of snapping.
      const dt = Math.min(now - this.lastNow, MAX_DT_MS);
      this.current += (this.targetValue - this.current) * dampFactor(this.damping, dt);
      if (Math.abs(this.targetValue - this.current) < SETTLE_EPSILON) this.current = this.targetValue;
    }
    // else: first frame of a freshly woken loop — it only establishes the dt baseline.
    // Guessing a nominal dt here would make the start of every gesture frame-rate
    // dependent (a 240 Hz display would travel further than a 60 Hz one).
    this.lastNow = now;

    // Drain BEFORE emitting: anyone who subscribes during the emit below stays owed and
    // is paid on the next frame, instead of being missed by the snapshot taken here.
    const owed = [...this.pendingInitial];
    this.pendingInitial.clear();

    if (this.current !== this.emitted) {
      this.emitted = this.current;
      // Snapshot: a subscriber may subscribe/unsubscribe from within its own callback.
      // This broadcast already pays everyone currently owed a value.
      for (const fn of [...this.subscribers]) fn(this.current);
    } else {
      for (const fn of owed) if (this.subscribers.has(fn)) fn(this.current);
    }

    if (this.current !== this.targetValue) {
      this.wake(); // still settling — and wake() re-checks destroyed/pending
    } else {
      this.lastNow = NaN; // loop stops; the next wake() starts a fresh dt baseline
    }
  };

  destroy(): void {
    if (this.destroyedFlag) return;
    this.destroyedFlag = true;
    if (this.framePending) {
      this.env.caf(this.rafHandle);
      this.framePending = false;
    }
    this.subscribers.clear();
    this.pendingInitial.clear();
  }
}
