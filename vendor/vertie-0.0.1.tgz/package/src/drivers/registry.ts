/**
 * The driver registry (D1): the one place that knows which input modalities exist and
 * how to build one. `<vertie-scene driver="…">` names a kind, this file turns it into a
 * `Driver` — so D2/D3 (view, pointer) are an entry here plus their implementation file,
 * never element surgery.
 *
 * Additive discipline (ADR-012): an unknown kind is a NEWER document meeting an OLDER
 * player, so it warns and falls back to the flagship scroll driver rather than refusing
 * to play. That rule lives here, next to the list it is about.
 */

import type { Driver } from "./types.js";
import { ScrollDriver, type ScrollDriverOptions } from "./scroll.js";
import { TimeDriver, type TimeDriverOptions } from "./time.js";
import { ViewDriver, type ViewDriverOptions } from "./view.js";
import { PointerDriver, type PointerDriverOptions } from "./pointer.js";
import { ExternalDriver, type ExternalDriverOptions } from "./external.js";

/** Every input modality the player can build. Grows; never shrinks. */
export const DRIVER_KINDS = ["scroll", "time", "view", "pointer", "external"] as const;

export type DriverKind = (typeof DRIVER_KINDS)[number];

/**
 * A kind together with its own options — the pairing is what keeps `createDriver`
 * honest: options are per-driver and do not share a shape (a time driver has no
 * `offsetStart`, a scroll driver has no `loop`).
 */
export type DriverSpec =
  | { kind: "scroll"; options: ScrollDriverOptions }
  | { kind: "time"; options: TimeDriverOptions }
  | { kind: "view"; options: ViewDriverOptions }
  | { kind: "pointer"; options: PointerDriverOptions }
  | { kind: "external"; options: ExternalDriverOptions };

export function isDriverKind(name: string): name is DriverKind {
  return (DRIVER_KINDS as readonly string[]).includes(name);
}

/**
 * Map an attribute value onto a kind. `null`/absent = the flagship scroll driver; an
 * unrecognized name warns and degrades to it (see the additive rule above).
 */
export function resolveDriverKind(name: string | null): DriverKind {
  if (name === null || name === "") return "scroll";
  if (isDriverKind(name)) return name;
  console.warn(
    `vertie: unknown driver "${name}" — falling back to "scroll" (known: ${DRIVER_KINDS.join(", ")})`,
  );
  return "scroll";
}

/**
 * Build the driver a spec asks for. `target` is the region: the scroll driver measures
 * it, the view driver watches it, the pointer driver listens on it, and a driver that
 * reads none of that (time, external) ignores it.
 */
export function createDriver(spec: DriverSpec, target: Element): Driver {
  switch (spec.kind) {
    case "time":
      return new TimeDriver(spec.options);
    case "external":
      return new ExternalDriver(spec.options);
    case "view":
      return new ViewDriver(target, spec.options);
    case "pointer":
      return new PointerDriver(target, spec.options);
    case "scroll":
      return new ScrollDriver(target, spec.options);
  }
}
