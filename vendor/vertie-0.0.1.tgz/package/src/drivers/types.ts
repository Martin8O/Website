/**
 * The `drivers` layer: each driver maps one input modality (scroll, time, view,
 * pointer, external — ADR-012) onto the single normalized progress parameter t ∈ [0..1] that
 * feeds the evaluator (`sceneTime = t · duration`, spec §6). Drivers own the rAF
 * loop and the on-demand invalidation; the render layer only ever sees discrete
 * `apply()`/`render()` calls when t actually changed.
 *
 * Layer boundary: drivers may touch the DOM (they read input) but never three.js —
 * rendering stays behind the `SceneState` seam (ESLint-enforced, like core/format).
 */

/**
 * The one driver contract (C4; D1–D3 and E1b add time/view/pointer/external
 * implementations additively behind the same interface).
 */
export interface Driver {
  /** Current (damped) progress t ∈ [0..1]. */
  readonly t: number;
  /**
   * Register a sink called from the driver's rAF whenever t changes (invalidate-on-
   * change: no call means nothing to re-render). Returns an unsubscribe function.
   * A driver that owns a frame loop does NOT call the subscriber synchronously on
   * registration — the first call comes from its next frame. `ExternalDriver` (E1b) is
   * the exception the rule needs: it has no loop of its own to owe that value to, so it
   * delivers the current t inside `subscribe()` itself. A subscriber must therefore
   * tolerate both, i.e. be usable the moment it is registered.
   *
   * `discontinuity` (D1, additive — a driver that never jumps simply omits it) means
   * "this t does not continue the previous one": a loop wrap, a seek, a restart. It
   * exists because §10 event windows are tested against the INTERVAL between frames,
   * so a wrap from 1 back to 0 would otherwise replay the whole timeline backwards.
   */
  subscribe(fn: (t: number, discontinuity?: boolean) => void): () => void;
  /** Detach all listeners and cancel any scheduled frame. Idempotent. */
  destroy(): void;
}
