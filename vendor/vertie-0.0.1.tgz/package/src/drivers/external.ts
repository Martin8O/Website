/**
 * The external driver (E1b): the HOST owns t. `<vertie-scene driver="external">` reads
 * no input of its own — the page hands it a value (`element.t = 0.42`) and that value is
 * the timeline. It exists because a real site's progress is often not a region scroll:
 * the Website's climb derives t from a chapter-warped global Lenis position inside its
 * own r3f frame loop, and the 2D layer it flies over paints from the same number. A
 * player that insisted on measuring its own region could only disagree with it.
 *
 * **It has no loop.** No rAF, no damping, no settle rule — the host's frame IS the frame,
 * so a push renders inside the caller's own call stack and the scene lands in the same
 * paint as everything else the host drew from that t. That is the whole point: one frame
 * of lag against a compositing 2D layer is a visible desync, and a second smoothing pass
 * over a value the host already smoothed would be lag dressed up as polish (which is why
 * there is no `damping` option here — see `ScrollDriver`/`PointerDriver` for the drivers
 * that own their input and therefore own the smoothing).
 *
 * The contract the host owes back is exactly one line: **push from a frame** (rAF, r3f's
 * `useFrame`, a scroll library's own tick), never from a `scroll`/`pointermove` handler —
 * the jank rule (ADR-026) still holds, it is just enforced on the other side of the seam.
 *
 * What it deliberately does NOT do: it never advances by itself, so it is not `pausable`
 * (SC 2.2.2 binds whatever moves the host's t, and the player cannot pause that — see
 * `docs/a11y.md`); and it is not `scrubbable` — a range control in the shadow root would
 * be a second author of t, fighting the host for one number every frame (D3's lesson).
 *
 * Layer note: no DOM at all. This is the only driver that touches neither.
 */

import type { Driver } from "./types.js";

/**
 * How many coalesced re-entrant pushes one outer call drains before giving up. A host
 * that pushes t from inside a `vertie-event` listener re-enters this driver, and an
 * unbounded drain would be a livelock (a spin is never the answer — ADR-037). Generous
 * enough that no sane sequence reaches it.
 */
const MAX_DRAIN = 64;

export interface ExternalDriverOptions {
  /**
   * Where the timeline stands before the host's first push. The element feeds it the last
   * value the host pushed while the scene was still loading, so a page that teleported to
   * the middle of its chapter opens THERE rather than snapping back to the start for one
   * frame. Clamped like any other value; default 0.
   */
  initialT?: number;
}

/** Plain snapshot for the `window.__vertie` no-screenshot verification channel. */
export interface ExternalDriverDebug {
  t: number;
  /** Values the host pushed, including ones that changed nothing. */
  pushes: number;
  /** Pushes that actually reached the subscribers (emit-on-change). */
  emitted: number;
  /** Pushes refused for not being a finite number. */
  ignored: number;
  /** Pushes the host flagged as a jump — each re-seeds the §10 event tracker. */
  jumps: number;
  /** Pushes coalesced away because they arrived from inside an emit. */
  reentrant: number;
  destroyed: boolean;
}

type ExternalSubscriber = (t: number, discontinuity?: boolean) => void;

function clampT(t: number): number {
  return t < 0 ? 0 : t > 1 ? 1 : t;
}

export class ExternalDriver implements Driver {
  private readonly subscribers = new Set<ExternalSubscriber>();

  private current: number;
  /** NaN ≠ anything → the first push always emits. */
  private emittedValue = NaN;
  /** Set while subscribers are running: a push from inside one is queued, not recursed. */
  private emitting = false;
  /** The coalesced re-entrant push, last-write-wins (where the host is now is the truth). */
  private pending: { t: number; discontinuity: boolean } | null = null;

  private pushCount = 0;
  private emitCount = 0;
  private ignoredCount = 0;
  private jumpCount = 0;
  private reentrantCount = 0;
  private warnedNonFinite = false;
  private warnedDrain = false;
  private destroyedFlag = false;

  constructor(options: ExternalDriverOptions = {}) {
    const initial = options.initialT;
    this.current = initial !== undefined && Number.isFinite(initial) ? clampT(initial) : 0;
  }

  /** Current progress t ∈ [0..1] — the last value the host pushed. */
  get t(): number {
    return this.current;
  }

  get destroyed(): boolean {
    return this.destroyedFlag;
  }

  get debug(): ExternalDriverDebug {
    return {
      t: this.current,
      pushes: this.pushCount,
      emitted: this.emitCount,
      ignored: this.ignoredCount,
      jumps: this.jumpCount,
      reentrant: this.reentrantCount,
      destroyed: this.destroyedFlag,
    };
  }

  /**
   * Register a sink — and pay it its initial value **synchronously**, right here. Every
   * other driver owes that value to its own next frame; this one has no frame to owe it
   * to, and a host that pushed once before the scene was ready (or that pushes only when
   * its own value changes) would otherwise leave the canvas blank until it happened to
   * move again. See the `Driver` contract note in `types.ts`.
   */
  subscribe(fn: ExternalSubscriber): () => void {
    this.subscribers.add(fn);
    if (!this.destroyedFlag) {
      this.emittedValue = this.current;
      this.emitCount++;
      const nested = this.guard(() => fn(this.current));
      if (!nested) this.drain();
    }
    return () => {
      this.subscribers.delete(fn);
    };
  }

  /**
   * Take a value from the host. Out-of-range is clamped (a host whose own timeline
   * overshoots — the climb's `runLocalTRaw` is unclamped by design — should not have to
   * clamp twice), an identical value renders nothing, and a value that is not a finite
   * number is refused rather than passed on: a NaN t would poison every pose downstream
   * and no comparison would ever settle it again.
   *
   * `discontinuity` says "this t does not continue the last one" — a chapter teleport, a
   * nav jump — so the §10 tracker is re-seeded instead of being handed an interval it
   * would faithfully replay window by window (ADR-034). A jump always emits, even to the
   * value that is already showing: the tracker still has to be told.
   */
  setT(t: number, discontinuity = false): void {
    if (this.destroyedFlag) return;
    this.pushCount++;
    if (!Number.isFinite(t)) {
      this.ignoredCount++;
      if (!this.warnedNonFinite) {
        this.warnedNonFinite = true;
        console.warn(`vertie: driver="external" ignored a non-finite t (${String(t)})`);
      }
      return;
    }
    if (discontinuity) this.jumpCount++;
    const next = clampT(t);

    if (this.emitting) {
      // Re-entrant: a subscriber (a §10 event listener, most likely) pushed while we were
      // still emitting. Coalesce rather than recurse — and keep the jump flag sticky, a
      // dropped one would leave the tracker replaying a timeline the host has left.
      this.reentrantCount++;
      this.pending = { t: next, discontinuity: discontinuity || (this.pending?.discontinuity ?? false) };
      return;
    }

    this.emit(next, discontinuity);
    this.drain();
  }

  destroy(): void {
    if (this.destroyedFlag) return;
    this.destroyedFlag = true;
    this.subscribers.clear();
    this.pending = null;
  }

  /** Emit-on-change: an unchanged t costs the host nothing (no apply, no render). */
  private emit(next: number, discontinuity: boolean): void {
    this.current = next;
    if (next === this.emittedValue && !discontinuity) return;
    this.emittedValue = next;
    this.emitCount++;
    // Snapshot: a subscriber may subscribe/unsubscribe from within its own callback.
    this.guard(() => {
      for (const fn of [...this.subscribers]) fn(next, discontinuity || undefined);
    });
  }

  /**
   * Run a callback with the re-entrancy flag raised, restoring whatever it was (a
   * subscriber may subscribe from inside an emit, and the inner call must not report the
   * outer one as finished). Returns true if it was already raised, i.e. we were nested.
   */
  private guard(run: () => void): boolean {
    const nested = this.emitting;
    this.emitting = true;
    try {
      run();
    } finally {
      this.emitting = nested;
    }
    return nested;
  }

  /** Deliver whatever arrived while subscribers were running. */
  private drain(): void {
    let drained = 0;
    while (this.pending !== null && !this.destroyedFlag) {
      if (++drained > MAX_DRAIN) {
        this.pending = null;
        if (!this.warnedDrain) {
          this.warnedDrain = true;
          console.warn(
            `vertie: driver="external" dropped a push — more than ${MAX_DRAIN} re-entrant updates in one call ` +
              `(a listener is pushing t from inside a vertie-event handler)`,
          );
        }
        return;
      }
      const next = this.pending;
      this.pending = null;
      this.emit(next.t, next.discontinuity);
    }
  }
}
