/**
 * Pure scroll-driver math (no DOM): the region measurement, the scroll→t mapping and
 * the frame-rate independent damping factor. Kept separate from the DOM wiring so the
 * logic is unit-testable in node, the same discipline as the core evaluator.
 */

/**
 * Below this |target − current| distance the damped value snaps to the target and
 * the rAF loop stops (on-demand rendering: a settled driver schedules no frames).
 * In t-units: 1e-4 of a scene is far below one output pixel of camera motion.
 */
export const SETTLE_EPSILON = 1e-4;

/** Region geometry in document coordinates, remeasured only on invalidation. */
export interface RegionMetrics {
  /** Document-space top of the scroll region (px). */
  top: number;
  /** Region height (px). */
  height: number;
  /** Viewport height (px) — subtracted to get the scrollable travel. */
  viewportHeight: number;
}

/** The scrollable range a region maps onto, after the author's offsets. */
export interface RegionRange {
  /** Scroll position at which t = 0. */
  start: number;
  /** Scroll distance covering t = 0→1. Non-positive = no travel. */
  size: number;
}

/**
 * Convert a viewport-relative rect into document-space region metrics. Split out of
 * the DOM env so the `rect.top + scrollY` step (the easiest thing in this file to get
 * wrong) is covered by a unit test rather than only by the browser.
 */
export function regionMetrics(
  rect: { top: number; height: number },
  scrollY: number,
  viewportHeight: number,
): RegionMetrics {
  return { top: rect.top + scrollY, height: rect.height, viewportHeight };
}

/**
 * The sticky-canvas travel: t runs from the region's top reaching the viewport top to
 * its bottom reaching the viewport bottom, i.e. across `height − viewportHeight` px.
 * `offsetStart`/`offsetEnd` each move exactly one end inward (driver-side range
 * mapping, §11); the travel shrinks by both.
 *
 * NB the mapping assumes the sticky child is pinned at `top: 0`; a canvas pinned under
 * a fixed header compensates with `offsetStart`.
 */
export function regionRange(metrics: RegionMetrics, offsetStart = 0, offsetEnd = 0): RegionRange {
  return {
    start: metrics.top + offsetStart,
    size: metrics.height - metrics.viewportHeight - offsetStart - offsetEnd,
  };
}

/**
 * Map an absolute scroll position onto normalized progress over a region:
 * t = (scroll − range.start) / range.size, clamped to [0..1].
 *
 * Two defensive cases, both of which must NOT produce NaN — a NaN t would never equal
 * itself, so the driver's settle check would spin the rAF loop forever:
 *  - a degenerate region (size ≤ 0: the section is shorter than the viewport, or the
 *    offsets ate the travel) has no travel at all → t = 0, i.e. the scene rests at its
 *    start pose. Pinning a mis-authored region at its END would read as a broken player.
 *  - a non-finite input (an uninitialized smooth-scroll source returning `undefined`,
 *    a `display: none` region measuring NaN) → t = 0.
 */
export function scrollProgress(scroll: number, regionStart: number, regionSize: number): number {
  if (!Number.isFinite(scroll) || !Number.isFinite(regionStart) || !Number.isFinite(regionSize)) {
    return 0;
  }
  if (regionSize <= 0) return 0;
  const t = (scroll - regionStart) / regionSize;
  return t < 0 ? 0 : t > 1 ? 1 : t;
}

/**
 * Exponential-smoothing step factor for one frame: current += (target − current) · k.
 * k = 1 − e^(−λ·dt) is frame-rate independent — two 8 ms steps land exactly where
 * one 16 ms step does — so damping feels identical at 30, 60, or 120 Hz.
 * λ ≤ 0 disables damping (k = 1, instant).
 *
 * @param lambda damping rate in 1/seconds (higher = snappier)
 * @param dtMs   frame delta in milliseconds
 */
export function dampFactor(lambda: number, dtMs: number): number {
  if (lambda <= 0) return 1;
  return 1 - Math.exp((-lambda * dtMs) / 1000);
}
