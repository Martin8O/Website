/**
 * The time driver (D1): the wall clock is the timeline — t runs 0→1 over `durationMs`
 * of real time, optionally looping. The first Vertie driver that advances **on its own**,
 * which makes it the first one bound by WCAG 2.2 SC 2.2.2 (Pause, Stop, Hide): the
 * element ships the pause control, and this class exposes the two gates it needs
 * (`docs/a11y.md` §3 — that obligation was recorded at C6 and is discharged here).
 *
 * Two independent gates, deliberately not folded into one flag:
 *  - `paused` is **intent** — the user pressing pause, or an author's `paused` attribute.
 *  - `suspend()` is the **environment** — the element switches it while the scene is off
 *    screen or the page is hidden. Playback resumes exactly where it stopped, and an
 *    invisible scene costs no frames (the battery half of the C6 pause rules).
 * Advancing ⟺ neither gate is set (and the timeline has not ended).
 *
 * The clock itself lives in `timeline.ts` (extracted at D2, when the view driver needed
 * the same machinery with a third gate): dt capping, looping, emit-on-change, the owed
 * initial value, the discontinuity flag and the on-demand loop that schedules NO frame
 * while it is not advancing — a paused, suspended or ended driver costs nothing.
 */

import type { Driver } from "./types.js";
import { TimelineClock, type TimelineClockEnv } from "./timeline.js";

/** The gate the user (or the author's `paused` attribute) owns. */
const INTENT = "intent";
/** The gate the element owns: off screen, or a hidden page. */
const ENVIRONMENT = "environment";

/**
 * The driver's frame-scheduling seam, injectable so the loop is deterministic in node
 * tests. Not a public extension point. There is no clock of its own: rAF hands the
 * frame timestamp in, which is the only time base a frame loop may trust.
 */
export type TimeDriverEnv = TimelineClockEnv;

export interface TimeDriverOptions {
  /** Wall-clock length of one pass, in milliseconds. Non-finite or ≤ 0 → 5000. */
  durationMs?: number;
  /** Restart from 0 on reaching the end instead of stopping. Default false. */
  loop?: boolean;
  /** Start stopped (the element's `paused` attribute). Default false — autoplay. */
  paused?: boolean;
  /** Test seam — override the frame scheduler. */
  env?: Partial<TimeDriverEnv>;
}

/** Plain snapshot for the `window.__vertie` no-screenshot verification channel. */
export interface TimeDriverDebug {
  t: number;
  /** Playback intent: what the pause control shows. */
  paused: boolean;
  /** Environment gate: off screen or a hidden page. */
  suspended: boolean;
  /** True while frames are actually being scheduled. */
  advancing: boolean;
  /** A non-looping timeline that reached t = 1 (a `play()` restarts it). */
  ended: boolean;
  /** Completed passes (looping only) — the wrap count. */
  loops: number;
  elapsedMs: number;
  durationMs: number;
  /** False until the first frame has run. */
  primed: boolean;
  frames: number;
  destroyed: boolean;
}

export class TimeDriver implements Driver {
  /**
   * This driver moves without the user, so the element must offer a way to stop it
   * (SC 2.2.2). A capability flag rather than an `instanceof` check: every later
   * self-advancing driver sets it and inherits the control for free.
   */
  readonly pausable = true;

  private readonly clock: TimelineClock;

  constructor(options: TimeDriverOptions = {}) {
    this.clock = new TimelineClock({
      ...(options.durationMs !== undefined ? { durationMs: options.durationMs } : {}),
      ...(options.loop !== undefined ? { loop: options.loop } : {}),
      ...(options.env !== undefined ? { env: options.env } : {}),
    });
    // Set AFTER construction on purpose: the clock has already scheduled its first frame,
    // so a driver that starts paused still draws its starting t and only then goes quiet.
    if (options.paused ?? false) this.clock.gate(INTENT, true);
  }

  get t(): number {
    return this.clock.t;
  }

  /** Playback intent (the pause control), independent of `suspend()`. */
  get paused(): boolean {
    return this.clock.blocked(INTENT);
  }

  /** A non-looping timeline that has run out. `play()` starts it over. */
  get ended(): boolean {
    return this.clock.ended;
  }

  get debug(): TimeDriverDebug {
    return {
      t: this.clock.t,
      paused: this.paused,
      suspended: this.clock.blocked(ENVIRONMENT),
      advancing: this.clock.advancing,
      ended: this.clock.ended,
      loops: this.clock.loops,
      elapsedMs: this.clock.elapsedMs,
      durationMs: this.clock.durationMs,
      primed: this.clock.primed,
      frames: this.clock.frames,
      destroyed: this.clock.destroyed,
    };
  }

  /** See `TimelineClock.subscribe` — the `discontinuity` flag is the D1 contract. */
  subscribe(fn: (t: number, discontinuity?: boolean) => void): () => void {
    return this.clock.subscribe(fn);
  }

  /** Start (or resume) playback. At the end of a non-looping run, starts it over. */
  play(): void {
    if (this.clock.ended) this.clock.restart();
    this.clock.gate(INTENT, false);
  }

  /** Stop advancing (the SC 2.2.2 control). Keeps the position. */
  pause(): void {
    this.clock.gate(INTENT, true);
  }

  /**
   * The environment gate: the element sets it while the scene is off screen or the page
   * is hidden. Separate from `pause()` so releasing it never overrides what the user
   * asked for.
   */
  suspend(suspended: boolean): void {
    this.clock.gate(ENVIRONMENT, suspended);
  }

  /** Jump to a position (t ∈ [0..1]) without changing the play/pause state. */
  seek(t: number): void {
    this.clock.seek(t);
  }

  destroy(): void {
    this.clock.destroy();
  }
}
