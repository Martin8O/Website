/**
 * The wall-clock timeline (extracted at D2): the machinery every self-advancing driver
 * needs — elapsed time, looping, the capped frame delta, emit-on-change, the owed
 * initial value, the discontinuity flag and the on-demand rAF loop. D1 wrote all of it
 * inside `TimeDriver`; D2's view driver needs the same clock with one more gate, and a
 * second hand-written copy of these rules is exactly how two drivers drift apart.
 *
 * The one addition over D1 is that the gates are a **named set** instead of two flags.
 * The rule they encode does not change: a gate is a reason NOT to advance, gates never
 * merge, and releasing one may never override another (a driver scrolled back into view
 * while the user has it paused stays paused — ADR-034). Advancing ⟺ no gate is set, the
 * timeline has not ended, and the clock is alive.
 *
 * Layer note: no DOM beyond the injected `raf`/`caf`. Watching the *environment* (a
 * viewport, a page-visibility flag) belongs to the driver that owns that modality.
 */

/** dt cap — a long rAF stall (background tab, GC) advances like one slow frame. */
export const MAX_DT_MS = 100;

/**
 * Fallback length for a scene that declares no usable duration. A zero-length timeline
 * would pin t at 1 the moment it starts, which reads as a broken player rather than as
 * a mis-authored scene (the same defensive choice `scrollProgress` makes for a
 * degenerate region).
 */
export const DEFAULT_DURATION_MS = 5000;

/**
 * The frame-scheduling seam, injectable so the loop is deterministic in node tests. Not
 * a public extension point. There is no clock of its own: rAF hands the frame timestamp
 * in, which is the only time base a frame loop may trust.
 */
export interface TimelineClockEnv {
  raf(cb: (now: number) => void): number;
  caf(handle: number): void;
}

export interface TimelineClockOptions {
  /** Wall-clock length of one pass, in milliseconds. Non-finite or ≤ 0 → 5000. */
  durationMs?: number;
  /** Restart from 0 on reaching the end instead of stopping. Default false. */
  loop?: boolean;
  /** Test seam — override the frame scheduler. */
  env?: Partial<TimelineClockEnv>;
}

function defaultEnv(): TimelineClockEnv {
  return {
    raf: (cb) => requestAnimationFrame(cb),
    caf: (handle) => cancelAnimationFrame(handle),
  };
}

export type TimelineSubscriber = (t: number, discontinuity?: boolean) => void;

export class TimelineClock {
  readonly durationMs: number;

  private readonly env: TimelineClockEnv;
  private readonly loop: boolean;

  private readonly subscribers = new Set<TimelineSubscriber>();
  /** Subscribers that joined after the first frame and still owe an initial value. */
  private readonly pendingInitial = new Set<TimelineSubscriber>();
  /** Every reason the timeline is currently not allowed to advance. */
  private readonly gates = new Set<string>();

  private elapsed = 0;
  private current = 0;
  private emitted = NaN; // NaN ≠ anything → the first frame always emits
  private endedFlag = false;
  /** A jump the next frame must announce (loop wrap, seek, restart) — see `subscribe`. */
  private jump = false;
  private primedFlag = false;
  private lastNow = NaN; // NaN = the next frame only establishes the dt baseline
  private framePending = false; // separate from the handle: 0 is a legal handle value
  private rafHandle = 0;
  private frameCount = 0;
  private loopCount = 0;
  private destroyedFlag = false;

  constructor(options: TimelineClockOptions = {}) {
    this.env = { ...defaultEnv(), ...options.env };
    const declared = options.durationMs;
    this.durationMs =
      declared !== undefined && Number.isFinite(declared) && declared > 0 ? declared : DEFAULT_DURATION_MS;
    this.loop = options.loop ?? false;
    this.wake(); // initial frame: emit the starting t even when it starts gated
  }

  get t(): number {
    return this.current;
  }

  get elapsedMs(): number {
    return this.elapsed;
  }

  /** A non-looping timeline that has run out. `restart()` starts it over. */
  get ended(): boolean {
    return this.endedFlag;
  }

  /** True while frames are actually being scheduled. */
  get advancing(): boolean {
    return this.gates.size === 0 && !this.endedFlag && !this.destroyedFlag;
  }

  /** False until the first frame has run. */
  get primed(): boolean {
    return this.primedFlag;
  }

  get frames(): number {
    return this.frameCount;
  }

  /** Completed passes (looping only) — the wrap count. */
  get loops(): number {
    return this.loopCount;
  }

  get destroyed(): boolean {
    return this.destroyedFlag;
  }

  blocked(gate: string): boolean {
    return this.gates.has(gate);
  }

  /**
   * Set or release one reason not to advance. Releasing a gate drops the dt baseline, so
   * the time spent gated is never played back in one step; it never clears any OTHER
   * gate, which is what keeps intent and environment independent.
   */
  gate(name: string, blocked: boolean): void {
    if (this.destroyedFlag || this.gates.has(name) === blocked) return;
    if (blocked) this.gates.add(name);
    else this.gates.delete(name);
    this.lastNow = NaN;
    if (!blocked) this.wake();
  }

  /**
   * Register a sink for t changes. The second argument marks a **discontinuity** — a
   * loop wrap, a seek, a restart — i.e. "this t is not the continuation of the last
   * one". The element uses it to re-seed the §10 event tracker, which compares the
   * interval between frames: without the flag, a wrap from 1 back to 0 would look like
   * scrubbing backwards through the entire timeline and replay every window in reverse.
   *
   * A subscriber that joins after the first frame is owed an initial value, so a frame
   * is forced for it — otherwise a consumer subscribing after an `await` would render
   * nothing until the next change (and a gated clock would never render at all).
   */
  subscribe(fn: TimelineSubscriber): () => void {
    this.subscribers.add(fn);
    if (this.primedFlag && !this.destroyedFlag) {
      this.pendingInitial.add(fn);
      this.wake();
    }
    return () => {
      this.subscribers.delete(fn);
      this.pendingInitial.delete(fn);
    };
  }

  /** Start the timeline over from 0. A restart is not a continuation, so it jumps. */
  restart(): void {
    if (this.destroyedFlag) return;
    this.elapsed = 0;
    this.endedFlag = false;
    this.jump = true;
    this.lastNow = NaN;
    this.wake();
  }

  /** Jump to a position (t ∈ [0..1]) without touching any gate. */
  seek(t: number): void {
    if (this.destroyedFlag) return;
    const clamped = !Number.isFinite(t) ? 0 : t < 0 ? 0 : t > 1 ? 1 : t;
    this.elapsed = clamped * this.durationMs;
    this.endedFlag = clamped >= 1 && !this.loop;
    this.jump = true;
    this.lastNow = NaN;
    this.wake();
  }

  /** Schedule a frame if none is pending. */
  private wake(): void {
    if (this.destroyedFlag || this.framePending) return;
    this.framePending = true;
    this.rafHandle = this.env.raf(this.frame);
  }

  private readonly frame = (now: number): void => {
    // Cleared FIRST: anything happening during this body must be able to schedule the
    // next frame rather than be swallowed.
    this.framePending = false;
    if (this.destroyedFlag) return;
    this.frameCount++;

    if (this.primedFlag && this.advancing && !Number.isNaN(this.lastNow)) {
      // Cap dt so a throttled/background tab resumes instead of teleporting forward.
      this.elapsed += Math.min(now - this.lastNow, MAX_DT_MS);
      if (this.elapsed >= this.durationMs) {
        if (this.loop) {
          this.loopCount += Math.floor(this.elapsed / this.durationMs);
          this.elapsed %= this.durationMs;
          this.jump = true;
        } else {
          this.elapsed = this.durationMs;
          this.endedFlag = true;
        }
      }
    }
    this.primedFlag = true;
    // A non-advancing loop keeps no baseline: the next resume starts a fresh dt, so the
    // time spent gated or ended is never played back in one step.
    this.lastNow = this.advancing ? now : NaN;
    this.current = this.elapsed / this.durationMs;

    // Drain BEFORE emitting: anyone subscribing during the emit below stays owed and is
    // paid on the next frame instead of being missed by the snapshot taken here.
    const owed = [...this.pendingInitial];
    this.pendingInitial.clear();
    const discontinuity = this.jump;
    this.jump = false;

    if (this.current !== this.emitted || discontinuity) {
      this.emitted = this.current;
      // Snapshot: a subscriber may subscribe/unsubscribe from within its own callback.
      for (const fn of [...this.subscribers]) fn(this.current, discontinuity || undefined);
    } else {
      for (const fn of owed) if (this.subscribers.has(fn)) fn(this.current);
    }

    if (this.advancing) this.wake();
  };

  destroy(): void {
    if (this.destroyedFlag) return;
    this.destroyedFlag = true;
    if (this.framePending) {
      this.env.caf(this.rafHandle);
      this.framePending = false;
    }
    this.subscribers.clear();
    this.pendingInitial.clear();
  }
}
