/**
 * The view driver (D2): visibility is the trigger — the timeline plays on the wall clock,
 * but only once the scene has actually scrolled into the viewport, and it stops the
 * moment it leaves again. The "reveal animation" every drop-in player is asked for, with
 * no host JavaScript: `<vertie-scene driver="view">`.
 *
 * Three gates, all independent (ADR-034's rule, one gate wider):
 *  - **intent** — `pause()` / `play()`, the user or the author's `paused` attribute.
 *  - **environment** — `suspend()`, set by the element while the page is hidden.
 *  - **view** — this driver's own IntersectionObserver.
 * Releasing one never releases another: a scene the user paused while it was off screen
 * stays paused when it scrolls back in, which is the whole point of keeping them apart.
 *
 * What happens on re-entry is the one authored choice: by default the timeline **holds
 * where it stopped** (a finished reveal stays revealed), and `replay` restarts it from 0
 * on every entry. A restart is a jump, so it is announced as a `discontinuity` — without
 * that, §10's interval-tested event windows would replay the timeline backwards (ADR-032).
 *
 * ⚠ The threshold is a fraction of the TARGET's area, and the default element is 300vh
 * tall — a region taller than the viewport can never be more than `viewportHeight /
 * regionHeight` intersected, so a threshold above that could never be met. That silence
 * is diagnosed with a warning instead of looking like a broken player.
 */

import type { Driver } from "./types.js";
import { TimelineClock, type TimelineClockEnv } from "./timeline.js";

/** The gate the user (or the author's `paused` attribute) owns. */
const INTENT = "intent";
/** The gate the element owns: a hidden page. */
const ENVIRONMENT = "environment";
/** The gate this driver owns: is the scene actually on screen? */
const VIEW = "view";

/**
 * The driver's environment seam, injectable so the loop is deterministic in node tests —
 * and because a hidden preview tab delivers no IntersectionObserver callbacks at all, so
 * the live harness drives `enterView()` by hand instead. Not a public extension point.
 */
export interface ViewDriverEnv extends TimelineClockEnv {
  /**
   * Watch whether `target` is visible enough to count. Reports the current state as it
   * is installed and on every change; returns a teardown.
   */
  observeInView(target: Element, threshold: number, onChange: (inView: boolean) => void): () => void;
}

export interface ViewDriverOptions {
  /** Wall-clock length of one pass, in milliseconds. Non-finite or ≤ 0 → 5000. */
  durationMs?: number;
  /** Restart from 0 on reaching the end instead of stopping. Default false. */
  loop?: boolean;
  /** Start stopped: entering view then arms nothing until `play()`. Default false. */
  paused?: boolean;
  /**
   * How much of the region must be visible to count as "in view", as a fraction of the
   * region's own area (the IntersectionObserver meaning). Default 0 = any part of it.
   */
  threshold?: number;
  /** Restart from 0 on every entry instead of holding the current position. Default false. */
  replay?: boolean;
  /** Test seam — override the frame scheduler and the visibility source. */
  env?: Partial<ViewDriverEnv>;
}

/** Plain snapshot for the `window.__vertie` no-screenshot verification channel. */
export interface ViewDriverDebug {
  t: number;
  /** Playback intent: what the pause control shows. */
  paused: boolean;
  /** Environment gate: a hidden page. */
  suspended: boolean;
  /** The view gate, as the observer last reported it. */
  inView: boolean;
  /** True while frames are actually being scheduled. */
  advancing: boolean;
  /** A non-looping timeline that reached t = 1 (a re-entry with `replay` restarts it). */
  ended: boolean;
  /** Completed passes (looping only) — the wrap count. */
  loops: number;
  /** How many times the region has entered the viewport (whether or not it then played). */
  entries: number;
  elapsedMs: number;
  durationMs: number;
  threshold: number;
  replay: boolean;
  /** False until the first frame has run. */
  primed: boolean;
  frames: number;
  destroyed: boolean;
}

/**
 * Can a threshold ever be met? The intersection ratio is measured against the target's
 * own area, so a target taller than the viewport tops out at `viewportHeight/height`.
 * Pure so the rule is testable without a layout.
 */
export function thresholdReachable(targetHeight: number, viewportHeight: number, threshold: number): boolean {
  if (threshold <= 0) return true;
  // Nothing measurable (a detached node, a zero-height box): do not cry wolf.
  if (!(targetHeight > 0) || !(viewportHeight > 0)) return true;
  return viewportHeight / targetHeight >= threshold;
}

function defaultEnv(): ViewDriverEnv {
  return {
    raf: (cb) => requestAnimationFrame(cb),
    caf: (handle) => cancelAnimationFrame(handle),
    observeInView(target, threshold, onChange) {
      // No observer (old browser, jsdom) = assume visible: a player that can never see
      // the scene must still play it, exactly like the element's own in-view gate.
      if (typeof IntersectionObserver !== "function") {
        onChange(true);
        return () => {};
      }
      if (typeof window !== "undefined") {
        const height = target.getBoundingClientRect().height;
        if (!thresholdReachable(height, window.innerHeight, threshold)) {
          console.warn(
            `vertie: driver="view" threshold=${threshold} can never be met — the region is ` +
              `${Math.round(height)}px tall in a ${window.innerHeight}px viewport ` +
              `(max ${(window.innerHeight / height).toFixed(2)}). The scene would never start.`,
          );
        }
      }
      const observer = new IntersectionObserver(
        (entries) => {
          const entry = entries.at(-1);
          // `isIntersecting` alone is not enough above threshold 0: the callback also
          // fires on the way OUT of a threshold band, where the ratio is what decides.
          if (entry) onChange(entry.isIntersecting && entry.intersectionRatio >= threshold);
        },
        { rootMargin: "0px", threshold },
      );
      observer.observe(target); // fires once with the current state
      return () => observer.disconnect();
    },
  };
}

export class ViewDriver implements Driver {
  /**
   * Once it is on screen this driver moves without the user, so the element must offer a
   * way to stop it — the same SC 2.2.2 capability flag the time driver sets (D1).
   */
  readonly pausable = true;

  private readonly clock: TimelineClock;
  private readonly replay: boolean;
  private readonly thresholdValue: number;
  private readonly unobserve: () => void;
  private inViewFlag = false;
  private entryCount = 0;
  private destroyedFlag = false;

  constructor(target: Element, options: ViewDriverOptions = {}) {
    const env = { ...defaultEnv(), ...options.env };
    this.clock = new TimelineClock({
      ...(options.durationMs !== undefined ? { durationMs: options.durationMs } : {}),
      ...(options.loop !== undefined ? { loop: options.loop } : {}),
      env,
    });
    this.replay = options.replay ?? false;
    this.thresholdValue = clampThreshold(options.threshold);
    // Gated until the observer says otherwise: a scene the reader has not reached yet
    // still draws its first frame (the clock scheduled it) and then costs nothing.
    this.clock.gate(VIEW, true);
    if (options.paused ?? false) this.clock.gate(INTENT, true);
    this.unobserve = env.observeInView(target, this.thresholdValue, (inView) => this.enterView(inView));
  }

  get t(): number {
    return this.clock.t;
  }

  /** Playback intent (the pause control), independent of visibility. */
  get paused(): boolean {
    return this.clock.blocked(INTENT);
  }

  /** A non-looping pass that has run out. `play()` — or a `replay` entry — starts it over. */
  get ended(): boolean {
    return this.clock.ended;
  }

  /** Is the region on screen, as the observer last reported it? */
  get inView(): boolean {
    return this.inViewFlag;
  }

  get debug(): ViewDriverDebug {
    return {
      t: this.clock.t,
      paused: this.paused,
      suspended: this.clock.blocked(ENVIRONMENT),
      inView: this.inViewFlag,
      advancing: this.clock.advancing,
      ended: this.clock.ended,
      loops: this.clock.loops,
      entries: this.entryCount,
      elapsedMs: this.clock.elapsedMs,
      durationMs: this.clock.durationMs,
      threshold: this.thresholdValue,
      replay: this.replay,
      primed: this.clock.primed,
      frames: this.clock.frames,
      destroyed: this.destroyedFlag,
    };
  }

  /** See `TimelineClock.subscribe` — the `discontinuity` flag is the D1 contract. */
  subscribe(fn: (t: number, discontinuity?: boolean) => void): () => void {
    return this.clock.subscribe(fn);
  }

  /**
   * The observer's sink, public because a hidden tab delivers no IntersectionObserver
   * callbacks — `dev().setInView()` drives this directly (and so do the tests).
   *
   * Entering releases ONLY the view gate: a paused scene stays paused, and a finished
   * one stays finished unless `replay` asked for a fresh pass.
   */
  enterView(inView: boolean): void {
    if (this.destroyedFlag || this.inViewFlag === inView) return;
    this.inViewFlag = inView;
    if (!inView) {
      this.clock.gate(VIEW, true);
      return;
    }
    this.entryCount++;
    // `restart()` marks the jump, so §10's windows re-seed instead of running backwards.
    if (this.replay && (this.clock.elapsedMs > 0 || this.clock.ended)) this.clock.restart();
    this.clock.gate(VIEW, false);
  }

  /** Start (or resume) playback. At the end of a non-looping run, starts it over. */
  play(): void {
    if (this.clock.ended) this.clock.restart();
    this.clock.gate(INTENT, false);
  }

  /** Stop advancing (the SC 2.2.2 control). Keeps the position. */
  pause(): void {
    this.clock.gate(INTENT, true);
  }

  /** The environment gate (a hidden page) — the element owns it; visibility is ours. */
  suspend(suspended: boolean): void {
    this.clock.gate(ENVIRONMENT, suspended);
  }

  /** Jump to a position (t ∈ [0..1]) without changing any gate. */
  seek(t: number): void {
    this.clock.seek(t);
  }

  destroy(): void {
    if (this.destroyedFlag) return;
    this.destroyedFlag = true;
    this.unobserve();
    this.clock.destroy();
  }
}

/** IntersectionObserver throws outside [0..1]; a typo becomes a warning, not a crash. */
function clampThreshold(value: number | undefined): number {
  if (value === undefined || !Number.isFinite(value)) return 0;
  if (value < 0 || value > 1) {
    console.warn(`vertie: driver="view" threshold=${value} is outside 0..1 — clamped`);
    return value < 0 ? 0 : 1;
  }
  return value;
}
