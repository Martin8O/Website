/**
 * The pointer/scrub driver (D3): the pointer's position over the scene is the timeline.
 * `<vertie-scene driver="pointer">` — move across it and the camera moves with you; the
 * turntable/hover-scrub every product page asks for, with no host JavaScript.
 *
 * One behaviour, not two. t follows the pointer whenever a `pointermove` arrives over
 * the element, which gives a mouse its hover-scrub AND a touch its drag-scrub for free:
 * a touch pointer only reports moves while it is down, so "hover" and "drag" are the same
 * code path on the only devices where each exists. `drag: true` narrows it for the mouse
 * as well — nothing moves until a button is held — and a press positions t immediately,
 * so a single tap is a complete interaction (WCAG 2.2 SC 2.5.7 never becomes an issue).
 *
 * What it deliberately does NOT do:
 *  - it never advances by itself, so it is not `pausable` (SC 2.2.2 does not apply —
 *    the user's own pointer is the pause mechanism, exactly as scroll's is);
 *  - it never calls `preventDefault()`/`stopPropagation()` and registers every listener
 *    passively, so the page keeps its scroll (`docs/a11y.md` §4);
 *  - it never captures the pointer: a capture would retarget the page's own overlaid
 *    links mid-drag. A mouse that releases outside is caught by `buttons === 0` on the
 *    next move instead, and touch gets implicit capture from the browser.
 *
 * Keyboard is NOT this driver's job and is not optional either: a pointer-only timeline
 * would fail SC 2.1.1. The driver reports `scrubbable` and the element answers it with a
 * real range control in its shadow root (`docs/a11y.md` §3), which reaches this file as
 * plain `seek()` calls — the same door `dev()` uses.
 */

import type { Driver } from "./types.js";
import { ChaseLoop, type ChaseLoopEnv } from "./chase.js";
// The map-and-clamp rule is not scroll-specific (only its C4 name is): value, range
// start, range size — with the same NaN/degenerate guards, which matter just as much for
// a zero-width box as they do for a region shorter than the viewport.
import { scrollProgress } from "./progress.js";

/** Which way across the box the timeline runs. */
export type PointerAxis = "x" | "y";

/** The pointer kinds the driver listens for. */
export type PointerInputType = "pointermove" | "pointerdown" | "pointerup" | "pointercancel" | "pointerleave";

/**
 * The slice of a `PointerEvent` the driver reads. Named so the test seam does not have to
 * synthesize DOM events, and so it is obvious that nothing else about the event is
 * touched — no target inspection, no cancellation.
 */
export interface PointerSample {
  clientX: number;
  clientY: number;
  /** `PointerEvent.buttons` — 0 means nothing is held (a mouse released off-element). */
  buttons: number;
}

/** The element's box in client (viewport) coordinates — what a pointer position maps into. */
export interface PointerBox {
  left: number;
  top: number;
  width: number;
  height: number;
}

/**
 * The driver's DOM seam, injectable so the loop is deterministic in node tests. Not a
 * public extension point.
 */
export interface PointerDriverEnv extends ChaseLoopEnv {
  /** The box a pointer position is mapped into, in client coordinates. */
  measure(target: Element): PointerBox;
  /** Registered passively — the options object is part of the contract, not a detail. */
  addListener(
    target: Element,
    type: PointerInputType,
    fn: (event: PointerSample) => void,
    options: { passive: true },
  ): void;
  removeListener(target: Element, type: PointerInputType, fn: (event: PointerSample) => void): void;
  /** Watch for layout shifts that move the box without a pointer event. Returns a teardown. */
  observeLayout(target: Element, onChange: () => void): () => void;
  prefersReducedMotion(): boolean;
}

export interface PointerDriverOptions {
  /** Which way across the box t runs. Default `"x"`. */
  axis?: PointerAxis;
  /** Require a held button: nothing moves until a pointer is down. Default false. */
  drag?: boolean;
  /**
   * Damping rate λ (1/s) for the chase toward the pointer — the same smoothing the
   * scroll driver applies to scroll steps. 0 = t lands exactly on the pointer. Default 8.
   */
  damping?: number;
  /**
   * Under `prefers-reduced-motion: reduce`, drop the damping so t never keeps moving
   * after the pointer stopped. Default true (see `docs/a11y.md` §2).
   */
  respectReducedMotion?: boolean;
  /**
   * A gate the host closes while one of its OWN controls owns the pointer — the element
   * uses it for the scrub slider, which sits over the scene and would otherwise be
   * scrubbing the timeline twice at once.
   */
  ignoreInput?: () => boolean;
  /** Test seam — override the DOM environment. */
  env?: Partial<PointerDriverEnv>;
}

/** Plain snapshot for the `window.__vertie` no-screenshot verification channel. */
export interface PointerDriverDebug {
  t: number;
  /** Where t is heading — the mapped pointer position (or the last `seek`). */
  targetT: number;
  axis: PointerAxis;
  drag: boolean;
  /** True while a pointer is held down on the element. */
  dragging: boolean;
  /** Was the last thing we heard a move over the element (rather than a leave)? */
  inside: boolean;
  /** True once the first frame has run AND the damped value has caught up. */
  settled: boolean;
  /** False until the first frame has run. */
  primed: boolean;
  frames: number;
  /** Box measurements — one per frame that carries new pointer input, never per event. */
  measures: number;
  destroyed: boolean;
}

const POINTER_TYPES: PointerInputType[] = [
  "pointermove",
  "pointerdown",
  "pointerup",
  "pointercancel",
  "pointerleave",
];

function defaultEnv(): PointerDriverEnv {
  return {
    raf: (cb) => requestAnimationFrame(cb),
    caf: (handle) => cancelAnimationFrame(handle),
    measure: (target) => {
      const rect = target.getBoundingClientRect();
      return { left: rect.left, top: rect.top, width: rect.width, height: rect.height };
    },
    // A real `PointerEvent` structurally IS a `PointerSample`; the cast is only there
    // because `EventListener` is declared over the base `Event`. The function identity is
    // untouched, which is what `removeEventListener` matches on.
    addListener: (target, type, fn, options) =>
      target.addEventListener(type, fn as unknown as EventListener, options),
    removeListener: (target, type, fn) =>
      target.removeEventListener(type, fn as unknown as EventListener),
    observeLayout: (target, onChange) => {
      if (typeof ResizeObserver !== "function") return () => {};
      const observer = new ResizeObserver(onChange);
      observer.observe(target);
      return () => observer.disconnect();
    },
    prefersReducedMotion: () =>
      typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches,
  };
}

/** Map a pointer position onto t across the box, along one axis. Pure. */
export function pointerProgress(point: { x: number; y: number }, box: PointerBox, axis: PointerAxis): number {
  return axis === "y"
    ? scrollProgress(point.y, box.top, box.height)
    : scrollProgress(point.x, box.left, box.width);
}

export class PointerDriver implements Driver {
  /**
   * This driver has no keyboard of its own, so the element owes it one: `scrubbable`
   * makes the player show a real range control wired to `seek()` (`docs/a11y.md` §3).
   */
  readonly scrubbable = true;

  private readonly element: Element;
  private readonly env: PointerDriverEnv;
  private readonly axis: PointerAxis;
  private readonly dragOnly: boolean;
  private readonly ignoreInput: (() => boolean) | undefined;
  private readonly unobserveLayout: () => void;
  private readonly loop: ChaseLoop;

  /** Where t is heading: the mapped pointer position, or whatever last `seek()` asked for. */
  private targetProgress = 0;
  /** The last pointer position we accepted, kept so a layout change can be re-mapped. */
  private point: { x: number; y: number } | null = null;
  /** Set by a handler, consumed by the frame — the "there is new input" flag. */
  private pointDirty = false;
  private draggingFlag = false;
  private insideFlag = false;
  private measures = 0;
  private destroyedFlag = false;

  // Stable bound handlers so removeListener() can match them.
  private readonly handlers: Record<PointerInputType, (event: PointerSample) => void> = {
    pointermove: (event) => this.onMove(event),
    pointerdown: (event) => this.onDown(event),
    pointerup: () => this.endDrag(),
    pointercancel: () => this.endDrag(),
    pointerleave: () => {
      // Hold where it is: snapping back to 0 the moment the pointer leaves reads as the
      // scene resetting itself, which is never what a scrub is for.
      this.insideFlag = false;
    },
  };

  constructor(target: Element, options: PointerDriverOptions = {}) {
    this.element = target;
    this.env = { ...defaultEnv(), ...options.env };
    this.axis = options.axis === "y" ? "y" : "x";
    this.dragOnly = options.drag ?? false;
    this.ignoreInput = options.ignoreInput;
    const reduced = (options.respectReducedMotion ?? true) && this.env.prefersReducedMotion();
    this.loop = new ChaseLoop({
      damping: reduced ? 0 : (options.damping ?? 8),
      sample: () => this.sample(),
      ...(options.env ? { env: options.env } : {}),
    });

    for (const type of POINTER_TYPES) {
      this.env.addListener(target, type, this.handlers[type], { passive: true });
    }
    this.unobserveLayout = this.env.observeLayout(target, () => this.invalidate());
    this.loop.wake(); // initial frame: emit the starting t (0) like every other driver
  }

  get t(): number {
    return this.loop.t;
  }

  /** Is a pointer currently held down on the element? */
  get dragging(): boolean {
    return this.draggingFlag;
  }

  get debug(): PointerDriverDebug {
    return {
      t: this.loop.t,
      targetT: this.loop.target,
      axis: this.axis,
      drag: this.dragOnly,
      dragging: this.draggingFlag,
      inside: this.insideFlag,
      settled: this.loop.settled,
      primed: this.loop.primed,
      frames: this.loop.frames,
      measures: this.measures,
      destroyed: this.destroyedFlag,
    };
  }

  subscribe(fn: (t: number) => void): () => void {
    return this.loop.subscribe(fn);
  }

  /**
   * Jump to a position (t ∈ [0..1]) — the element's scrub control, and `dev()`. It LANDS
   * rather than easing: damping exists to smooth a stream of input samples, but a seek is
   * a position the user named, and easing toward it would leave the control showing one
   * place while the scene showed another (and a held arrow key fighting the write-back).
   *
   * No `discontinuity` is reported, deliberately: a scrub is exactly what §10's
   * interval-tested windows are built for — a jump crosses every window between the two
   * frames, which is what a fast pointer sweep does too (ADR-032).
   */
  seek(t: number): void {
    if (this.destroyedFlag) return;
    this.targetProgress = !Number.isFinite(t) ? 0 : t < 0 ? 0 : t > 1 ? 1 : t;
    this.pointDirty = false; // the seek wins this frame; the next move takes over again
    this.loop.snapNextFrame();
    this.loop.wake();
  }

  /**
   * Re-map the last pointer position against a fresh measurement. Called by the layout
   * observer and by the element on resize: the box moves with the page, and the mapping
   * would otherwise stay on the geometry that was true when the pointer last moved.
   */
  invalidate(): void {
    if (this.destroyedFlag || !this.point) return;
    this.pointDirty = true;
    this.loop.wake();
  }

  destroy(): void {
    if (this.destroyedFlag) return;
    this.destroyedFlag = true;
    for (const type of POINTER_TYPES) {
      this.env.removeListener(this.element, type, this.handlers[type]);
    }
    this.unobserveLayout();
    this.loop.destroy();
  }

  /**
   * The loop's per-frame read. The box is measured only when there is new input to map —
   * one `getBoundingClientRect()` per input frame, never one per event (moves coalesce
   * into a single frame) and never during the damping tail.
   */
  private sample(): number {
    if (this.pointDirty && this.point) {
      this.pointDirty = false;
      this.measures++;
      this.targetProgress = pointerProgress(this.point, this.env.measure(this.element), this.axis);
    }
    return this.targetProgress;
  }

  /** The one thing a handler may do: record the position and schedule a frame. */
  private accept(event: PointerSample): void {
    this.point = { x: event.clientX, y: event.clientY };
    this.pointDirty = true;
    this.insideFlag = true;
    this.loop.wake();
  }

  private onMove(event: PointerSample): void {
    if (this.ignoreInput?.()) return;
    if (this.draggingFlag && event.buttons === 0) {
      // The mouse was released somewhere we never heard about (outside the element, over
      // another frame). No capture is taken, so this is where a stale drag ends.
      this.draggingFlag = false;
      if (this.dragOnly) return;
    }
    if (this.dragOnly && !this.draggingFlag) return;
    this.accept(event);
  }

  private onDown(event: PointerSample): void {
    if (this.ignoreInput?.()) return;
    this.draggingFlag = true;
    // A press positions t on the spot — that is what makes a single tap a complete
    // interaction on touch, and what keeps drag mode reachable without a drag.
    this.accept(event);
  }

  private endDrag(): void {
    this.draggingFlag = false;
  }
}
