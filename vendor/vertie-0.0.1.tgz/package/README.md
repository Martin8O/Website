# vertie

**An open format + drop-in web player for 3D scenes on the web.**
*Vertie is to 3D what Lottie is to 2D.*

Describe a 3D scene — models, camera choreography, events — as a small JSON file, then play it
anywhere with one line of HTML. Drive it by **scroll** (flagship), time, visibility, or pointer.
Built on glTF and three.js. Open spec, MIT player, no server, no telemetry.

> **Pre-release.** The format spec and the player are being built in the open. The API below is
> implemented and tested, but nothing is stable until 1.0 — pin an exact version.

## Install

```bash
npm install vertie three
```

`three` is a **peer dependency**: your app owns the version, and only one copy of three ends up in
your bundle.

```js
import "vertie"; // registers <vertie-scene>
```

Or with no build step at all, from a CDN — this build has three inlined:

```html
<script type="module" src="https://cdn.jsdelivr.net/npm/vertie@0.0.1/dist/vertie.standalone.js"></script>
```

Add `integrity="sha384-…"` + `crossorigin="anonymous"` for subresource integrity; the hash of every
shipped bundle is in `dist/integrity.txt` inside the package.

## Use

```html
<vertie-scene src="scene.json" style="--vertie-height: 300vh">
  <!-- Your page's own text lives here, in the light DOM: selectable, indexable,
       and readable even when WebGL never starts. -->
  <h2>Chapter one</h2>
</vertie-scene>
```

The element **is** the scroll region: it is as tall as `--vertie-height`, keeps a sticky canvas
pinned in the viewport, and maps that travel to scene progress `t ∈ [0..1]`.

### Attributes

| attribute | meaning |
| --- | --- |
| `src` | scene document URL (required) |
| `assets` | base URL for the scene's assets — defaults to the scene document's own URL |
| `driver` | `scroll` (default) · `time` · `view` · `pointer` · `external` |
| `poster` | image shown until the scene is ready, and instead of it on the fallback rungs |
| `region` | CSS selector for an external scroll region (escape hatch) |
| `damping`, `offset-start`, `offset-end` | driver tuning (scroll, pointer) |
| `duration`, `loop`, `paused` | driver tuning (time) |
| `threshold`, `replay` | driver tuning (view) |
| `axis`, `drag` | driver tuning (pointer) |
| — | `external` has no attributes: the host pushes `t` — see below |
| `frustum-clamp` | keep every authored key inside the frame at any viewport — see below |
| `debug` | expose the verification helpers on `window.__vertie` |
| `state` | **read-only, reflected**: `loading` · `ready` · `static` · `error` |

### When your page already owns the progress — `driver="external"`

Some pages compute their own timeline: a smooth-scroll library's virtual position, a chapter
that is stretched or warped, a value two layers must share to the frame. Point the element at
it instead of letting it measure a region of its own:

```html
<vertie-scene id="hero" src="scene.json" driver="external"></vertie-scene>
```
```js
const hero = document.querySelector("#hero");

function frame() {
  hero.t = myTimeline.progress;          // 0..1 — out of range is clamped for you
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

// A jump the reader did not scrub through (a nav teleport, a chapter change):
hero.setT(0.05, { discontinuity: true });   // re-seeds the scene's event windows
```

**Push it from a frame** — your `requestAnimationFrame`, your render loop, your scroll
library's own tick — never from a `scroll` or `pointermove` handler. This driver has no loop
of its own: the assignment renders synchronously, so the scene lands in the same paint as
everything else you drew from that value, and your frame budget stays yours. An unchanged
value costs nothing, a value pushed before the scene is ready is where it opens, and no
smoothing is applied on top of yours (there is no `damping` here on purpose).

Accessibility note: when you own `t`, you own WCAG SC 2.2.2 for it — if your source advances
on its own rather than following the reader, provide a way to stop it. See
[`docs/a11y.md`](https://github.com/Martin8O/Vertie/blob/main/docs/a11y.md) §3.

### Responsive framing — `frustum-clamp`

A scene's `stage` frames the **reference plane** you composed against. Choreography that
deliberately runs wider than that plane — "the move should span the screen" — can still put a
key outside the viewport on an aspect ratio you never tried, because a key in front of or
behind the plane sits in a different frustum than the plane does.

`frustum-clamp` turns on the spec's §9 data-aware clamp: every authored key is scaled
laterally so it stays inside the frame **at its own depth**, and never scaled above the
authored 1×.

```html
<!-- clamp to the frame edge -->
<vertie-scene src="scene.json" frustum-clamp></vertie-scene>

<!-- keep a margin: a key is a pivot, and the model hangs off it -->
<vertie-scene src="scene.json" frustum-clamp="0.87"></vertie-scene>
```

Off by default (it changes framing), and ignored with a warning for a scene that carries its
own camera track — a moving frustum has no single factor. The clamp lives in the renderer, so
`vertie-event`'s `follow` coordinates already account for it.

### Events

`vertie-progress` `{progress, phase}` · `vertie-ready` · `vertie-error` `{error, phase}` ·
`vertie-fallback` `{reason, rung}` — all bubbling and composed.

Scenes can also signal the page directly:

`vertie-event` `{name, phase, time, progress, data, follow}` — a **named timeline signal** the
scene declares (`events`). `phase` is `enter` · `progress` · `leave` for the window
`[at, at + span]`, in both scroll directions; a point event (`span: 0`) fires when the scrub
crosses it. `data` is the event's `x-*` payload, verbatim. An event that declares `follow` also
carries where that track's object is — in the world, and projected to `{x, y, visible}` in canvas
pixels, so a plain DOM label can ride along with a moving object.

`vertie-trigger` `{name, on, target, time, point, screen, data}` — an **input signal** (`triggers`):
the player raycasts the rendered scene, so a click or hover on an actual 3D object reaches you as a
DOM event with no 3D code on your page. `name` is the trigger's `emit`.

```js
scene.addEventListener("vertie-trigger", (e) => showSpec(e.detail.name));
```

## Accessibility and the fallback ladder

The player decides how to present itself **before it requests a single byte**:
`prefers-reduced-motion: reduce` stops the motion (the poster if you gave one, otherwise a single
static frame at `t = 0`); a browser without WebGL2 gets the poster, or your light-DOM content
alone. Neither is an error — both dispatch `vertie-fallback`. Rendering also pauses while the
scene is off screen or the tab is hidden. The normative contract, with its WCAG citations, is
[`docs/a11y.md`](https://github.com/Martin8O/Vertie/blob/main/docs/a11y.md).

## Builds

| file | three | for |
| --- | --- | --- |
| `dist/vertie.js` | external (peer) | npm + bundlers — **36 kB gz** |
| `dist/vertie.standalone.js` | inlined | `<script type="module">` from a CDN — 211 kB gz |
| `dist/vertie.capture.js` | external (peer) | `vertie/capture`, video export — opt-in, 38 kB gz |
| `dist/decoders/` | — | Draco + Basis payloads, fetched lazily and only if a scene uses them |

Compressed geometry and textures need decoder payloads. With the npm build three resolves its own,
so there is nothing to configure. The standalone build ships a copy next to the bundle, so a
production embed never calls out to a third-party origin. Override either with
`SceneRendererOptions.decoderPath`.

> **Using Vite?** Add `optimizeDeps: { exclude: ["three"] }` to your config. Vite's dependency
> pre-bundling rewrites three into `node_modules/.vite/deps/`, which breaks the relative URLs its
> loaders use to find the Draco/Basis payloads — and the dev server answers those requests with
> `index.html` instead of a 404, so a compressed scene hangs at "decoding" with no error. Production
> builds are unaffected.

## Export a scene to video

```js
import { captureScene, captureSupport } from "vertie/capture";

if (captureSupport().supported) {
  const { blob, format } = await captureScene({
    scene: "/scene.json",
    width: 1920,
    height: 1080,
    fps: 30,
    duration: 8,            // seconds; defaults to the scene's own length
    background: "#ffffff",  // video has no alpha — without this, transparent means black
    onProgress: (p) => console.log(`${p.frame}/${p.frames}`),
  });
  // → an MP4 (H.264) you can post anywhere. `format` reports what you actually got.
}
```

A separate entry on purpose: it is downloaded only by a page that actually exports, so the
player itself never pays for it. It renders through its **own offscreen canvas**, so the output
resolution has nothing to do with how big the scene is on the page, and the export cannot be
disturbed by the reader scrolling. Frame *i* always renders at the same *t*, so the same options
produce the same file every time.

Needs the WebCodecs `VideoEncoder` (Chrome/Edge 94+, Safari 16.4+, Firefox 130+). Where it is
missing, `captureSupport().supported` is `false` and `captureScene` throws
`CaptureError` with `code: "unsupported"` — there is deliberately no `MediaRecorder` fallback,
because it timestamps by the wall clock and cannot produce a correct-length file.

A 1080p export runs at roughly 40 frames/second, so a 60-second video takes a minute or two —
show the `onProgress` value, and pass an `AbortSignal` so it can be cancelled.

## API

`<vertie-scene>` is the whole player, but the layers underneath are exported and usable on their
own: `validateScene` (format) · `compileScene` / `evaluate` (the pure, deterministic evaluator) ·
`ScrollDriver` / `TimeDriver` / `ViewDriver` / `PointerDriver` (input → `t`) · `SceneRenderer` /
`ScenePreloader` (three.js rendering) · `captureScene` from `vertie/capture` (video export).

- Repository, spec and docs: <https://github.com/Martin8O/Vertie>
- License: MIT (player) · CC0 (format spec)
