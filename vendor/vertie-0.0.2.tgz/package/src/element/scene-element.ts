/**
 * The `element` layer: `<vertie-scene>` — the public face of the player (ADR-002).
 *
 * `format` → `core` → `drivers` → `render` → **`element` (this)**. It owns no math, no
 * loop and no GPU state; it is the wiring that turns four libraries into a one-line
 * embed: fetch the scene document, validate it, build the renderer, gate the preload on
 * the region approaching the viewport, then let the driver's t drive evaluate → apply →
 * render. Everything it does with those layers is the integration order they were
 * hardened for (ADR-026/027): the driver is constructed BEFORE the awaited preload and
 * subscribed AFTER it, an `AbortError` is a normal cancel rather than a failure, and no
 * work happens outside the driver's rAF.
 *
 * The attribute/event surface is a **public contract** (ADR-002): additive-only, so the
 * names here are chosen once. Canvas lives in the Shadow DOM; the page's own text stays
 * in the light DOM through a `<slot>` — it must remain selectable, indexable and
 * readable when WebGL never starts (the SEO/a11y half of the contract).
 *
 * C6 hangs the **fallback ladder** off that start-up (see `docs/a11y.md` for the
 * normative contract and its WCAG citations). Before a single byte is requested the
 * element decides which rung it is on:
 *
 *  1. `prefers-reduced-motion: reduce` → **no motion at all**. Scroll-driven camera
 *     movement is "motion animation triggered by interaction" (WCAG 2.3.3), and panning
 *     a large object is a textbook vestibular trigger — so with a `poster` we show the
 *     poster and never touch the GPU or the network, and without one we load the scene
 *     and draw exactly ONE frame, never subscribing to the driver.
 *  2. **No WebGL2** → the poster if there is one, otherwise the page's own light-DOM
 *     content, alone. This is a *successful degraded outcome*, not a `vertie-error`.
 *  3. **Light DOM stands either way** — the text a user (or a crawler) needs is never
 *     inside the canvas.
 *
 * Rendering also **pauses while the region is out of view or the page is hidden**: a
 * scene nobody can see must not spend a frame, a watt or a degree of thermal budget.
 *
 * Everything that touches the outside world goes through the `VertieSceneEnv` seam, the
 * same pattern `ScrollDriverEnv` and `ScenePreloaderEnv` use: it keeps the element
 * testable in node without three or a GPU, and it is how a hidden preview tab (where
 * IntersectionObserver never fires) can still be driven.
 */

import type { Scene, Vec3 } from "../format/types.js";
import { validateScene } from "../format/validate.js";
import { compileScene, createSceneState, evaluate } from "../core/evaluate.js";
import { compileEvents, EventTracker } from "../core/events.js";
import type { CompiledEvent, EventPhase } from "../core/events.js";
import type { CompiledScene, SceneState } from "../core/types.js";
import type { Driver } from "../drivers/types.js";
import { createDriver, resolveDriverKind } from "../drivers/registry.js";
import type { DriverKind, DriverSpec } from "../drivers/registry.js";
import type { PointerAxis } from "../drivers/pointer.js";
import { SceneRenderer } from "../render/renderer.js";
import type { SceneRendererDebug, SceneRendererOptions } from "../render/renderer.js";
import type { PickResult, ScreenPoint } from "../render/pick.js";
import { TriggerController } from "./triggers.js";
import type {
  TriggerControllerDebug,
  TriggerControllerOptions,
  TriggerSignal,
} from "./triggers.js";
import { ScenePreloader, defaultPreloaderEnv } from "../render/preload.js";
import type {
  PreloadPhase,
  PreloadTarget,
  ScenePreloaderDebug,
  ScenePreloaderOptions,
} from "../render/preload.js";

/**
 * Exposed on the debug hook (`window.__vertie.version`) so a page can tell which build it
 * is talking to. Deliberately a plain literal rather than a build-time define — the source
 * tests read the same value the browser does — and `test/packaging.test.ts` pins it to
 * `package.json`, so a version bump that forgets this constant fails the gate (C7).
 */
export const VERTIE_VERSION = "0.0.2";

/** The registered tag name (ADR-002). `defineVertieScene(tag)` can register another. */
export const DEFAULT_TAG = "vertie-scene";

/** WCAG 2.3.3's sufficient technique SCR40 — the same query the driver reads for damping. */
const REDUCED_MOTION_QUERY = "(prefers-reduced-motion: reduce)";

/** Where an error happened — part of the `vertie-error` detail contract. */
export type VertieErrorPhase = "config" | "fetch" | "validate" | "load";

/** Why the player stepped down the fallback ladder (C6). Additive: new reasons may appear. */
export type VertieFallbackReason = "reduced-motion" | "no-webgl2";

/**
 * Which rung it landed on: the `poster` image · a single static `frame` of the real
 * scene · the page's own light-DOM `text`, with nothing drawn at all.
 */
export type VertieFallbackRung = "poster" | "frame" | "text";

/**
 * The element's settled presentation, reflected to the read-only `state` attribute so a
 * page can style it without any JS (`vertie-scene[state="static"] .scroll-hint { … }`).
 * `static` = settled, but nothing will move.
 */
export type VertieState = "loading" | "ready" | "static" | "error";

export interface VertieFallbackDetail {
  reason: VertieFallbackReason;
  rung: VertieFallbackRung;
}

export interface VertieProgressDetail {
  /** 0..1, monotonic. NB the environment map's bytes are invisible here (three owns that fetch). */
  progress: number;
  phase: PreloadPhase;
}

export interface VertieErrorDetail {
  error: Error;
  phase: VertieErrorPhase;
}

/** Where a `follow` event's tracked object is right now (spec §10). */
export interface VertieFollowDetail {
  /** The followed track's id. */
  id: string;
  /**
   * Where its object is in the world: the animated pose composed with the track's static
   * `transform` (§7), so this points at what the viewer sees rather than at the group's
   * origin. Identical to the bare pose for the common case of a track without a transform.
   */
  position: Vec3;
  /**
   * That position projected into the canvas box (CSS pixels, top-left origin) — what a
   * host needs to park a DOM label on a moving object. Null when the renderer cannot
   * project (no surface yet, or a stub without projection).
   */
  screen: ScreenPoint | null;
}

/**
 * A named timeline signal (spec §10), delivered as `vertie-event`. The player renders
 * nothing for it: the host decides what a name means. `enter`/`leave` bracket the
 * window `[at, at+span]` in both scroll directions; `progress` repeats while inside.
 */
export interface VertieEventDetail {
  /** The author's `name`, verbatim. */
  name: string;
  phase: EventPhase;
  /** Scene-local time of the frame that produced this signal. */
  time: number;
  /** Position inside the window, 0..1 (always 0 for a point event). */
  progress: number;
  /** The event's verbatim `x-*` payload. */
  data: Record<string, unknown>;
  /** Present only for an event that declares `follow`. */
  follow: VertieFollowDetail | null;
}

/**
 * An input signal (spec §11), delivered as `vertie-trigger` — the player raycasted the
 * rendered scene so the host never has to touch 3D. A trigger only signals: it cannot
 * seek or play the timeline (ADR-009 defers actions post-1.0).
 */
export type VertieTriggerDetail = TriggerSignal;

/**
 * The slice of the render layer the element drives. Narrow on purpose — `SceneRenderer`
 * satisfies it structurally, and a test can satisfy it without three or a GPU.
 */
export interface SceneSurface extends PreloadTarget {
  apply(state: SceneState): void;
  render(): void;
  resize(width: number, height: number): void;
  dispose(): void;
  readonly debug: SceneRendererDebug;
  /**
   * Screen-space projection and picking (C9). Optional so a minimal surface stays
   * valid: without them a `follow` event simply carries no screen point, and only
   * whole-canvas triggers can fire.
   */
  project?(world: Vec3): ScreenPoint;
  hitTest?(x: number, y: number): PickResult | null;
  /** A track's composed world position (pose ∘ `transform`) — what `follow` reports. */
  trackWorldPosition?(id: string): Vec3 | null;
  /** Verification-only (the `debug` attribute's dev tools); absent on stubs. */
  readPixels?(x: number, y: number, w?: number, h?: number): Uint8Array;
  getContext?(): WebGLRenderingContext | WebGL2RenderingContext;
}

/** The slice of `TriggerController` the element drives (C9). */
export interface TriggerControllerLike {
  destroy(): void;
  readonly debug: TriggerControllerDebug;
}

/**
 * A `Driver` plus the extras the element uses when the implementation has them — every
 * one optional, so a driver only implements what its modality actually means.
 *
 * `pausable` is the capability that makes the element show its pause control: a driver
 * that advances without the user (D1's time driver, and anything like it later) sets it
 * and inherits the SC 2.2.2 mechanism (`docs/a11y.md` §3). `scrubbable` (D3) is the same
 * idea for the other direction: a driver whose input no keyboard can produce says so, and
 * inherits the range control that makes it operable anyway.
 */
export type ElementDriver = Driver & {
  /** Re-measure on the next frame (scroll-like drivers). */
  invalidate?(): void;
  /** True ⟹ this driver moves on its own and MUST be pausable by the user. */
  readonly pausable?: boolean;
  /**
   * True ⟹ this driver's input is pointer-only, so the player owes it a keyboard-operable
   * control (SC 2.1.1). Requires `seek`.
   */
  readonly scrubbable?: boolean;
  /** Jump to a position, t ∈ [0..1] — what the scrub control drives. */
  seek?(t: number): void;
  /**
   * Take a t from the host (E1b's `external` kind — the only driver whose input arrives
   * through the element rather than from the DOM). `discontinuity` marks a jump.
   */
  setT?(t: number, discontinuity?: boolean): void;
  readonly paused?: boolean;
  /** A finite timeline that has run out — `play()` starts it over. */
  readonly ended?: boolean;
  play?(): void;
  pause?(): void;
  /** Environment gate: the element sets it while nothing can be seen. */
  suspend?(suspended: boolean): void;
  /**
   * A driver that watches the viewport itself (D2's view driver) — the element never
   * calls this in the browser (the driver's own observer does), but `dev().setInView()`
   * does, because a hidden tab delivers no IntersectionObserver callbacks at all.
   */
  enterView?(inView: boolean): void;
  readonly debug?: unknown;
};

/** The slice of `ScenePreloader` the element drives. */
export interface ScenePreloaderLike {
  startWhenNear(target: Element, options?: { rootMargin?: string }): Promise<void>;
  start(): Promise<void>;
  destroy(): void;
  readonly phase: PreloadPhase;
  readonly progress: number;
  readonly debug: ScenePreloaderDebug;
}

/**
 * The element's window seam. Injectable so the element is deterministic in node tests
 * (no three, no GPU, no network) and drivable in a hidden tab. Not a public extension
 * point — the public contract is the attributes and the events.
 */
export interface VertieSceneEnv {
  fetchScene(url: string, signal: AbortSignal): Promise<unknown>;
  createSurface(canvas: HTMLCanvasElement, options: SceneRendererOptions): SceneSurface;
  /** Build the driver the `driver` attribute asked for (D1's registry resolves the kind). */
  createDriver(spec: DriverSpec, target: Element): ElementDriver;
  createPreloader(target: PreloadTarget, scene: Scene, options: ScenePreloaderOptions): ScenePreloaderLike;
  /** Input triggers (§11). Built only for a scene that declares some. */
  createTriggers(options: TriggerControllerOptions): TriggerControllerLike;
  /** Watch the canvas box; returns a teardown. */
  observeResize(target: Element, onResize: () => void): () => void;
  /**
   * Can this browser run the renderer at all (ADR-007 floor: WebGL2)? Asked BEFORE the
   * scene is fetched, so an unsupported browser downloads nothing.
   */
  supportsWebGL2(): boolean;
  /** Does the user ask for reduced motion right now? */
  prefersReducedMotion(): boolean;
  /**
   * Watch the reduced-motion preference. Reported on change only (the current value is
   * read with `prefersReducedMotion`); returns a teardown.
   */
  observeReducedMotion(onChange: (reduced: boolean) => void): () => void;
  /** Watch whether the region is on screen. Reports the current state on install. */
  observeInView(target: Element, onChange: (inView: boolean) => void): () => void;
  /** Watch page visibility (tab switch, minimize). Reports the current state on install. */
  observePageVisible(onChange: (visible: boolean) => void): () => void;
  /**
   * Schedule the deferred teardown and return its canceller. Deferred because a
   * disconnect is not always a death: moving an element in the DOM (or React 18's
   * StrictMode double-mount) disconnects and reconnects it within the same task, and
   * tearing the GPU down in between would throw the scene away for nothing.
   */
  deferTeardown(fn: () => void): () => void;
}

/** Plain snapshot for the `window.__vertie` no-screenshot verification channel. */
export interface VertieSceneDebug {
  version: string;
  src: string | null;
  /** Resolved scene document URL — also the default base for relative asset paths. */
  sceneUrl: string | null;
  assetBase: string | null;
  driverKind: string;
  /** Whether the scroll region is the element itself or an outer element (`region` attribute). */
  regionIsSelf: boolean;
  ready: boolean;
  t: number;
  lints: number;
  /** The settled presentation — mirrors the reflected `state` attribute. */
  state: VertieState;
  /** Which rung of the fallback ladder, or null on the normal animated path (C6). */
  fallback: VertieFallbackDetail | null;
  reducedMotion: boolean;
  webgl2: boolean;
  /** False while rendering is paused (region off screen, or the page is hidden). */
  rendering: boolean;
  error: string | null;
  errorPhase: VertieErrorPhase | null;
  preload: ScenePreloaderDebug | null;
  renderer: SceneRendererDebug | null;
  driver: unknown;
  /** Timeline events (§10): which windows are open, and how many signals have gone out. */
  events: { declared: number; active: string[]; fired: number };
  /** Input triggers (§11), or null for a scene that declares none. */
  triggers: TriggerControllerDebug | null;
}

/** Dev-only helpers, present only while the `debug` attribute is set. */
export interface VertieSceneDevTools {
  /** Open the preload gate by hand — IntersectionObserver delivers nothing in a hidden tab. */
  fireGate(): boolean;
  /** Render at an explicit t without touching the driver (scrubbing / golden checks). */
  setT(t: number): void;
  /** Pure evaluation at t — cross-checks the renderer against the math. */
  evalAt(t: number): SceneState | null;
  /**
   * Re-fit the canvas to its current box and redraw. Normally the `ResizeObserver`
   * does this; a hidden tab delivers no observer callbacks (and no rAF), so pixel
   * readback needs a way to say "the box changed, catch up".
   */
  resize(): void;
  /**
   * Drive the offscreen-pause path by hand: a hidden preview tab delivers no
   * IntersectionObserver callbacks, so this is the only way to exercise it there.
   */
  setInView(inView: boolean): void;
  readPixels(x: number, y: number, w?: number, h?: number): Uint8Array | null;
  /** Non-transparent device pixels in the drawing buffer — "did it actually paint?". */
  paintedPixels(): number;
  /**
   * Raycast the rendered scene at a canvas-box point (CSS pixels) — the same call a
   * trigger makes, exposed so a hidden tab can verify picking without synthesizing
   * pointer events.
   */
  hitTest(x: number, y: number): PickResult | null;
  /** Where a track is on screen right now (canvas-box CSS pixels) — the `follow` math. */
  project(trackId: string): ScreenPoint | null;
}

/**
 * aria-hidden: the canvas carries no semantics of its own — whatever the scene *means* is
 * the page's light-DOM text, which stays in the a11y tree through the slot. No `tabindex`
 * either: there is nothing inside it to operate.
 */
function makeCanvas(): HTMLCanvasElement {
  const canvas = document.createElement("canvas");
  canvas.setAttribute("part", "canvas");
  canvas.setAttribute("aria-hidden", "true");
  return canvas;
}

const SVG_NS = "http://www.w3.org/2000/svg";

function svgNode(tag: string, attrs: Record<string, string>): SVGElement {
  const node = document.createElementNS(SVG_NS, tag);
  for (const [name, value] of Object.entries(attrs)) node.setAttribute(name, value);
  return node;
}

/**
 * The keyboard route into a pointer-scrubbed scene (D3, `docs/a11y.md` §3). A native
 * `<input type="range">` rather than anything of our own: it is in the tab order, moves
 * with the arrow keys / Home / End / PageUp / PageDown, announces itself as a slider with
 * a value, and — the part a keyboard-only fix would miss — it is operable by a single tap
 * on its track, which is WCAG 2.2 SC 2.5.7's non-dragging alternative.
 *
 * The value is a whole percentage: one arrow press = 1 % of the timeline, which is a
 * usable step on a scene of any length, and screen readers announce it as a plain number
 * (`aria-valuetext` adds the unit).
 */
function makeScrubber(): HTMLInputElement {
  const input = document.createElement("input");
  input.type = "range";
  input.className = "scrub";
  input.setAttribute("part", "scrub");
  input.min = "0";
  input.max = "100";
  input.step = "1";
  input.value = "0";
  input.setAttribute("aria-label", "Scene position");
  input.setAttribute("aria-valuetext", "0%");
  input.hidden = true;
  return input;
}

/**
 * The pause control required by WCAG 2.2 SC 2.2.2 for any driver that starts on its own
 * (`docs/a11y.md` §3). A real `<button>`, so it is in the tab order, operable with Enter
 * and Space, and announced as a button — none of which a styled `<div>` would give us.
 *
 * The accessible name is the *action*, swapped with the state ("Pause"/"Play"), which is
 * the pattern media players use; `aria-pressed` is deliberately avoided (this is not a
 * toggle whose state a user tracks, it is a button whose job changes). The icons are
 * built with the SVG DOM rather than `innerHTML` — the element stays CSP-friendly with
 * no Trusted Types opt-out, like the rest of the shadow root.
 */
function makePauseButton(): HTMLButtonElement {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "pause";
  button.setAttribute("part", "pause");
  button.hidden = true;

  const icon = svgNode("svg", { viewBox: "0 0 16 16", "aria-hidden": "true", focusable: "false" });
  const pause = svgNode("g", { class: "icon-pause" });
  pause.append(
    svgNode("rect", { x: "4", y: "3", width: "3", height: "10", rx: "1" }),
    svgNode("rect", { x: "9", y: "3", width: "3", height: "10", rx: "1" }),
  );
  const play = svgNode("g", { class: "icon-play" });
  play.append(svgNode("path", { d: "M5 3.5 12.5 8 5 12.5Z" }));
  icon.append(pause, play);
  button.append(icon);
  return button;
}

function asError(err: unknown): Error {
  return err instanceof Error ? err : new Error(String(err));
}

function isAbortError(err: unknown): boolean {
  return err instanceof Error && err.name === "AbortError";
}

export function defaultSceneEnv(): VertieSceneEnv {
  return {
    async fetchScene(url, signal) {
      const res = await fetch(url, { signal });
      if (!res.ok) throw new Error(`vertie: scene fetch failed (${res.status} ${res.statusText}) — ${url}`);
      return (await res.json()) as unknown;
    },
    createSurface: (canvas, options) => new SceneRenderer(canvas, options),
    createDriver: (spec, target) => createDriver(spec, target),
    createPreloader: (target, scene, options) => new ScenePreloader(target, scene, options),
    createTriggers: (options) => new TriggerController(options),
    observeResize(target, onResize) {
      if (typeof ResizeObserver !== "function") return () => {};
      const observer = new ResizeObserver(onResize);
      observer.observe(target);
      return () => observer.disconnect();
    },
    supportsWebGL2() {
      // The cheap check first — no context is created if the constructor is missing.
      if (typeof WebGL2RenderingContext === "undefined" || typeof document === "undefined") return false;
      try {
        // Probe on a throwaway canvas, never on ours: a canvas hands out ONE context, and
        // a context created here would make three's own `getContext` call return this one
        // with THIS one's attributes — silently dropping antialias/alpha/preserveDrawingBuffer.
        const probe = document.createElement("canvas");
        const gl = probe.getContext("webgl2");
        if (!gl) return false;
        // Contexts are a scarce per-page resource; give this one straight back.
        gl.getExtension("WEBGL_lose_context")?.loseContext();
        return true;
      } catch {
        return false;
      }
    },
    prefersReducedMotion: () =>
      typeof matchMedia === "function" && matchMedia(REDUCED_MOTION_QUERY).matches,
    observeReducedMotion(onChange) {
      if (typeof matchMedia !== "function") return () => {};
      const query = matchMedia(REDUCED_MOTION_QUERY);
      const handler = (event: MediaQueryListEvent): void => onChange(event.matches);
      query.addEventListener("change", handler);
      return () => query.removeEventListener("change", handler);
    },
    observeInView(target, onChange) {
      // No observer (old browser, jsdom) = assume visible; pausing something we cannot
      // see the state of would be worse than rendering a frame nobody watches.
      if (typeof IntersectionObserver !== "function") return () => {};
      const observer = new IntersectionObserver(
        (entries) => {
          const entry = entries.at(-1);
          if (entry) onChange(entry.isIntersecting);
        },
        { rootMargin: "0px", threshold: 0 },
      );
      observer.observe(target); // fires once with the current state
      return () => observer.disconnect();
    },
    observePageVisible(onChange) {
      if (typeof document === "undefined") return () => {};
      const handler = (): void => onChange(!document.hidden);
      document.addEventListener("visibilitychange", handler);
      handler();
      return () => document.removeEventListener("visibilitychange", handler);
    },
    deferTeardown(fn) {
      // A macrotask, not a microtask: a re-parenting host must get its connectedCallback
      // in before the teardown runs, and that lands on the next task.
      const handle = setTimeout(fn, 0);
      return () => clearTimeout(handle);
    },
  };
}

/**
 * Shadow DOM: a sticky viewport holding the canvas and the poster, then the `<slot>` for
 * the page's own content. Built imperatively rather than with `innerHTML` so the element
 * stays CSP-friendly (no HTML parsing of a string, no Trusted Types opt-out).
 *
 * Sizing is declared in `:host`, which loses to any page rule — so the default makes the
 * one-line embed work and the author overrides it with plain CSS (or the two custom
 * properties) without a specificity fight.
 */
const SHADOW_CSS = `
:host {
  display: block;
  position: relative;
  height: var(--vertie-height, 300vh);
}
:host([hidden]) { display: none; }
/* A pointer-scrubbed scene (D3) is a picture, not a scroll track: it needs no travel, so
   it defaults to one viewport tall instead of three. touch-action keeps the page's own
   gesture — a scrub along one axis leaves panning along the other to the browser. */
:host([driver="pointer"]) {
  height: var(--vertie-height, var(--vertie-viewport-height, 100vh));
  touch-action: pan-y;
}
:host([driver="pointer"][axis="y"]) { touch-action: pan-x; }
.viewport {
  position: sticky;
  top: 0;
  height: var(--vertie-viewport-height, 100vh);
  overflow: hidden;
}
canvas, .poster {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  display: block;
}
/* Never hijack the scroll: vertical gestures belong to the page (a11y, C6). */
canvas { touch-action: pan-y; }
/* The SC 2.2.2 control (D1) — present only while a driver that moves on its own is
   live. Deliberately unstyled-ish and self-contained: a page restyles it through
   ::part(pause), and forced-colors mode gets system colours rather than our own. */
.pause {
  position: absolute;
  right: 1rem;
  bottom: 1rem;
  inline-size: 2.5rem;
  block-size: 2.5rem;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  border: 1px solid rgba(255, 255, 255, 0.4);
  border-radius: 50%;
  background: rgba(0, 0, 0, 0.55);
  color: #fff;
  cursor: pointer;
}
.pause svg { inline-size: 1rem; block-size: 1rem; fill: currentColor; }
.pause .icon-play { display: none; }
.pause[data-paused="true"] .icon-play { display: block; }
.pause[data-paused="true"] .icon-pause { display: none; }
@media (forced-colors: active) {
  .pause { background: ButtonFace; color: ButtonText; border-color: ButtonBorder; }
}
/* The scrub control (D3) — shown only for a driver whose input is pointer-only. Visible
   rather than visually-hidden-until-focus: it is the affordance that tells everyone the
   scene can be moved, and a page restyles or repositions it through ::part(scrub). */
.scrub {
  position: absolute;
  left: 50%;
  bottom: 1rem;
  transform: translateX(-50%);
  inline-size: min(60%, 20rem);
  accent-color: #fff;
  cursor: pointer;
}
@media (forced-colors: active) { .scrub { accent-color: Highlight; } }
/* Neither the canvas nor the poster may swallow a click meant for the page's own
   links and buttons — authors overlay real light-DOM controls on top of the scene, and
   those must stay operable. C9's triggers listen on the host and raycast from there. */
canvas, .poster { pointer-events: none; }
.poster { object-fit: cover; }
[hidden] { display: none; }
`;

/**
 * Apply the shadow-root stylesheet in a CSP-safe way. A `<style>` element is
 * inline CSS: a hardened `style-src` with no `'unsafe-inline'` blocks it, and the
 * canvas — which the stylesheet stretches to fill the viewport — then collapses to
 * its intrinsic 300×150 in the corner (a real bug found on a site whose CSP is
 * `style-src 'self'`). A *constructable* stylesheet adopted onto the root is not
 * "inline" and is exempt from `style-src`, so it applies under a strict CSP. Fall
 * back to a `<style>` element where constructable sheets are unavailable — older
 * engines, which are not the ones enforcing a modern strict CSP.
 */
function applyShadowStyle(root: ShadowRoot): void {
  try {
    if (
      typeof CSSStyleSheet === "function" &&
      "replaceSync" in CSSStyleSheet.prototype &&
      "adoptedStyleSheets" in root
    ) {
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(SHADOW_CSS);
      root.adoptedStyleSheets = [...root.adoptedStyleSheets, sheet];
      return;
    }
  } catch {
    // Constructable stylesheets unsupported or disallowed — use the element below.
  }
  const style = document.createElement("style");
  style.textContent = SHADOW_CSS;
  root.append(style);
}

export class VertieSceneElement extends HTMLElement {
  static readonly observedAttributes = [
    "src",
    "assets",
    "driver",
    "poster",
    "region",
    "damping",
    "offset-start",
    "offset-end",
    "duration",
    "loop",
    "paused",
    "threshold",
    "replay",
    "axis",
    "drag",
    "frustum-clamp",
    "debug",
  ];

  /** Test/hidden-tab seam — assign before the element connects. Not a public extension point. */
  __env?: Partial<VertieSceneEnv>;

  private canvas: HTMLCanvasElement;
  private readonly posterEl: HTMLImageElement;
  private readonly pauseButton: HTMLButtonElement;
  private readonly scrubber: HTMLInputElement;
  private readonly viewport: HTMLDivElement;
  /** True once a WebGL context has been handed out for the current canvas node. */
  private canvasSpent = false;

  private env: VertieSceneEnv = defaultSceneEnv();

  /** Bumped by every start and every teardown — an in-flight start checks it after each await. */
  private generation = 0;
  private started = false;
  private readyFlag = false;
  private currentT = 0;
  private lintCount = 0;
  private sceneUrl: string | null = null;
  private assetBase: string | null = null;
  private errorMessage: string | null = null;
  private errorPhaseValue: VertieErrorPhase | null = null;
  private regionIsSelf = true;
  /** Resolved once per run, so reading `debug` never re-warns about an unknown kind. */
  private driverKindValue: DriverKind = "scroll";
  /** What the pause control currently shows — so a per-frame sync touches no DOM. */
  private pauseShownAs: boolean | null = null;
  /** Guard: reflecting `paused` must not be read back as an author changing it. */
  private syncingPaused = false;
  /** The scrub control sits over the scene: while the pointer is on it, it is not on the scene. */
  private scrubHover = false;
  private scrubHeld = false;
  /**
   * The last t the HOST pushed (`driver="external"`). Kept on the element, not only in the
   * driver, because it has to outlive both of the moments the driver does not exist: before
   * the scene is ready, and across a driver rebuild.
   */
  private externalT: number | null = null;
  /** Warn once, not once per frame — a host that pushes t drives at frame rate. */
  private warnedExternalT = false;

  private stateValue: VertieState = "loading";
  private fallbackInfo: VertieFallbackDetail | null = null;
  /** What `prefersReducedMotion()` said when this run started — a live change re-runs it. */
  private reducedUsed = false;
  private webgl2 = true;
  /** Rendering pauses while either is false; a frame owed from that time is remembered. */
  private inView = true;
  private pageVisible = true;
  private pendingFrame = false;

  private controller: AbortController | null = null;
  private surface: SceneSurface | null = null;
  private driverInstance: ElementDriver | null = null;
  private preloader: ScenePreloaderLike | null = null;
  private compiled: CompiledScene | null = null;
  private sceneState: SceneState | null = null;
  private sceneDoc: Scene | null = null;
  private compiledEvents: CompiledEvent[] = [];
  private eventTracker: EventTracker | null = null;
  private eventsFired = 0;
  private triggerController: TriggerControllerLike | null = null;
  /** False until `vertie-ready` has gone out; signals produced before that wait here. */
  private eventsAnnounced = false;
  private readonly pendingEvents: VertieEventDetail[] = [];

  private unsubscribe: (() => void) | null = null;
  private unobserveResize: (() => void) | null = null;
  private unobserveMotion: (() => void) | null = null;
  private unobserveInView: (() => void) | null = null;
  private unobservePageVisible: (() => void) | null = null;
  private cancelTeardown: (() => void) | null = null;
  private fireGateFn: (() => void) | null = null;

  constructor() {
    super();
    const root = this.attachShadow({ mode: "open" });
    applyShadowStyle(root);

    const viewport = document.createElement("div");
    viewport.className = "viewport";
    viewport.setAttribute("part", "viewport");

    this.viewport = viewport;
    this.canvas = makeCanvas();

    this.posterEl = document.createElement("img");
    this.posterEl.className = "poster";
    this.posterEl.setAttribute("part", "poster");
    this.posterEl.setAttribute("alt", "");
    this.posterEl.setAttribute("aria-hidden", "true");
    this.posterEl.hidden = true;

    this.pauseButton = makePauseButton();
    this.pauseButton.addEventListener("click", () => this.setPaused(!this.driverStopped()));

    this.scrubber = makeScrubber();
    this.scrubber.addEventListener("input", () => this.onScrubInput());
    // The control is a child of the host, so every pointer event over it also reaches the
    // pointer driver listening there (shadow retargeting makes them indistinguishable by
    // target). These four flags are how the driver is told "this one is mine".
    this.scrubber.addEventListener("pointerenter", () => {
      this.scrubHover = true;
    });
    this.scrubber.addEventListener("pointerleave", () => {
      this.scrubHover = false;
    });
    this.scrubber.addEventListener("pointerdown", () => {
      this.scrubHeld = true;
    });
    for (const type of ["pointerup", "pointercancel", "change"]) {
      // `change` is the belt to the braces: a drag that ends off the control still fires
      // it, so the scene can never be left permanently deaf to the pointer.
      this.scrubber.addEventListener(type, () => {
        this.scrubHeld = false;
      });
    }

    viewport.append(this.canvas, this.posterEl, this.pauseButton, this.scrubber);
    root.append(viewport, document.createElement("slot"));
  }

  // ---------------------------------------------------------------- attributes (contract)

  get src(): string | null {
    return this.getAttribute("src");
  }
  set src(value: string | null) {
    this.reflect("src", value);
  }

  get assets(): string | null {
    return this.getAttribute("assets");
  }
  set assets(value: string | null) {
    this.reflect("assets", value);
  }

  get driver(): string | null {
    return this.getAttribute("driver");
  }
  set driver(value: string | null) {
    this.reflect("driver", value);
  }

  get poster(): string | null {
    return this.getAttribute("poster");
  }
  set poster(value: string | null) {
    this.reflect("poster", value);
  }

  get region(): string | null {
    return this.getAttribute("region");
  }
  set region(value: string | null) {
    this.reflect("region", value);
  }

  get damping(): number | null {
    return this.numberAttr("damping");
  }
  set damping(value: number | null) {
    this.reflect("damping", value === null ? null : String(value));
  }

  /**
   * The §9 data-aware clamp (ADR-017's optional runtime policy). `true` = clamp the
   * authored keys to the frustum edge, a number in (0..1] = the fraction of the
   * half-frustum a key may occupy, `false`/absent = off (the default: it changes framing).
   */
  get frustumClamp(): boolean | number {
    return this.frustumClampOption() ?? false;
  }
  set frustumClamp(value: boolean | number) {
    this.reflect("frustum-clamp", value === false ? null : value === true ? "" : String(value));
  }

  get offsetStart(): number | null {
    return this.numberAttr("offset-start");
  }
  set offsetStart(value: number | null) {
    this.reflect("offset-start", value === null ? null : String(value));
  }

  get offsetEnd(): number | null {
    return this.numberAttr("offset-end");
  }
  set offsetEnd(value: number | null) {
    this.reflect("offset-end", value === null ? null : String(value));
  }

  /**
   * Wall-clock length of one pass, in **seconds** (`driver="time"` only). Default: the
   * scene's own `duration` (§2) read as seconds — the unit authors overwhelmingly mean.
   * The scene's timeline is unitless (§6), so this is where those units get a rate.
   */
  get duration(): number | null {
    return this.numberAttr("duration");
  }
  set duration(value: number | null) {
    this.reflect("duration", value === null ? null : String(value));
  }

  /**
   * Which way across the scene the pointer scrubs (`driver="pointer"`): `"x"` (default)
   * or `"y"`. An unrecognized value warns and falls back to `"x"`.
   */
  get axis(): string | null {
    return this.getAttribute("axis");
  }
  set axis(value: string | null) {
    this.reflect("axis", value);
  }

  /**
   * Require a held pointer (`driver="pointer"`): nothing moves on hover, a press
   * positions the timeline and a drag scrubs it. Touch behaves this way regardless — it
   * has no hover to lose.
   */
  get drag(): boolean {
    return this.hasAttribute("drag");
  }
  set drag(value: boolean) {
    this.reflect("drag", value ? "" : null);
  }

  /** Restart from the beginning instead of stopping at the end (`driver="time"`). */
  get loop(): boolean {
    return this.hasAttribute("loop");
  }
  set loop(value: boolean) {
    this.reflect("loop", value ? "" : null);
  }

  /**
   * Playback state of a self-advancing driver. Present as an attribute at load time it
   * means "start stopped"; afterwards the element keeps it in sync with the real state,
   * so `vertie-scene[paused] .caption { … }` works with no JS. A driver that cannot move
   * on its own (scroll) reports `true`: there is nothing playing.
   */
  get paused(): boolean {
    const driver = this.driverInstance;
    if (!driver?.pausable) return true;
    return this.driverStopped();
  }
  set paused(value: boolean) {
    if (value) this.pause();
    else this.play();
  }

  /** Start (or resume) a self-advancing driver; at the end of a run, start it over. */
  play(): void {
    this.setPaused(false);
  }

  /** Stop a self-advancing driver where it stands (the SC 2.2.2 mechanism, in JS form). */
  pause(): void {
    this.setPaused(true);
  }

  /**
   * Current progress t ∈ [0..1] — where the timeline stands, whatever drives it.
   *
   * Writable only under `driver="external"` (E1b), where the HOST owns t: assign it once
   * per frame from your own loop and the scene follows. Not to be confused with
   * `vertie-progress`, which reports LOADING progress.
   */
  get t(): number {
    return this.currentT;
  }
  set t(value: number) {
    this.setT(value);
  }

  /**
   * The full form of `t =`: `discontinuity` says this value does not continue the last
   * one (a chapter teleport, a nav jump), so §10 event windows are re-seeded instead of
   * being replayed backwards across everything the host skipped.
   *
   * A value pushed before the scene is ready is remembered, not lost — the driver opens
   * on it, so a page that jumped mid-load never shows one frame of t = 0 first.
   */
  setT(t: number, options?: { discontinuity?: boolean }): void {
    // The ATTRIBUTE, not the resolved kind: a host may set t before the element has ever
    // started, and `resolveDriverKind` would warn about an unknown name on every push.
    if (this.getAttribute("driver") !== "external") {
      if (!this.warnedExternalT) {
        this.warnedExternalT = true;
        console.warn(
          `vertie: setting t is ignored — this element is driven by "${this.driverKindValue}"; ` +
            `use driver="external" to own the timeline from the host`,
        );
      }
      return;
    }
    this.externalT = t;
    this.driverInstance?.setT?.(t, options?.discontinuity ?? false);
  }

  // ---------------------------------------------------------------- read-only state

  /** The validated scene document, once fetched. */
  get scene(): Scene | null {
    return this.sceneDoc;
  }

  /** True once the scene is loaded, warmed and drawing. */
  get ready(): boolean {
    return this.readyFlag;
  }

  /** The settled presentation (also the reflected `state` attribute). */
  get state(): VertieState {
    return this.stateValue;
  }

  /** Which fallback rung the element settled on, or null on the normal animated path. */
  get fallback(): VertieFallbackDetail | null {
    return this.fallbackInfo;
  }

  /** Plain snapshot for `window.__vertie` — the no-screenshot verification channel. */
  get debug(): VertieSceneDebug {
    return {
      version: VERTIE_VERSION,
      src: this.getAttribute("src"),
      sceneUrl: this.sceneUrl,
      assetBase: this.assetBase,
      driverKind: this.driverKindValue,
      regionIsSelf: this.regionIsSelf,
      ready: this.readyFlag,
      t: this.currentT,
      lints: this.lintCount,
      state: this.stateValue,
      fallback: this.fallbackInfo,
      reducedMotion: this.reducedUsed,
      webgl2: this.webgl2,
      rendering: this.inView && this.pageVisible,
      error: this.errorMessage,
      errorPhase: this.errorPhaseValue,
      preload: this.preloader?.debug ?? null,
      renderer: this.surface?.debug ?? null,
      driver: this.driverInstance?.debug ?? null,
      events: {
        declared: this.compiledEvents.length,
        active: this.eventTracker?.activeNames ?? [],
        fired: this.eventsFired,
      },
      triggers: this.triggerController?.debug ?? null,
    };
  }

  /** Dev tools — only while the `debug` attribute is set (it also keeps the drawing buffer readable). */
  get devTools(): VertieSceneDevTools | null {
    if (!this.hasAttribute("debug")) return null;
    return {
      fireGate: () => {
        if (!this.fireGateFn) return false;
        this.fireGateFn();
        return true;
      },
      setT: (t) => {
        this.currentT = t;
        // Forced: the verification channel must draw even where the offscreen pause says
        // no — the preview pane reports `document.hidden` for its whole life.
        this.renderFrame(t, true);
      },
      evalAt: (t) => {
        if (!this.compiled) return null;
        const state = createSceneState(this.compiled);
        evaluate(this.compiled, t, state);
        return state;
      },
      resize: () => this.onResize(true),
      setInView: (inView) => {
        this.setInView(inView);
        // A view driver runs its OWN observer, which is just as dead in a hidden tab as
        // the element's. Only the dev handle drives both — in a real browser the two
        // observers are independent on purpose (they have different thresholds).
        this.driverInstance?.enterView?.(inView);
      },
      readPixels: (x, y, w, h) => this.surface?.readPixels?.(x, y, w, h) ?? null,
      paintedPixels: () => {
        const gl = this.surface?.getContext?.();
        if (!gl || !this.surface?.readPixels) return -1;
        const px = this.surface.readPixels(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight);
        let painted = 0;
        for (let i = 3; i < px.length; i += 4) if ((px[i] ?? 0) > 0) painted++;
        return painted;
      },
      hitTest: (x, y) => this.surface?.hitTest?.(x, y) ?? null,
      project: (trackId) => {
        const position = this.trackPosition(trackId);
        if (!position || !this.surface?.project) return null;
        return this.surface.project(position);
      },
    };
  }

  // ---------------------------------------------------------------- lifecycle

  connectedCallback(): void {
    this.env = { ...defaultSceneEnv(), ...this.__env };

    // Re-parented (or React StrictMode remount): the teardown scheduled by the matching
    // disconnect has not run yet, so cancel it and keep the live scene.
    if (this.cancelTeardown) {
      this.cancelTeardown();
      this.cancelTeardown = null;
    }

    registerElement(this);
    if (this.started) return;
    this.started = true;
    void this.start();
  }

  disconnectedCallback(): void {
    if (this.cancelTeardown) return;
    this.cancelTeardown = this.env.deferTeardown(() => {
      this.cancelTeardown = null;
      if (this.isConnected) return;
      this.teardown();
    });
  }

  attributeChangedCallback(name: string, previous: string | null, next: string | null): void {
    if (previous === next) return;
    if (name === "poster") {
      this.applyPoster();
      // Under reduced motion the poster IS the rung: gaining one means we can stop
      // rendering the scene, losing one means we owe the user a static frame instead.
      if (this.started && this.reducedUsed) this.restart();
      return;
    }
    // Everything else is read fresh by start(); before that there is nothing to redo.
    if (!this.started) return;

    // Playback state, not configuration: an author setting `paused` must stop the driver
    // where it stands, never rebuild it (that would throw the position away). Our own
    // reflection lands here too — the guard keeps it from bouncing back.
    if (name === "paused") {
      if (!this.syncingPaused) this.setPaused(next !== null);
      return;
    }

    // Driver configuration is constructor-only on the driver, so it takes a new driver —
    // but not a new download: rebuilding the whole scene for a damping tweak would be
    // absurd (and the playground/authoring UIs will tweak exactly these live).
    if (
      name === "damping" ||
      name === "offset-start" ||
      name === "offset-end" ||
      name === "duration" ||
      name === "loop" ||
      name === "threshold" ||
      name === "replay" ||
      name === "axis" ||
      name === "drag"
    ) {
      this.rebuildDriver();
      return;
    }
    this.restart();
  }

  // ---------------------------------------------------------------- the run

  private async start(): Promise<void> {
    const gen = ++this.generation;
    this.readyFlag = false;
    this.errorMessage = null;
    this.errorPhaseValue = null;
    this.fallbackInfo = null;
    this.pendingFrame = false;
    this.eventsAnnounced = false;
    this.pendingEvents.length = 0;
    this.eventsFired = 0;
    this.canvas.hidden = false;
    this.setState("loading");
    this.applyPoster();
    this.hidePauseControl();
    this.hideScrubControl();
    // Resolved once per run: `debug` and the spec both read it, and an unknown kind must
    // warn once rather than on every debug snapshot.
    this.driverKindValue = resolveDriverKind(this.getAttribute("driver"));

    // The preference can change mid-session (the OS toggle, or a browser devtools
    // emulation); MDN's SCR40 pattern is to listen, not only to sample once.
    this.unobserveMotion = this.env.observeReducedMotion((reduced) => this.onReducedMotionChange(reduced));

    const src = this.getAttribute("src");
    if (!src) {
      this.fail(new Error("vertie: <vertie-scene> requires a `src` attribute"), "config");
      return;
    }

    // ------------------------------------------------ the fallback ladder (C6)
    // Decided BEFORE anything is fetched: a browser that cannot render, or a user who
    // asked for no motion and gave us a poster, must not pay for a single asset byte.
    this.reducedUsed = this.env.prefersReducedMotion();
    this.webgl2 = this.env.supportsWebGL2();
    const hasPoster = this.hasAttribute("poster");

    if (!this.webgl2) {
      // Not an error: an old browser showing the poster (or the page's own text) is the
      // ladder working as designed. `vertie-error` stays for things that are wrong.
      this.settleWithoutRendering("no-webgl2", hasPoster ? "poster" : "text");
      return;
    }
    if (this.reducedUsed && hasPoster) {
      this.settleWithoutRendering("reduced-motion", "poster");
      return;
    }
    // Reduced motion without a poster still shows the scene — as exactly one frame.
    const staticFrame = this.reducedUsed;

    let sceneUrl: string;
    try {
      sceneUrl = new URL(src, this.baseURI).href;
    } catch {
      this.fail(new Error(`vertie: invalid src URL — ${src}`), "config");
      return;
    }
    this.sceneUrl = sceneUrl;

    const controller = new AbortController();
    this.controller = controller;

    let document_: unknown;
    try {
      document_ = await this.env.fetchScene(sceneUrl, controller.signal);
    } catch (err) {
      if (gen === this.generation) this.failUnlessAborted(err, "fetch");
      return;
    }
    if (gen !== this.generation) return;

    const scene = document_ as Scene;
    const result = validateScene(scene);
    if (!result.valid) {
      const codes = result.errors.map((issue) => issue.code).join(", ");
      this.fail(new Error(`vertie: invalid scene (${codes}) — ${sceneUrl}`), "validate");
      return;
    }
    this.sceneDoc = scene;
    this.lintCount = result.lints.length;
    this.compiled = compileScene(scene);
    this.sceneState = createSceneState(this.compiled);
    this.compiledEvents = compileEvents(scene);
    this.eventTracker = this.compiledEvents.length > 0 ? new EventTracker(this.compiledEvents) : null;

    // Relative asset paths resolve against the SCENE document (spec §14.1, RFC 3986) —
    // not against the host page, which is what a naive default would do and would break
    // the moment a scene is hosted somewhere other than the embedding page.
    const assets = this.getAttribute("assets");
    let assetBase = sceneUrl;
    if (assets) {
      try {
        assetBase = new URL(assets, this.baseURI).href;
      } catch {
        this.fail(new Error(`vertie: invalid assets URL — ${assets}`), "config");
        return;
      }
    }
    this.assetBase = assetBase;

    // A canvas hands out ONE WebGL context for its whole life: once three's `dispose()`
    // has called `forceContextLoss()`, `getContext("webgl2")` on that element returns
    // null forever and the next renderer constructs against nothing. So a rebuild gets a
    // fresh node. (Found live in C6: toggling the reduced-motion preference twice is a
    // restart, and it killed the scene with "Cannot read properties of null".)
    if (this.canvasSpent) this.renewCanvas();
    this.canvasSpent = true;

    try {
      const frustumClamp = this.frustumClampOption();
      this.surface = this.env.createSurface(this.canvas, {
        baseUrl: assetBase,
        preserveDrawingBuffer: this.hasAttribute("debug"),
        ...(frustumClamp === undefined ? {} : { frustumClamp }),
      });
    } catch (err) {
      // A browser WITHOUT WebGL2 never reaches this line (the ladder caught it above), so
      // a throw here is a real failure — a lost context, an exhausted GPU, a broken driver.
      this.fail(asError(err), "load");
      return;
    }
    this.fitCanvas();
    this.unobserveResize = this.env.observeResize(this.canvas, () => this.onResize());

    const region = this.regionElement();

    // Pause rendering whenever the scene cannot be seen — off screen, or in a background
    // tab. Both report their current state as they are installed.
    this.unobserveInView = this.env.observeInView(region, (inView) => this.setInView(inView));
    this.unobservePageVisible = this.env.observePageVisible((visible) => {
      this.pageVisible = visible;
      this.updateDriverSuspension();
      this.resumeIfOwed();
    });

    // The driver is constructed BEFORE the awaited preload and subscribed AFTER it —
    // the ordering ADR-026 hardened (the driver forces an initial emit for a late
    // subscriber, so nothing is lost by waiting). The static-frame rung builds no driver
    // at all: there is nothing for scroll to drive.
    if (!staticFrame) {
      this.driverInstance = this.env.createDriver(this.driverSpec(), region);
      // A self-advancing driver must not run for a scene nobody can see (the observers
      // above already reported their current state).
      this.updateDriverSuspension();
    }

    this.preloader = this.env.createPreloader(this.surface, scene, {
      onProgress: (progress, phase) => {
        if (gen !== this.generation) return;
        this.dispatch<VertieProgressDetail>("vertie-progress", { progress, phase });
      },
      ...(this.hasAttribute("debug") ? { env: { observe: this.debugObserve } } : {}),
    });

    try {
      await this.preloader.startWhenNear(region);
    } catch (err) {
      if (gen === this.generation) this.failUnlessAborted(err, "load");
      return;
    }
    if (gen !== this.generation) return;

    this.readyFlag = true;
    this.fitCanvas();

    if (staticFrame) {
      // One frame, then nothing: the scene is visible, the camera never moves (WCAG
      // 2.3.3). `vertie-ready` still fires — the scene really is loaded and drawn.
      this.currentT = 0;
      this.renderFrame(0);
      this.applyPoster();
      // Triggers stay live on this rung: a click is input, not motion (§11 is
      // progressive enhancement, and nothing here animates).
      this.installTriggers(scene);
      this.dispatch("vertie-ready", null);
      this.announceEvents();
      this.settle("static", { reason: "reduced-motion", rung: "frame" });
      return;
    }

    this.unsubscribe = this.driverInstance?.subscribe(this.onDriverT) ?? null;
    this.applyPoster();
    this.showPauseControlIfNeeded();
    this.showScrubControlIfNeeded();
    this.installTriggers(scene);
    this.setState("ready");
    this.dispatch("vertie-ready", null);
    // The driver forces an initial emit as it is subscribed, so the first frame — and
    // with it any event window already open at that t — happens BEFORE this point. Those
    // signals were held back so a host that starts listening on `vertie-ready` still
    // hears them, in the right order.
    this.announceEvents();
  }

  /**
   * The one sink every driver feeds. `discontinuity` (D1) means this t does not continue
   * the last one — a loop wrap, a seek — so the §10 tracker is re-seeded instead of
   * being handed a backwards interval it would faithfully replay window by window.
   */
  private readonly onDriverT = (t: number, discontinuity?: boolean): void => {
    if (discontinuity) this.eventTracker?.reset();
    this.currentT = t;
    this.renderFrame(t);
    this.syncPauseControl();
    this.syncScrubber(t);
  };

  /** Build the §11 input layer for a scene that declares triggers (and only then). */
  private installTriggers(scene: Scene): void {
    const triggers = scene.triggers ?? [];
    if (triggers.length === 0) return;
    this.triggerController = this.env.createTriggers({
      host: this,
      canvas: this.canvas,
      triggers,
      hitTester: { hitTest: (x, y) => this.surface?.hitTest?.(x, y) ?? null },
      sceneTime: () => this.sceneState?.time ?? 0,
      emit: (signal) => this.dispatch<VertieTriggerDetail>("vertie-trigger", signal),
    });
  }

  /**
   * A rung that draws nothing: hide the canvas, leave the poster (or the page's own
   * light-DOM content) standing, and tell the host. No fetch has happened yet and none
   * will — that is the point of deciding this before the first byte.
   */
  private settleWithoutRendering(reason: VertieFallbackReason, rung: VertieFallbackRung): void {
    this.canvas.hidden = true;
    this.applyPoster();
    this.settle("static", { reason, rung });
  }

  private settle(state: VertieState, fallback: VertieFallbackDetail): void {
    this.fallbackInfo = fallback;
    this.setState(state);
    this.dispatchDeferred<VertieFallbackDetail>("vertie-fallback", fallback);
  }

  /** Wrap the gate so a hidden tab (no IntersectionObserver callbacks) stays drivable. */
  private readonly debugObserve = (target: Element, rootMargin: string, onNear: () => void): (() => void) => {
    this.fireGateFn = onNear;
    return defaultPreloaderEnv().observe(target, rootMargin, onNear);
  };

  /**
   * `force` is the verification escape hatch (`dev().setT`/`resize`): the preview pane
   * is permanently `document.hidden`, so without it the no-screenshot channel could
   * never draw a pixel to read back.
   */
  private renderFrame(t: number, force = false): void {
    if (!this.readyFlag || !this.compiled || !this.sceneState || !this.surface) return;
    if (!force && !(this.inView && this.pageVisible)) {
      // Nobody can see it — skip the GPU work and remember that we owe a frame, so the
      // scene is current the moment it comes back rather than a scroll-step behind.
      this.pendingFrame = true;
      return;
    }
    evaluate(this.compiled, t, this.sceneState);
    this.surface.apply(this.sceneState);
    this.surface.render();
    // After the draw, so a `follow` point projects through the camera the user is
    // actually looking at.
    this.emitEvents();
  }

  /**
   * Timeline events (§10) for the frame just drawn. Paused frames emit nothing — the
   * catch-up frame delivers everything that was crossed meanwhile, because the tracker
   * compares intervals rather than samples.
   */
  private emitEvents(): void {
    const tracker = this.eventTracker;
    if (!tracker || !this.sceneState) return;
    const time = this.sceneState.time;
    const transitions = tracker.update(time);
    if (transitions.length === 0) return;

    // The tracker reuses its buffer and a listener may scrub re-entrantly, so read the
    // frame's transitions out before any of them is dispatched.
    const frame = transitions.map((transition) => ({
      name: transition.event.name,
      phase: transition.phase,
      time,
      progress: transition.progress,
      data: transition.event.data,
      follow: this.followDetail(transition.event.follow),
    }));

    for (const detail of frame) {
      this.eventsFired++;
      if (this.eventsAnnounced) this.dispatch<VertieEventDetail>("vertie-event", detail);
      else this.pendingEvents.push(detail);
    }
  }

  /** Where the followed track is — in the world, and on screen (§10 `follow`). */
  private followDetail(id: string | undefined): VertieFollowDetail | null {
    if (id === undefined) return null;
    const position = this.trackPosition(id);
    if (!position) return null; // graceful: the validator rejects an unknown id anyway
    return { id, position, screen: this.surface?.project?.(position) ?? null };
  }

  /**
   * The followed object's world position: the renderer's answer when it has one, since
   * that composes the pose with the track's static `transform` (§7) and so points at the
   * thing the viewer actually sees. The evaluator's bare pose is the fallback for a
   * surface that cannot answer.
   */
  private trackPosition(id: string): Vec3 | null {
    const composed = this.surface?.trackWorldPosition?.(id);
    if (composed) return composed;
    const state = this.sceneState?.tracks.find((track) => track.id === id);
    if (!state) return null;
    return [state.pose.p[0], state.pose.p[1], state.pose.p[2]];
  }

  /** Open the gate held during start-up and let the first frame's signals out. */
  private announceEvents(): void {
    this.eventsAnnounced = true;
    if (this.pendingEvents.length === 0) return;
    const queued = this.pendingEvents.splice(0, this.pendingEvents.length);
    for (const detail of queued) this.dispatch<VertieEventDetail>("vertie-event", detail);
  }

  private setInView(inView: boolean): void {
    this.inView = inView;
    this.updateDriverSuspension();
    this.resumeIfOwed();
  }

  /**
   * A driver that moves on its own stops while the scene cannot be seen — off screen or
   * in a background tab — and resumes where it stopped. Two reasons, both C6's: an
   * invisible scene may not spend a watt, and a viewer scrolling back must not find the
   * timeline somewhere else entirely. Drivers the user moves (scroll) have no such state.
   */
  private updateDriverSuspension(): void {
    this.driverInstance?.suspend?.(!(this.inView && this.pageVisible));
  }

  private resumeIfOwed(): void {
    if (!this.pendingFrame || !this.inView || !this.pageVisible) return;
    this.pendingFrame = false;
    this.renderFrame(this.currentT);
  }

  /** A live change of the motion preference moves the element between rungs. */
  private onReducedMotionChange(reduced: boolean): void {
    if (!this.started || reduced === this.reducedUsed) return;
    this.restart();
  }

  private onResize(force = false): void {
    this.fitCanvas();
    // A resized canvas usually means a resized region: the driver caches its metrics
    // and only re-reads them on invalidation (ADR-026).
    this.driverInstance?.invalidate?.();
    this.renderFrame(this.currentT, force);
  }

  private renewCanvas(): void {
    const next = makeCanvas();
    this.viewport.replaceChild(next, this.canvas);
    this.canvas = next;
  }

  private fitCanvas(): void {
    if (!this.surface) return;
    const width = this.canvas.clientWidth || this.clientWidth || 1;
    const height = this.canvas.clientHeight || 1;
    this.surface.resize(width, height);
  }

  private rebuildDriver(): void {
    if (!this.driverInstance) return;
    this.unsubscribe?.();
    this.unsubscribe = null;
    this.driverInstance.destroy();
    // The new driver reads the attributes fresh — including `paused`, which the element
    // keeps in sync with the real state, so a rebuild mid-pause stays paused.
    this.driverInstance = this.env.createDriver(this.driverSpec(), this.regionElement());
    this.updateDriverSuspension();
    this.hidePauseControl();
    this.hideScrubControl();
    if (!this.readyFlag) return;
    this.unsubscribe = this.driverInstance.subscribe(this.onDriverT);
    this.showPauseControlIfNeeded();
    this.showScrubControlIfNeeded();
  }

  private restart(): void {
    this.teardown();
    registerElement(this);
    this.started = true;
    void this.start();
  }

  private teardown(): void {
    this.generation++; // orphans any in-flight start
    this.started = false;
    this.readyFlag = false;

    this.unsubscribe?.();
    this.unsubscribe = null;
    this.unobserveResize?.();
    this.unobserveResize = null;
    this.unobserveMotion?.();
    this.unobserveMotion = null;
    this.unobserveInView?.();
    this.unobserveInView = null;
    this.unobservePageVisible?.();
    this.unobservePageVisible = null;
    this.driverInstance?.destroy();
    this.driverInstance = null;
    this.triggerController?.destroy();
    this.triggerController = null;
    this.preloader?.destroy();
    this.preloader = null;
    this.controller?.abort();
    this.controller = null;
    this.surface?.dispose();
    this.surface = null;

    this.compiled = null;
    this.sceneState = null;
    this.sceneDoc = null;
    this.compiledEvents = [];
    this.eventTracker = null;
    this.eventsAnnounced = false;
    this.pendingEvents.length = 0;
    this.fireGateFn = null;
    this.inView = true;
    this.pageVisible = true;
    this.pendingFrame = false;
    this.hidePauseControl();
    this.hideScrubControl();
    unregisterElement(this);
    this.applyPoster();
  }

  // ---------------------------------------------------------------- helpers

  private regionElement(): Element {
    const selector = this.getAttribute("region");
    this.regionIsSelf = true;
    if (!selector) return this;
    try {
      const found = this.closest(selector) ?? this.ownerDocument.querySelector(selector);
      if (found) {
        this.regionIsSelf = found === this;
        return found;
      }
      console.warn(`vertie: region "${selector}" matched no element — using <vertie-scene> itself`);
    } catch {
      console.warn(`vertie: invalid region selector "${selector}" — using <vertie-scene> itself`);
    }
    return this;
  }

  /**
   * The attributes, read into the kind's own options (D1's registry owns the kinds; the
   * unknown-name fallback happened once in `start()`). Options are per-driver on purpose:
   * a time driver has no `offsetStart`, a scroll driver has no `loop`.
   */
  private driverSpec(): DriverSpec {
    if (this.driverKindValue === "time") {
      return {
        kind: "time",
        options: {
          durationMs: this.timelineMs(),
          loop: this.hasAttribute("loop"),
          paused: this.hasAttribute("paused"),
        },
      };
    }
    if (this.driverKindValue === "view") {
      const threshold = this.numberAttr("threshold");
      return {
        kind: "view",
        options: {
          durationMs: this.timelineMs(),
          loop: this.hasAttribute("loop"),
          paused: this.hasAttribute("paused"),
          replay: this.hasAttribute("replay"),
          ...(threshold !== null ? { threshold } : {}),
        },
      };
    }
    if (this.driverKindValue === "external") {
      // The host may have been pushing t since before the scene existed (a page that
      // teleported mid-load); the driver opens where the host already is.
      return {
        kind: "external",
        options: { ...(this.externalT !== null ? { initialT: this.externalT } : {}) },
      };
    }
    if (this.driverKindValue === "pointer") {
      const pointerDamping = this.numberAttr("damping");
      return {
        kind: "pointer",
        options: {
          axis: this.axisOption(),
          drag: this.hasAttribute("drag"),
          // The scrub control lies on top of the scene; while the pointer is working it,
          // the driver must not read the same movement as a scrub of its own.
          ignoreInput: () => this.scrubHover || this.scrubHeld,
          ...(pointerDamping !== null ? { damping: pointerDamping } : {}),
        },
      };
    }
    const damping = this.numberAttr("damping");
    const offsetStart = this.numberAttr("offset-start");
    const offsetEnd = this.numberAttr("offset-end");
    return {
      kind: "scroll",
      options: {
        ...(damping !== null ? { damping } : {}),
        ...(offsetStart !== null ? { offsetStart } : {}),
        ...(offsetEnd !== null ? { offsetEnd } : {}),
      },
    };
  }

  /**
   * Wall-clock length of one pass, for every driver that plays on a clock. Scene time is
   * unitless (§6); this is where those units get a rate. An explicit `duration` wins,
   * otherwise the scene's own length is read as seconds — the unit authors mean in
   * practice. A non-positive value is meaningless, so it is ignored rather than obeyed
   * into a scene that is over before it starts.
   */
  private timelineMs(): number {
    const seconds = this.numberAttr("duration");
    const scale = seconds !== null && seconds > 0 ? seconds : (this.compiled?.duration ?? 0);
    return scale * 1000;
  }

  // ---------------------------------------------------------------- playback (SC 2.2.2)

  /**
   * Is the timeline standing still? Either the user asked it to (`paused`) or a finite
   * run has ended — both mean the control offers "play", and both make a `play()`
   * meaningful (an ended driver starts over).
   */
  private driverStopped(): boolean {
    const driver = this.driverInstance;
    if (!driver?.pausable) return true;
    return (driver.paused ?? false) || (driver.ended ?? false);
  }

  private setPaused(paused: boolean): void {
    const driver = this.driverInstance;
    if (!driver?.pausable) return;
    if (paused) driver.pause?.();
    else driver.play?.();
    // Reflect the INTENT, not the ended state: `paused` is what the author (or the user)
    // asked for, and a timeline that simply ran out was never asked to stop.
    const intent = driver.paused ?? paused;
    this.syncingPaused = true;
    this.reflect("paused", intent ? "" : null);
    this.syncingPaused = false;
    this.syncPauseControl();
  }

  // ---------------------------------------------------------------- scrubbing (SC 2.1.1)

  /**
   * The keyboard/AT route into a driver whose only input is a pointer (D3). Same shape as
   * the pause control: the driver declares the capability, the player supplies the
   * control — a page never has to build one, and a pointer-only timeline never ships.
   */
  private showScrubControlIfNeeded(): void {
    const driver = this.driverInstance;
    if (!driver?.scrubbable || !driver.seek) return;
    this.scrubber.hidden = false;
    this.syncScrubber(this.currentT);
  }

  private hideScrubControl(): void {
    this.scrubber.hidden = true;
    this.scrubHover = false;
    this.scrubHeld = false;
  }

  private onScrubInput(): void {
    const percent = Number(this.scrubber.value);
    if (!Number.isFinite(percent)) return;
    this.scrubber.setAttribute("aria-valuetext", `${Math.round(percent)}%`);
    this.driverInstance?.seek?.(percent / 100);
  }

  /**
   * Keep the control showing where the timeline actually is. Nothing has to be guarded
   * against the user here: a driver that offers `seek` LANDS on the value it was given
   * (D3), so the write-back that follows an interaction writes the value the user just
   * chose. It is a mirror, not a competitor.
   */
  private syncScrubber(t: number): void {
    if (this.scrubber.hidden) return;
    const percent = Math.round((t < 0 ? 0 : t > 1 ? 1 : t) * 100);
    if (this.scrubber.value === String(percent)) return;
    this.scrubber.value = String(percent);
    this.scrubber.setAttribute("aria-valuetext", `${percent}%`);
  }

  private showPauseControlIfNeeded(): void {
    if (!this.driverInstance?.pausable) return;
    this.pauseButton.hidden = false;
    this.syncPauseControl();
  }

  private hidePauseControl(): void {
    this.pauseButton.hidden = true;
    this.pauseShownAs = null;
  }

  /** Cheap enough to call every frame: the DOM is touched only when the state flips. */
  private syncPauseControl(): void {
    if (this.pauseButton.hidden) return;
    const stopped = this.driverStopped();
    if (stopped === this.pauseShownAs) return;
    this.pauseShownAs = stopped;
    this.pauseButton.dataset["paused"] = String(stopped);
    // The name is the ACTION, swapped with the state — the media-player pattern.
    const label = stopped ? "Play animation" : "Pause animation";
    this.pauseButton.setAttribute("aria-label", label);
    this.pauseButton.title = label;
  }

  /** `axis` for the pointer driver — an unknown value is a typo, not a refusal to play. */
  private axisOption(): PointerAxis {
    const raw = this.getAttribute("axis");
    if (raw === null || raw.trim() === "") return "x";
    const value = raw.trim();
    if (value === "x" || value === "y") return value;
    console.warn(`vertie: axis="${raw}" is not "x" or "y" — using "x"`);
    return "x";
  }

  /**
   * `frustum-clamp` → the renderer's option. Bare attribute (or `"true"`) means "clamp to
   * the edge"; a number is the margin. The renderer does the range checking and the
   * warning, so a bad value takes exactly one code path, not two.
   */
  private frustumClampOption(): boolean | number | undefined {
    const raw = this.getAttribute("frustum-clamp");
    if (raw === null) return undefined;
    const trimmed = raw.trim();
    if (trimmed === "" || trimmed === "true") return true;
    if (trimmed === "false") return false;
    return Number(trimmed);
  }

  private numberAttr(name: string): number | null {
    const raw = this.getAttribute(name);
    if (raw === null || raw.trim() === "") return null;
    const value = Number(raw);
    if (!Number.isFinite(value)) {
      console.warn(`vertie: ${name}="${raw}" is not a number — ignored`);
      return null;
    }
    return value;
  }

  private reflect(name: string, value: string | null): void {
    if (value === null) this.removeAttribute(name);
    else this.setAttribute(name, value);
  }

  private applyPoster(): void {
    const poster = this.getAttribute("poster");
    if (!poster) {
      this.posterEl.removeAttribute("src");
      this.posterEl.hidden = true;
      return;
    }
    if (this.posterEl.getAttribute("src") !== poster) this.posterEl.setAttribute("src", poster);
    // The poster covers the canvas until there is something to see; a failed load leaves
    // it standing, which is the whole point of having one.
    this.posterEl.hidden = this.readyFlag;
  }

  private fail(error: Error, phase: VertieErrorPhase): void {
    this.errorMessage = error.message;
    this.errorPhaseValue = phase;
    this.setState("error");
    this.dispatchDeferred<VertieErrorDetail>("vertie-error", { error, phase });
  }

  /** Reflected so a page can style the outcome with plain CSS, no JS and no timing race. */
  private setState(state: VertieState): void {
    this.stateValue = state;
    this.setAttribute("state", state);
  }

  /** A cancelled load (element removed, src swapped) is a normal outcome, not an error (ADR-027). */
  private failUnlessAborted(err: unknown, phase: VertieErrorPhase): void {
    if (isAbortError(err)) return;
    this.fail(asError(err), phase);
  }

  private dispatch<T>(type: string, detail: T): void {
    // bubbles: a host can delegate; composed: the event still escapes if the element is
    // itself inside someone else's shadow root.
    this.dispatchEvent(new CustomEvent<T>(type, { detail, bubbles: true, composed: true }));
  }

  /**
   * For outcomes that can be decided **synchronously while the element upgrades** — a
   * zero-byte fallback rung, a missing `src`. The one-line embed is
   * `<vertie-scene>` in the markup plus a module script that imports the package, so the
   * import itself upgrades the element: a synchronous dispatch would land before the page
   * ever gets to call `addEventListener`, and the event would be unobservable. A
   * microtask is late enough for the importing module to finish, and early enough that
   * nothing has painted. (Verified live: the C6 no-WebGL2 rung reached the playground
   * only after this change.)
   */
  private dispatchDeferred<T>(type: string, detail: T): void {
    const gen = this.generation;
    queueMicrotask(() => {
      if (gen !== this.generation) return; // superseded — the outcome is no longer current
      this.dispatch<T>(type, detail);
    });
  }
}

// ---------------------------------------------------------------- registration + debug hook

/**
 * Register the element. Guarded twice: no `customElements` (node/SSR) is a no-op, and an
 * already-registered tag is left alone — two copies of the bundle on one page must not
 * throw, they must agree on whoever got there first.
 */
export function defineVertieScene(tag: string = DEFAULT_TAG): void {
  if (typeof customElements === "undefined") return;
  if (customElements.get(tag)) return;
  customElements.define(tag, VertieSceneElement);
}

const liveElements = new Set<VertieSceneElement>();

/** The `window.__vertie` shape — the project's standard no-screenshot verification channel. */
export interface VertieGlobal {
  version: string;
  readonly elements: VertieSceneElement[];
  get(index?: number): VertieSceneElement | null;
  debug(index?: number): VertieSceneDebug | null;
  dev(index?: number): VertieSceneDevTools | null;
}

declare global {
  /** Installed by the first `<vertie-scene>` that connects. Typed for host pages too. */
  var __vertie: VertieGlobal | undefined;
}

function installGlobal(): void {
  const target = globalThis as typeof globalThis & { __vertie?: VertieGlobal };
  if (target.__vertie) return;
  const hook: VertieGlobal = {
    version: VERTIE_VERSION,
    get elements() {
      return [...liveElements];
    },
    get: (index = 0) => [...liveElements][index] ?? null,
    debug: (index = 0) => [...liveElements][index]?.debug ?? null,
    dev: (index = 0) => [...liveElements][index]?.devTools ?? null,
  };
  target.__vertie = hook;
}

function registerElement(element: VertieSceneElement): void {
  installGlobal();
  liveElements.add(element);
}

function unregisterElement(element: VertieSceneElement): void {
  liveElements.delete(element);
}
